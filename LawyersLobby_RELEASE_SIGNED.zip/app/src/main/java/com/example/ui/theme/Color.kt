package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SaffronOrange = Color(0xFFFF9933)
val NavyBlue = Color(0xFF1B3A5C)
val IndiaGreen = Color(0xFF138808)
val WarmCream = Color(0xFFFFF8F0)
val TextPrimary = Color(0xFF1B3A5C)
val TextSecondary = Color(0xFF6B7280)
val BorderColor = Color(0xFFE5E7EB)
val ErrorRed = Color(0xFFDC2626)
val SuccessGreen = Color(0xFF059669)

// Dark mode overrides
val DarkBackground = Color(0xFF0E1A27)
val DarkSurface = Color(0xFF152639)
val DarkTextPrimary = Color(0xFFF3F4F6)
val DarkTextSecondary = Color(0xFF9CA3AF)
