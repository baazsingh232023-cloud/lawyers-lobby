package com.example.ui

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NavyBlue
import com.example.ui.theme.SaffronOrange
import com.example.ui.theme.TextSecondary

@Composable
fun ShakeDetectorListener(onShake: () -> Unit) {
    val context = LocalContext.current
    DisposableEffect(context) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        
        var lastUpdate: Long = 0
        var lastX = 0f
        var lastY = 0f
        var lastZ = 0f
        val shakeThreshold = 950 // Speed threshold to detect shake

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                    val currentTime = System.currentTimeMillis()
                    if ((currentTime - lastUpdate) > 100) {
                        val diffTime = currentTime - lastUpdate
                        lastUpdate = currentTime
                        
                        val x = event.values[0]
                        val y = event.values[1]
                        val z = event.values[2]
                        
                        val speed = kotlin.math.abs(x + y + z - lastX - lastY - lastZ) / diffTime * 10000
                        if (speed > shakeThreshold) {
                            onShake()
                        }
                        lastX = x
                        lastY = y
                        lastZ = z
                    }
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }
        
        onDispose {
            sensorManager?.unregisterListener(listener)
        }
    }
}

@Composable
fun AppFeedbackDialog(
    onDismissRequest: () -> Unit,
    initialCategory: String = "Bug Report",
    onFeedbackSubmitted: (category: String, rating: Int, description: String) -> Unit
) {
    var rating by remember { mutableStateOf(5) }
    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var feedbackDescription by remember { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }
    
    val categories = listOf(
        "Bug Report", "Feature Request", "Lawyer Issue", 
        "Payment Problem", "App is Slow", "Screen Not Working", "Other"
    )

    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BugReport, contentDescription = null, tint = SaffronOrange, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Report Bug & Feedback", fontWeight = FontWeight.Bold, color = NavyBlue)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                Text(
                    text = "Help us improve Lawyer's Lobby. Report issues or send suggestions directly to our development team.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 14.dp)
                )

                // Category dropdown
                Text("Select Category", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
                Box(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = NavyBlue) },
                        modifier = Modifier.fillMaxWidth().clickable { categoryExpanded = true },
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SaffronOrange,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                    DropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat, fontSize = 14.sp) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                // Star Rating
                Text("Rate App Experience", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    for (i in 1..5) {
                        val isSelected = i <= rating
                        Icon(
                            imageVector = if (isSelected) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Star $i",
                            tint = if (isSelected) SaffronOrange else Color.Gray,
                            modifier = Modifier
                                .size(36.dp)
                                .clickable { rating = i }
                        )
                    }
                }

                // Description Input
                Text("Description & Details", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
                OutlinedTextField(
                    value = feedbackDescription,
                    onValueChange = { feedbackDescription = it },
                    modifier = Modifier.fillMaxWidth().height(100.dp).testTag("feedback_desc_input"),
                    placeholder = { Text("e.g., Description of what went wrong, screen where it happened, or suggestion...", fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SaffronOrange,
                        unfocusedBorderColor = Color.LightGray
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (feedbackDescription.isNotBlank()) {
                        onFeedbackSubmitted(selectedCategory, rating, feedbackDescription)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("Submit", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Cancel", color = Color.Gray)
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(16.dp)
    )
}

fun sendFeedbackEmail(context: Context, category: String, rating: Int, description: String) {
    val rCode = (100000..999999).random()
    try {
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf("baazsingh232023@gmail.com"))
            putExtra(Intent.EXTRA_SUBJECT, "Lawyer's Lobby App Feedback - [$category]")
            putExtra(
                Intent.EXTRA_TEXT,
                "Category: $category\n" +
                "Rating: $rating/5 Stars\n" +
                "Ticket Code: #NY-$rCode\n\n" +
                "Problem/Feedback Description:\n" +
                description
            )
        }
        val chooser = Intent.createChooser(emailIntent, "Send feedback email...")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
        Toast.makeText(context, "Drafting feedback email...", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Feedback registered successfully (Ticket #NY-$rCode)!", Toast.LENGTH_LONG).show()
    }
}
