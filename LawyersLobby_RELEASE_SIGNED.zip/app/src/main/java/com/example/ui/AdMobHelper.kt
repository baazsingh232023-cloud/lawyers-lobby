package com.example.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.SaffronOrange
import com.example.ui.theme.NavyBlue
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

object AdMobHelper {
    private const val TAG = "AdMobHelper"
    private var interstitialAd: InterstitialAd? = null
    private var profileViewCount = 0

    const val APP_ID = "ca-app-pub-7490615139432387~6994953643"
    const val BANNER_ID = "ca-app-pub-7490615139432387/1108497299"
    const val INTERSTITIAL_ID = "ca-app-pub-7490615139432387/6113411966"
    const val NATIVE_ID = "ca-app-pub-7490615139432387/8603843939"

    fun loadInterstitial(context: Context) {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            INTERSTITIAL_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    Log.d(TAG, "Interstitial ad failed to load: ${adError.message}")
                    interstitialAd = null
                }

                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial ad loaded successfully")
                    interstitialAd = ad
                }
            }
        )
    }

    fun incrementProfileViewAndShowIfThresholdReached(activity: Activity, showAds: Boolean) {
        if (!showAds) {
            Log.d(TAG, "Not showing ads to admin user")
            return
        }
        profileViewCount++
        Log.d(TAG, "Lawyer Profile viewed count: $profileViewCount")
        if (profileViewCount >= 3) {
            profileViewCount = 0 // Reset
            if (interstitialAd != null) {
                Log.d(TAG, "Presenting interstitial ad now")
                interstitialAd?.show(activity)
                loadInterstitial(activity) // Load next
            } else {
                Log.d(TAG, "Interstitial not yet ready; reloading...")
                loadInterstitial(activity)
            }
        }
    }
}

fun Context.findActivity(): Activity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    return null
}

@Composable
fun BannerAd(
    modifier: Modifier = Modifier,
    adUnitId: String = AdMobHelper.BANNER_ID
) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                setAdUnitId(adUnitId)
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

@Composable
fun NativeAdListItem(
    modifier: Modifier = Modifier,
    adUnitId: String = AdMobHelper.NATIVE_ID
) {
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        val adLoader = AdLoader.Builder(context, adUnitId)
            .forNativeAd { ad ->
                nativeAd = ad
            }
            .build()
        adLoader.loadAd(AdRequest.Builder().build())
        onDispose {
            nativeAd?.destroy()
        }
    }

    val currentAd = nativeAd
    if (currentAd != null) {
        AndroidView(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            factory = { ctx ->
                val adView = NativeAdView(ctx)
                val composeView = ComposeView(ctx).apply {
                    setContent {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF8F5)),
                            border = BorderStroke(1.dp, Color(0xFFFFCC99)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(SaffronOrange, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "AD",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = currentAd.headline ?: "Sponsored",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = NavyBlue
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentAd.body ?: "",
                                    fontSize = 13.sp,
                                    color = Color.DarkGray
                                )
                                if (currentAd.callToAction != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = {},
                                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Text(
                                            text = currentAd.callToAction ?: "Learn More",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                adView.addView(composeView)
                adView.headlineView = composeView
                adView.setNativeAd(currentAd)
                adView
            },
            update = { adView ->
                adView.setNativeAd(currentAd)
            }
        )
    } else {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .height(100.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        color = SaffronOrange,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Loading sponsored recommendation...", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}
