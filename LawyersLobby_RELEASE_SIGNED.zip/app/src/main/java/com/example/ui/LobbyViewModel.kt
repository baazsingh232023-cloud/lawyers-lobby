package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseReference
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// High level categorization model for static views
data class CategoryItem(
    val id: String,
    val nameEnglish: String,
    val nameHindi: String,
    val icon: String,
    val lawyerCount: Int
)

data class CityItem(
    val id: String,
    val cityName: String,
    val state: String,
    val highCourt: String
)

data class LegalCase(
    val id: String,
    val clientName: String,
    val caseType: String,
    val date: String,
    val status: String // "Active" or "Closed"
)

data class PaymentKey(
    val id: String,
    val type: String, // "UPI" or "Card"
    val label: String,
    val value: String
)

data class AnnouncementItem(
    val id: String = System.currentTimeMillis().toString(),
    val title: String,
    val text: String,
    val target: String, // "ALL" | "LAWYERS" | "CLIENTS"
    val dateString: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class OtpSessionState(
    val phone: String,
    val correctOtp: String,
    val attemptsLeft: Int = 3,
    val expiresAt: Long,
    val lockedUntil: Long = 0L,
    val onVerified: () -> Unit
)

class LobbyViewModel(application: Application) : AndroidViewModel(application) {

    val repository = LobbyRepository.getInstance(application)

    private fun getDb(): com.google.firebase.database.FirebaseDatabase {
        return com.google.firebase.database.FirebaseDatabase.getInstance("https://lawyers-lobby-default-rtdb.firebaseio.com")
    }

    fun syncDataFromFirebase() {
        viewModelScope.launch {
            try {
                val database = getDb()
                
                // 1. Sync users node
                val usersSnapshot = database.getReference("users").get().await()
                for (child in usersSnapshot.children) {
                    try {
                        val uid = child.key ?: continue
                        val user = UserEntity(
                            uid = uid,
                            name = child.getString("name") ?: "",
                            email = child.getString("email") ?: "",
                            phone = child.getString("phone") ?: "",
                            city = child.getString("city") ?: "New Delhi",
                            state = child.getString("state") ?: "Delhi",
                            role = child.getString("role") ?: "client",
                            profilePhoto = child.getString("profilePhoto") ?: "",
                            createdAt = child.getLong("createdAt") ?: System.currentTimeMillis(),
                            isActive = child.getBoolean("isActive") ?: true
                        )
                        repository.insertUser(user)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                // 2. Sync lawyers node (Read lawyers list -> lawyers/)
                val lawyersSnapshot = database.getReference("lawyers").get().await()
                for (child in lawyersSnapshot.children) {
                    try {
                        val uid = child.key ?: continue
                        val lawyer = LawyerEntity(
                            uid = uid,
                            name = child.getString("name") ?: "",
                            email = child.getString("email") ?: "",
                            phone = child.getString("phone") ?: "",
                            city = child.getString("city") ?: "New Delhi",
                            state = child.getString("state") ?: "Delhi",
                            barCouncilNumber = child.getString("barCouncilNumber") ?: "",
                            experienceYears = child.getLong("experienceYears")?.toInt() ?: 5,
                            consultationFee = child.getLong("consultationFee")?.toInt() ?: 1000,
                            courtAppearanceFee = child.getLong("courtAppearanceFee")?.toInt() ?: 5000,
                            specialisation = child.getString("specialisation") ?: "General",
                            caseTypes = child.getString("caseTypes") ?: "",
                            languages = child.getString("languages") ?: "Hindi, English",
                            about = child.getString("about") ?: "",
                            officeAddress = child.getString("officeAddress") ?: "",
                            workingHours = child.getString("workingHours") ?: "10:00 AM - 06:00 PM (Mon-Sat)",
                            profilePhoto = child.getString("profilePhoto") ?: "",
                            officePhotos = child.getString("officePhotos") ?: "",
                            isVerified = child.getBoolean("isVerified") ?: false,
                            isOnline = child.getBoolean("isOnline") ?: true,
                            rating = child.getDouble("rating")?.toFloat() ?: 5.0f,
                            totalReviews = child.getLong("totalReviews")?.toInt() ?: 0,
                            totalCasesWon = child.getLong("totalCasesWon")?.toInt() ?: 10,
                            linkedInUrl = child.getString("linkedInUrl") ?: "",
                            googleProfileUrl = child.getString("googleProfileUrl") ?: "",
                            isActive = child.getBoolean("isActive") ?: true,
                            createdAt = child.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                        repository.registerLawyer(
                            UserEntity(
                                uid = uid,
                                name = lawyer.name,
                                email = lawyer.email,
                                phone = lawyer.phone,
                                city = lawyer.city,
                                state = lawyer.state,
                                role = "lawyer",
                                profilePhoto = lawyer.profilePhoto,
                                createdAt = lawyer.createdAt,
                                isActive = lawyer.isActive
                            ),
                            lawyer
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                // 3. Sync emergencies node
                val emergenciesSnapshot = database.getReference("emergencies").get().await()
                for (child in emergenciesSnapshot.children) {
                    try {
                        val request = EmergencyRequestEntity(
                            id = child.getLong("id")?.toInt() ?: (child.key?.hashCode() ?: 0),
                            name = child.getString("name") ?: "",
                            phone = child.getString("phone") ?: "",
                            city = child.getString("city") ?: "",
                            emergencyType = child.getString("emergencyType") ?: "",
                            description = child.getString("description") ?: "",
                            createdAt = child.getLong("createdAt") ?: System.currentTimeMillis(),
                            isResolved = child.getBoolean("isResolved") ?: false,
                            assignedLawyerId = child.getString("assignedLawyerId"),
                            assignedLawyerName = child.getString("assignedLawyerName")
                        )
                        repository.insertEmergencyRequest(request)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                // 4. Sync reviews node
                val reviewsSnapshot = database.getReference("reviews").get().await()
                for (child in reviewsSnapshot.children) {
                    try {
                        val review = ReviewEntity(
                            reviewId = child.getLong("reviewId")?.toInt() ?: (child.key?.hashCode() ?: 0),
                            lawyerId = child.getString("lawyerId") ?: "",
                            clientId = child.getString("clientId") ?: "anonymous_client",
                            clientName = child.getString("clientName") ?: "Anonymous",
                            rating = child.getLong("rating")?.toInt() ?: 5,
                            reviewText = child.getString("reviewText") ?: "",
                            caseType = child.getString("caseType") ?: "General Dispute",
                            isVerifiedClient = child.getBoolean("isVerifiedClient") ?: true,
                            createdAt = child.getLong("createdAt") ?: System.currentTimeMillis(),
                            isVisible = child.getBoolean("isVisible") ?: true
                        )
                        repository.insertReview(review)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Data streams
    val allLawyers: StateFlow<List<LawyerEntity>> = repository.allLawyers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReviews: StateFlow<List<ReviewEntity>> = repository.allReviews
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allEmergencyRequests: StateFlow<List<EmergencyRequestEntity>> = repository.allEmergencyRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentUser: StateFlow<UserEntity?> = repository.currentUser

    private val _featuredLawyerIds = MutableStateFlow<Set<String>>(setOf("lawyer_1"))
    val featuredLawyerIds: StateFlow<Set<String>> = _featuredLawyerIds

    private val _announcements = MutableStateFlow<List<AnnouncementItem>>(listOf(
        AnnouncementItem("1", "Welcome to Lawyers Lobby! 🎉", "Find registered senior advocates and consult instantly with offline-first local secure storage.", "ALL", "11 June, 2026"),
        AnnouncementItem("2", "Urgent High Court Notice 🏛️", "District and Sessions Courts offline filing counters will close early today due to administrative review.", "LAWYERS", "11 June, 2026")
    ))
    val announcements: StateFlow<List<AnnouncementItem>> = _announcements

    // UI Interactive States (Search and Filter)
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedCityFilter = MutableStateFlow("All")
    val selectedCityFilter: StateFlow<String> = _selectedCityFilter

    private val _selectedCategoryFilter = MutableStateFlow("All")
    val selectedCategoryFilter: StateFlow<String> = _selectedCategoryFilter

    private val _verifiedOnly = MutableStateFlow(false)
    val verifiedOnly: StateFlow<Boolean> = _verifiedOnly

    private val _onlineOnly = MutableStateFlow(false)
    val onlineOnly: StateFlow<Boolean> = _onlineOnly

    private val _sortOption = MutableStateFlow("Rating") // "Rating" | "Fees" | "Experience" | "Newest"
    val sortOption: StateFlow<String> = _sortOption

    // Advanced Admin States
    private val _blacklist = MutableStateFlow<List<Map<String, Any>>>(emptyList())
    val blacklist: StateFlow<List<Map<String, Any>>> = _blacklist

    private val _rejectionReasons = MutableStateFlow<Map<String, String>>(emptyMap())
    val rejectionReasons: StateFlow<Map<String, String>> = _rejectionReasons

    private val _suspensions = MutableStateFlow<Map<String, Triple<Long, String, Boolean>>>(emptyMap())
    val suspensions: StateFlow<Map<String, Triple<Long, String, Boolean>>> = _suspensions

    private val _adminNotes = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    val adminNotes: StateFlow<Map<String, List<String>>> = _adminNotes

    // OTP verification flow states
    private val _otpState = MutableStateFlow<OtpSessionState?>(null)
    val otpState: StateFlow<OtpSessionState?> = _otpState

    // Selected items for drill-down views
    private val _selectedLawyerId = MutableStateFlow<String?>(null)
    val selectedLawyerId: StateFlow<String?> = _selectedLawyerId

    init {
        // Seed db on startup
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
            syncDataFromFirebase()
        }
    }

    // Static Category helper lists (all 18 items)
    val categories = listOf(
        CategoryItem("1", "Criminal Defence", "आपराधिक बचाव", "⚖️", 124),
        CategoryItem("2", "Property Dispute", "संपत्ति विवाद", "🏠", 98),
        CategoryItem("3", "Divorce & Family", "तलाक और परिवार", "💔", 85),
        CategoryItem("4", "Corporate & Startup", "कॉर्पोरेट", "💼", 112),
        CategoryItem("5", "Cheque Bounce", "चेक बाउंस", "🏦", 73),
        CategoryItem("6", "Consumer Forum", "उपभोक्ता फोरम", "🛍️", 61),
        CategoryItem("7", "GST & Income Tax", "जीएसटी और कर", "📋", 54),
        CategoryItem("8", "Labour & Employment", "श्रम और रोजगार", "👷", 48),
        CategoryItem("9", "RTI", "आरटीआई", "📜", 32),
        CategoryItem("10", "RERA & Builder", "रेरा", "🏗️", 45),
        CategoryItem("11", "Cybercrime", "साइबर अपराध", "💻", 67),
        CategoryItem("12", "Motor Accident", "दुर्घटना", "🚗", 39),
        CategoryItem("13", "Trademark & IP", "ट्रेडमार्क", "🏷️", 58),
        CategoryItem("14", "Tenant & Landlord", "किरेयेदार", "🔑", 41),
        CategoryItem("15", "Bail Application", "जमानत", "📑", 102),
        CategoryItem("16", "POCSO & Child", "पॉक्सो", "👶", 28),
        CategoryItem("17", "Medical Negligence", "चिकित्सा लापरवाही", "💊", 23),
        CategoryItem("18", "High Court Matters", "उच्च न्यायालय", "🏛️", 89)
    )

    // Major Cities mapping (Indian major cities)
    val cities = listOf(
        // DELHI NCR
        CityItem("new_delhi", "New Delhi", "Delhi", "Delhi High Court"),
        CityItem("delhi", "Delhi", "Delhi", "Delhi High Court"),
        CityItem("noida", "Noida", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("greater_noida", "Greater Noida", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("gurgaon", "Gurgaon", "Haryana", "Punjab & Haryana High Court"),
        CityItem("faridabad", "Faridabad", "Haryana", "Punjab & Haryana High Court"),
        CityItem("ghaziabad", "Ghaziabad", "Uttar Pradesh", "Allahabad High Court"),

        // MAHARASHTRA
        CityItem("mumbai", "Mumbai", "Maharashtra", "Bombay High Court"),
        CityItem("pune", "Pune", "Maharashtra", "Bombay High Court"),
        CityItem("nagpur", "Nagpur", "Maharashtra", "Bombay High Court"),
        CityItem("thane", "Thane", "Maharashtra", "Bombay High Court"),
        CityItem("nashik", "Nashik", "Maharashtra", "Bombay High Court"),
        CityItem("aurangabad", "Aurangabad", "Maharashtra", "Bombay High Court"),
        CityItem("solapur", "Solapur", "Maharashtra", "Bombay High Court"),
        CityItem("amravati", "Amravati", "Maharashtra", "Bombay High Court"),
        CityItem("kolhapur", "Kolhapur", "Maharashtra", "Bombay High Court"),
        CityItem("nanded", "Nanded", "Maharashtra", "Bombay High Court"),
        CityItem("sangli", "Sangli", "Maharashtra", "Bombay High Court"),
        CityItem("jalgaon", "Jalgaon", "Maharashtra", "Bombay High Court"),
        CityItem("akola", "Akola", "Maharashtra", "Bombay High Court"),
        CityItem("latur", "Latur", "Maharashtra", "Bombay High Court"),
        CityItem("dhule", "Dhule", "Maharashtra", "Bombay High Court"),
        CityItem("ahmednagar", "Ahmednagar", "Maharashtra", "Bombay High Court"),
        CityItem("chandrapur", "Chandrapur", "Maharashtra", "Bombay High Court"),
        CityItem("navi_mumbai", "Navi Mumbai", "Maharashtra", "Bombay High Court"),
        CityItem("vasai_virar", "Vasai-Virar", "Maharashtra", "Bombay High Court"),
        CityItem("malegaon", "Malegaon", "Maharashtra", "Bombay High Court"),
        CityItem("bhiwandi", "Bhiwandi", "Maharashtra", "Bombay High Court"),

        // UTTAR PRADESH
        CityItem("lucknow", "Lucknow", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("kanpur", "Kanpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("agra", "Agra", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("meerut", "Meerut", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("varanasi", "Varanasi", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("prayagraj", "Prayagraj", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("bareilly", "Bareilly", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("aligarh", "Aligarh", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("moradabad", "Moradabad", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("saharanpur", "Saharanpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("gorakhpur", "Gorakhpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("firozabad", "Firozabad", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("jhansi", "Jhansi", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("muzaffarnagar", "Muzaffarnagar", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("mathura", "Mathura", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("rampur", "Rampur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("shahjahanpur", "Shahjahanpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("hapur", "Hapur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("etawah", "Etawah", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("mirzapur", "Mirzapur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("bulandshahr", "Bulandshahr", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("amroha", "Amroha", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("hardoi", "Hardoi", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("fatehpur", "Fatehpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("raebareli", "Raebareli", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("unnao", "Unnao", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("jaunpur", "Jaunpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("lakhimpur", "Lakhimpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("hathras", "Hathras", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("banda", "Banda", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("gonda", "Gonda", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("mainpuri", "Mainpuri", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("deoria", "Deoria", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("basti", "Basti", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("sultanpur", "Sultanpur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("ayodhya", "Ayodhya", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("sitapur", "Sitapur", "Uttar Pradesh", "Allahabad High Court"),
        CityItem("bahraich", "Bahraich", "Uttar Pradesh", "Allahabad High Court"),

        // KARNATAKA
        CityItem("bengaluru", "Bengaluru", "Karnataka", "Karnataka High Court"),
        CityItem("mysuru", "Mysuru", "Karnataka", "Karnataka High Court"),
        CityItem("hubballi", "Hubballi", "Karnataka", "Karnataka High Court"),
        CityItem("dharwad", "Dharwad", "Karnataka", "Karnataka High Court"),
        CityItem("mangaluru", "Mangaluru", "Karnataka", "Karnataka High Court"),
        CityItem("belagavi", "Belagavi", "Karnataka", "Karnataka High Court"),
        CityItem("davanagere", "Davanagere", "Karnataka", "Karnataka High Court"),
        CityItem("ballari", "Ballari", "Karnataka", "Karnataka High Court"),
        CityItem("vijayapura", "Vijayapura", "Karnataka", "Karnataka High Court"),
        CityItem("shivamogga", "Shivamogga", "Karnataka", "Karnataka High Court"),
        CityItem("tumakuru", "Tumakuru", "Karnataka", "Karnataka High Court"),
        CityItem("raichur", "Raichur", "Karnataka", "Karnataka High Court"),
        CityItem("bidar", "Bidar", "Karnataka", "Karnataka High Court"),
        CityItem("kalaburagi", "Kalaburagi", "Karnataka", "Karnataka High Court"),
        CityItem("hassan", "Hassan", "Karnataka", "Karnataka High Court"),
        CityItem("udupi", "Udupi", "Karnataka", "Karnataka High Court"),

        // TAMIL NADU
        CityItem("chennai", "Chennai", "Tamil Nadu", "Madras High Court"),
        CityItem("coimbatore", "Coimbatore", "Tamil Nadu", "Madras High Court"),
        CityItem("madurai", "Madurai", "Tamil Nadu", "Madras High Court"),
        CityItem("tiruchirappalli", "Tiruchirappalli", "Tamil Nadu", "Madras High Court"),
        CityItem("salem", "Salem", "Tamil Nadu", "Madras High Court"),
        CityItem("tirunelveli", "Tirunelveli", "Tamil Nadu", "Madras High Court"),
        CityItem("vellore", "Vellore", "Tamil Nadu", "Madras High Court"),
        CityItem("erode", "Erode", "Tamil Nadu", "Madras High Court"),
        CityItem("thoothukudi", "Thoothukudi", "Tamil Nadu", "Madras High Court"),
        CityItem("dindigul", "Dindigul", "Tamil Nadu", "Madras High Court"),
        CityItem("thanjavur", "Thanjavur", "Tamil Nadu", "Madras High Court"),
        CityItem("tiruppur", "Tiruppur", "Tamil Nadu", "Madras High Court"),
        CityItem("kanchipuram", "Kanchipuram", "Tamil Nadu", "Madras High Court"),
        CityItem("kumbakonam", "Kumbakonam", "Tamil Nadu", "Madras High Court"),
        CityItem("nagercoil", "Nagercoil", "Tamil Nadu", "Madras High Court"),
        CityItem("hosur", "Hosur", "Tamil Nadu", "Madras High Court"),
        CityItem("karur", "Karur", "Tamil Nadu", "Madras High Court"),
        CityItem("sivakasi", "Sivakasi", "Tamil Nadu", "Madras High Court"),
        CityItem("ambattur", "Ambattur", "Tamil Nadu", "Madras High Court"),
        CityItem("tambaram", "Tambaram", "Tamil Nadu", "Madras High Court"),

        // RAJASTHAN
        CityItem("jaipur", "Jaipur", "Rajasthan", "Rajasthan High Court"),
        CityItem("jodhpur", "Jodhpur", "Rajasthan", "Rajasthan High Court"),
        CityItem("kota", "Kota", "Rajasthan", "Rajasthan High Court"),
        CityItem("bikaner", "Bikaner", "Rajasthan", "Rajasthan High Court"),
        CityItem("ajmer", "Ajmer", "Rajasthan", "Rajasthan High Court"),
        CityItem("udaipur", "Udaipur", "Rajasthan", "Rajasthan High Court"),
        CityItem("bhilwara", "Bhilwara", "Rajasthan", "Rajasthan High Court"),
        CityItem("alwar", "Alwar", "Rajasthan", "Rajasthan High Court"),
        CityItem("bharatpur", "Bharatpur", "Rajasthan", "Rajasthan High Court"),
        CityItem("sikar", "Sikar", "Rajasthan", "Rajasthan High Court"),
        CityItem("sri_ganganagar", "Sri Ganganagar", "Rajasthan", "Rajasthan High Court"),
        CityItem("pali", "Pali", "Rajasthan", "Rajasthan High Court"),
        CityItem("barmer", "Barmer", "Rajasthan", "Rajasthan High Court"),
        CityItem("jhunjhunu", "Jhunjhunu", "Rajasthan", "Rajasthan High Court"),
        CityItem("tonk", "Tonk", "Rajasthan", "Rajasthan High Court"),
        CityItem("kishangarh", "Kishangarh", "Rajasthan", "Rajasthan High Court"),
        CityItem("hanumangarh", "Hanumangarh", "Rajasthan", "Rajasthan High Court"),
        CityItem("chittorgarh", "Chittorgarh", "Rajasthan", "Rajasthan High Court"),
        CityItem("bhiwadi", "Bhiwadi", "Rajasthan", "Rajasthan High Court"),
        CityItem("nagaur", "Nagaur", "Rajasthan", "Rajasthan High Court"),
        CityItem("bundi", "Bundi", "Rajasthan", "Rajasthan High Court"),

        // GUJARAT
        CityItem("ahmedabad", "Ahmedabad", "Gujarat", "Gujarat High Court"),
        CityItem("surat", "Surat", "Gujarat", "Gujarat High Court"),
        CityItem("vadodara", "Vadodara", "Gujarat", "Gujarat High Court"),
        CityItem("rajkot", "Rajkot", "Gujarat", "Gujarat High Court"),
        CityItem("bhavnagar", "Bhavnagar", "Gujarat", "Gujarat High Court"),
        CityItem("jamnagar", "Jamnagar", "Gujarat", "Gujarat High Court"),
        CityItem("junagadh", "Junagadh", "Gujarat", "Gujarat High Court"),
        CityItem("gandhinagar", "Gandhinagar", "Gujarat", "Gujarat High Court"),
        CityItem("gandhidham", "Gandhidham", "Gujarat", "Gujarat High Court"),
        CityItem("anand", "Anand", "Gujarat", "Gujarat High Court"),
        CityItem("morbi", "Morbi", "Gujarat", "Gujarat High Court"),
        CityItem("nadiad", "Nadiad", "Gujarat", "Gujarat High Court"),
        CityItem("surendranagar", "Surendranagar", "Gujarat", "Gujarat High Court"),
        CityItem("bharuch", "Bharuch", "Gujarat", "Gujarat High Court"),
        CityItem("mehsana", "Mehsana", "Gujarat", "Gujarat High Court"),
        CityItem("bhuj", "Bhuj", "Gujarat", "Gujarat High Court"),
        CityItem("vapi", "Vapi", "Gujarat", "Gujarat High Court"),
        CityItem("navsari", "Navsari", "Gujarat", "Gujarat High Court"),
        CityItem("porbandar", "Porbandar", "Gujarat", "Gujarat High Court"),
        CityItem("palanpur", "Palanpur", "Gujarat", "Gujarat High Court"),

        // ANDHRA PRADESH
        CityItem("visakhapatnam", "Visakhapatnam", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("vijayawada", "Vijayawada", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("guntur", "Guntur", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("nellore", "Nellore", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("kurnool", "Kurnool", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("tirupati", "Tirupati", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("kakinada", "Kakinada", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("rajahmundry", "Rajahmundry", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("kadapa", "Kadapa", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("anantapur", "Anantapur", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("eluru", "Eluru", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("ongole", "Ongole", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("nandyal", "Nandyal", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("hindupur", "Hindupur", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("machilipatnam", "Machilipatnam", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("bhimavaram", "Bhimavaram", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("adoni", "Adoni", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("proddatur", "Proddatur", "Andhra Pradesh", "Andhra Pradesh High Court"),
        CityItem("chittoor", "Chittoor", "Andhra Pradesh", "Andhra Pradesh High Court"),

        // TELANGANA
        CityItem("hyderabad", "Hyderabad", "Telangana", "Telangana High Court"),
        CityItem("secunderabad", "Secunderabad", "Telangana", "Telangana High Court"),
        CityItem("warangal", "Warangal", "Telangana", "Telangana High Court"),
        CityItem("nizamabad", "Nizamabad", "Telangana", "Telangana High Court"),
        CityItem("karimnagar", "Karimnagar", "Telangana", "Telangana High Court"),
        CityItem("khammam", "Khammam", "Telangana", "Telangana High Court"),
        CityItem("ramagundam", "Ramagundam", "Telangana", "Telangana High Court"),
        CityItem("mahbubnagar", "Mahbubnagar", "Telangana", "Telangana High Court"),
        CityItem("nalgonda", "Nalgonda", "Telangana", "Telangana High Court"),
        CityItem("adilabad", "Adilabad", "Telangana", "Telangana High Court"),
        CityItem("suryapet", "Suryapet", "Telangana", "Telangana High Court"),
        CityItem("miryalaguda", "Miryalaguda", "Telangana", "Telangana High Court"),
        CityItem("jagtial", "Jagtial", "Telangana", "Telangana High Court"),
        CityItem("mancherial", "Mancherial", "Telangana", "Telangana High Court"),
        CityItem("siddipet", "Siddipet", "Telangana", "Telangana High Court"),

        // WEST BENGAL
        CityItem("kolkata", "Kolkata", "West Bengal", "Calcutta High Court"),
        CityItem("howrah", "Howrah", "West Bengal", "Calcutta High Court"),
        CityItem("asansol", "Asansol", "West Bengal", "Calcutta High Court"),
        CityItem("siliguri", "Siliguri", "West Bengal", "Calcutta High Court"),
        CityItem("durgapur", "Durgapur", "West Bengal", "Calcutta High Court"),
        CityItem("bardhaman", "Bardhaman", "West Bengal", "Calcutta High Court"),
        CityItem("malda", "Malda", "West Bengal", "Calcutta High Court"),
        CityItem("baharampur", "Baharampur", "West Bengal", "Calcutta High Court"),
        CityItem("habra", "Habra", "West Bengal", "Calcutta High Court"),
        CityItem("kharagpur", "Kharagpur", "West Bengal", "Calcutta High Court"),
        CityItem("haldia", "Haldia", "West Bengal", "Calcutta High Court"),
        CityItem("raiganj", "Raiganj", "West Bengal", "Calcutta High Court"),
        CityItem("krishnanagar", "Krishnanagar", "West Bengal", "Calcutta High Court"),
        CityItem("cooch_behar", "Cooch Behar", "West Bengal", "Calcutta High Court"),
        CityItem("jalpaiguri", "Jalpaiguri", "West Bengal", "Calcutta High Court"),
        CityItem("darjeeling", "Darjeeling", "West Bengal", "Calcutta High Court"),
        CityItem("bidhannagar", "Bidhannagar", "West Bengal", "Calcutta High Court"),

        // MADHYA PRADESH
        CityItem("indore", "Indore", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("bhopal", "Bhopal", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("jabalpur", "Jabalpur", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("gwalior", "Gwalior", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("ujjain", "Ujjain", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("sagar", "Sagar", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("dewas", "Dewas", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("satna", "Satna", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("ratlam", "Ratlam", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("rewa", "Rewa", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("singrauli", "Singrauli", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("burhanpur", "Burhanpur", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("khandwa", "Khandwa", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("bhind", "Bhind", "Madhya Pradesh", "Bhind High Court"),
        CityItem("chhindwara", "Chhindwara", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("guna", "Guna", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("shivpuri", "Shivpuri", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("vidisha", "Vidisha", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("chhatarpur", "Chhatarpur", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("mandsaur", "Mandsaur", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("khargone", "Khargone", "Madhya Pradesh", "Madhya Pradesh High Court"),
        CityItem("neemuch", "Neemuch", "Madhya Pradesh", "Madhya Pradesh High Court"),

        // PUNJAB
        CityItem("ludhiana", "Ludhiana", "Punjab", "Punjab & Haryana High Court"),
        CityItem("amritsar", "Amritsar", "Punjab", "Punjab & Haryana High Court"),
        CityItem("jalandhar", "Jalandhar", "Punjab", "Punjab & Haryana High Court"),
        CityItem("patiala", "Patiala", "Punjab", "Punjab & Haryana High Court"),
        CityItem("bathinda", "Bathinda", "Punjab", "Punjab & Haryana High Court"),
        CityItem("mohali", "Mohali", "Punjab", "Punjab & Haryana High Court"),
        CityItem("firozpur", "Firozpur", "Punjab", "Punjab & Haryana High Court"),
        CityItem("batala", "Batala", "Punjab", "Punjab & Haryana High Court"),
        CityItem("pathankot", "Pathankot", "Punjab", "Punjab & Haryana High Court"),
        CityItem("moga", "Moga", "Punjab", "Punjab & Haryana High Court"),
        CityItem("abohar", "Abohar", "Punjab", "Punjab & Haryana High Court"),
        CityItem("phagwara", "Phagwara", "Punjab", "Punjab & Haryana High Court"),
        CityItem("muktsar", "Muktsar", "Punjab", "Punjab & Haryana High Court"),
        CityItem("barnala", "Barnala", "Punjab", "Punjab & Haryana High Court"),
        CityItem("rajpura", "Rajpura", "Punjab", "Punjab & Haryana High Court"),
        CityItem("hoshiarpur", "Hoshiarpur", "Punjab", "Punjab & Haryana High Court"),
        CityItem("kapurthala", "Kapurthala", "Punjab", "Punjab & Haryana High Court"),
        CityItem("sangrur", "Sangrur", "Punjab", "Punjab & Haryana High Court"),
        CityItem("gurdaspur", "Gurdaspur", "Punjab", "Punjab & Haryana High Court"),
        CityItem("ropar", "Ropar", "Punjab", "Punjab & Haryana High Court"),

        // HARYANA
        CityItem("faridabad", "Faridabad", "Haryana", "Punjab & Haryana High Court"),
        CityItem("gurgaon", "Gurgaon", "Haryana", "Punjab & Haryana High Court"),
        CityItem("panipat", "Panipat", "Haryana", "Punjab & Haryana High Court"),
        CityItem("ambala", "Ambala", "Haryana", "Punjab & Haryana High Court"),
        CityItem("yamunanagar", "Yamunanagar", "Haryana", "Punjab & Haryana High Court"),
        CityItem("rohtak", "Rohtak", "Haryana", "Punjab & Haryana High Court"),
        CityItem("hisar", "Hisar", "Haryana", "Punjab & Haryana High Court"),
        CityItem("karnal", "Karnal", "Haryana", "Punjab & Haryana High Court"),
        CityItem("sonipat", "Sonipat", "Haryana", "Punjab & Haryana High Court"),
        CityItem("panchkula", "Panchkula", "Haryana", "Punjab & Haryana High Court"),
        CityItem("bhiwani", "Bhiwani", "Haryana", "Punjab & Haryana High Court"),
        CityItem("sirsa", "Sirsa", "Haryana", "Punjab & Haryana High Court"),
        CityItem("bahadurgarh", "Bahadurgarh", "Haryana", "Punjab & Haryana High Court"),
        CityItem("jind", "Jind", "Haryana", "Punjab & Haryana High Court"),
        CityItem("kaithal", "Kaithal", "Haryana", "Punjab & Haryana High Court"),
        CityItem("rewari", "Rewari", "Haryana", "Punjab & Haryana High Court"),
        CityItem("palwal", "Palwal", "Haryana", "Punjab & Haryana High Court"),
        CityItem("narnaul", "Narnaul", "Haryana", "Punjab & Haryana High Court"),
        CityItem("fatehabad", "Fatehabad", "Haryana", "Punjab & Haryana High Court"),
        CityItem("kurukshetra", "Kurukshetra", "Haryana", "Punjab & Haryana High Court"),

        // BIHAR
        CityItem("patna", "Patna", "Bihar", "Patna High Court"),
        CityItem("gaya", "Gaya", "Bihar", "Patna High Court"),
        CityItem("bhagalpur", "Bhagalpur", "Bihar", "Patna High Court"),
        CityItem("muzaffarpur", "Muzaffarpur", "Bihar", "Patna High Court"),
        CityItem("purnia", "Purnia", "Bihar", "Patna High Court"),
        CityItem("darbhanga", "Darbhanga", "Bihar", "Patna High Court"),
        CityItem("bihar_sharif", "Bihar Sharif", "Bihar", "Patna High Court"),
        CityItem("arrah", "Arrah", "Bihar", "Patna High Court"),
        CityItem("begusarai", "Begusarai", "Bihar", "Patna High Court"),
        CityItem("katihar", "Katihar", "Bihar", "Patna High Court"),
        CityItem("munger", "Munger", "Bihar", "Patna High Court"),
        CityItem("chhapra", "Chhapra", "Bihar", "Patna High Court"),
        CityItem("bettiah", "Bettiah", "Bihar", "Patna High Court"),
        CityItem("saharsa", "Saharsa", "Bihar", "Patna High Court"),
        CityItem("sasaram", "Sasaram", "Bihar", "Patna High Court"),
        CityItem("hajipur", "Hajipur", "Bihar", "Patna High Court"),
        CityItem("siwan", "Siwan", "Bihar", "Patna High Court"),
        CityItem("motihari", "Motihari", "Bihar", "Patna High Court"),
        CityItem("nawada", "Nawada", "Bihar", "Patna High Court"),
        CityItem("kishanganj", "Kishanganj", "Bihar", "Patna High Court"),

        // ODISHA
        CityItem("bhubaneswar", "Bhubaneswar", "Odisha", "Orissa High Court"),
        CityItem("cuttack", "Cuttack", "Odisha", "Orissa High Court"),
        CityItem("rourkela", "Rourkela", "Odisha", "Orissa High Court"),
        CityItem("berhampur", "Berhampur", "Odisha", "Orissa High Court"),
        CityItem("sambalpur", "Sambalpur", "Odisha", "Orissa High Court"),
        CityItem("puri", "Puri", "Odisha", "Orissa High Court"),
        CityItem("balasore", "Balasore", "Odisha", "Orissa High Court"),
        CityItem("bhadrak", "Bhadrak", "Odisha", "Orissa High Court"),
        CityItem("baripada", "Baripada", "Odisha", "Orissa High Court"),
        CityItem("jharsuguda", "Jharsuguda", "Odisha", "Orissa High Court"),
        CityItem("jeypore", "Jeypore", "Odisha", "Orissa High Court"),
        CityItem("bargarh", "Bargarh", "Odisha", "Orissa High Court"),
        CityItem("rayagada", "Rayagada", "Odisha", "Orissa High Court"),

        // KERALA
        CityItem("kochi", "Kochi", "Kerala", "Kerala High Court"),
        CityItem("thiruvananthapuram", "Thiruvananthapuram", "Kerala", "Kerala High Court"),
        CityItem("kozhikode", "Kozhikode", "Kerala", "Kerala High Court"),
        CityItem("thrissur", "Thrissur", "Kerala", "Kerala High Court"),
        CityItem("kollam", "Kollam", "Kerala", "Kerala High Court"),
        CityItem("palakkad", "Palakkad", "Kerala", "Kerala High Court"),
        CityItem("alappuzha", "Alappuzha", "Kerala", "Kerala High Court"),
        CityItem("malappuram", "Malappuram", "Kerala", "Kerala High Court"),
        CityItem("kannur", "Kannur", "Kerala", "Kerala High Court"),
        CityItem("kottayam", "Kottayam", "Kerala", "Kerala High Court"),
        CityItem("kasaragod", "Kasaragod", "Kerala", "Kerala High Court"),

        // JHARKHAND
        CityItem("ranchi", "Ranchi", "Jharkhand", "Jharkhand High Court"),
        CityItem("jamshedpur", "Jamshedpur", "Jharkhand", "Jharkhand High Court"),
        CityItem("dhanbad", "Dhanbad", "Jharkhand", "Jharkhand High Court"),
        CityItem("bokaro", "Bokaro Steel City", "Jharkhand", "Jharkhand High Court"),
        CityItem("deoghar", "Deoghar", "Jharkhand", "Jharkhand High Court"),
        CityItem("hazaribagh", "Hazaribagh", "Jharkhand", "Jharkhand High Court"),
        CityItem("giridih", "Giridih", "Jharkhand", "Jharkhand High Court"),
        CityItem("ramgarh", "Ramgarh", "Jharkhand", "Jharkhand High Court"),
        CityItem("chaibasa", "Chaibasa", "Jharkhand", "Jharkhand High Court"),

        // ASSAM
        CityItem("guwahati", "Guwahati", "Assam", "Gauhati High Court"),
        CityItem("silchar", "Silchar", "Assam", "Gauhati High Court"),
        CityItem("dibrugarh", "Dibrugarh", "Assam", "Gauhati High Court"),
        CityItem("nagaon", "Nagaon", "Assam", "Gauhati High Court"),
        CityItem("tinsukia", "Tinsukia", "Assam", "Gauhati High Court"),
        CityItem("jorhat", "Jorhat", "Assam", "Gauhati High Court"),
        CityItem("bongaigaon", "Bongaigaon", "Assam", "Gauhati High Court"),
        CityItem("tezpur", "Tezpur", "Assam", "Gauhati High Court"),
        CityItem("karimganj", "Karimganj", "Assam", "Gauhati High Court"),

        // CHHATTISGARH
        CityItem("raipur", "Raipur", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("bhilai", "Bhilai", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("bilaspur", "Bilaspur", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("korba", "Korba", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("durg", "Durg", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("rajnandgaon", "Rajnandgaon", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("raigarh", "Raigarh", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("jagdalpur", "Jagdalpur", "Chhattisgarh", "Chhattisgarh High Court"),
        CityItem("ambikapur", "Ambikapur", "Chhattisgarh", "Chhattisgarh High Court"),

        // CHANDIGARH
        CityItem("chandigarh", "Chandigarh", "Chandigarh", "Punjab & Haryana High Court"),

        // UTTARAKHAND
        CityItem("dehradun", "Dehradun", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("haridwar", "Haridwar", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("roorkee", "Roorkee", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("haldwani", "Haldwani", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("rudrapur", "Rudrapur", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("kashipur", "Kashipur", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("rishikesh", "Rishikesh", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("kotdwar", "Kotdwar", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("nainital", "Nainital", "Uttarakhand", "Uttarakhand High Court"),
        CityItem("mussoorie", "Mussoorie", "Uttarakhand", "Uttarakhand High Court"),

        // HIMACHAL PRADESH
        CityItem("shimla", "Shimla", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("mandi", "Mandi", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("solan", "Solan", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("dharamshala", "Dharamshala", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("palampur", "Palampur", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("baddi", "Baddi", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("nahan", "Nahan", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("hamirpur", "Hamirpur", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("kullu", "Kullu", "Himachal Pradesh", "Himachal Pradesh High Court"),
        CityItem("manali", "Manali", "Himachal Pradesh", "Himachal Pradesh High Court"),

        // GOA
        CityItem("panaji", "Panaji", "Goa", "Bombay High Court"),
        CityItem("margao", "Margao", "Goa", "Bombay High Court"),
        CityItem("vasco", "Vasco da Gama", "Goa", "Bombay High Court"),
        CityItem("mapusa", "Mapusa", "Goa", "Bombay High Court"),
        CityItem("ponda", "Ponda", "Goa", "Bombay High Court"),

        // JAMMU & KASHMIR
        CityItem("srinagar", "Srinagar", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("jammu", "Jammu", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("anantnag", "Anantnag", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("baramulla", "Baramulla", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("sopore", "Sopore", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("kathua", "Kathua", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("udhampur", "Udhampur", "Jammu & Kashmir", "Jammu & Kashmir High Court"),
        CityItem("leh", "Leh", "Jammu & Kashmir", "Jammu & Kashmir High Court"),

        // NORTHEAST
        CityItem("imphal", "Imphal", "Manipur", "Manipur High Court"),
        CityItem("agartala", "Agartala", "Tripura", "Tripura High Court"),
        CityItem("aizawl", "Aizawl", "Mizoram", "Gauhati High Court"),
        CityItem("kohima", "Kohima", "Nagaland", "Gauhati High Court"),
        CityItem("itanagar", "Itanagar", "Arunachal Pradesh", "Gauhati High Court"),
        CityItem("shillong", "Shillong", "Meghalaya", "Meghalaya High Court"),
        CityItem("gangtok", "Gangtok", "Sikkim", "Sikkim High Court"),
        CityItem("dimapur", "Dimapur", "Nagaland", "Gauhati High Court"),

        // OTHER UNION TERRITORIES
        CityItem("puducherry", "Puducherry", "Puducherry", "Madras High Court"),
        CityItem("port_blair", "Port Blair", "Andaman & Nicobar", "Calcutta High Court"),
        CityItem("daman", "Daman", "Daman & Diu", "Bombay High Court"),
        CityItem("silvassa", "Silvassa", "Dadra & Nagar Haveli", "Bombay High Court")
    )

    val states = listOf(
        "Delhi", "Maharashtra", "Karnataka", "Telangana", "Punjab", "Kerala", "Tamil Nadu", "West Bengal", "Gujarat",
        "Uttar Pradesh", "Rajasthan", "Bihar", "Haryana", "Andhra Pradesh", "Madhya Pradesh", "Goa", "Assam",
        "Jammu & Kashmir", "Jharkhand", "Chhattisgarh", "Uttarakhand", "Himachal Pradesh", "Odisha"
    )

    // Reactive filtered layers stream
    val filteredLawyers: StateFlow<List<LawyerEntity>> = combine(
        allLawyers,
        searchQuery,
        selectedCityFilter,
        selectedCategoryFilter,
        verifiedOnly,
        onlineOnly,
        sortOption,
        featuredLawyerIds
    ) { args ->
        val lawyers = args[0] as List<LawyerEntity>
        val query = args[1] as String
        val city = args[2] as String
        val category = args[3] as String
        val isVerified = args[4] as Boolean
        val isOnline = args[5] as Boolean
        val sort = args[6] as String
        val featuredIds = args[7] as Set<String>

        var list = lawyers.filter { it.isActive }

        // Apply Search query
        if (query.isNotEmpty()) {
            list = list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.specialisation.contains(query, ignoreCase = true) ||
                it.city.contains(query, ignoreCase = true) ||
                it.caseTypes.contains(query, ignoreCase = true) ||
                it.languages.contains(query, ignoreCase = true)
            }
        }

        // Apply City Filter
        if (city != "All") {
            list = list.filter { it.city.equals(city, ignoreCase = true) }
        }

        // Apply Category/Specialisation
        if (category != "All") {
            list = list.filter {
                it.specialisation.contains(category, ignoreCase = true) ||
                it.caseTypes.contains(category, ignoreCase = true)
            }
        }

        // Apply Badges
        if (isVerified) {
            list = list.filter { it.isVerified }
        }
        if (isOnline) {
            list = list.filter { it.isOnline }
        }

        // Sorting
        val sortedList = when (sort) {
            "Rating" -> list.sortedByDescending { it.rating }
            "Fees" -> list.sortedBy { it.consultationFee }
            "Experience" -> list.sortedByDescending { it.experienceYears }
            "Newest" -> list.sortedByDescending { it.createdAt }
            else -> list
        }
        sortedList.sortedByDescending { featuredIds.contains(it.uid) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun getReviewsForLawyer(lawyerId: String): Flow<List<ReviewEntity>> {
        return repository.getReviewsForLawyer(lawyerId)
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateCityFilter(city: String) {
        _selectedCityFilter.value = city
    }

    fun updateCategoryFilter(category: String) {
        _selectedCategoryFilter.value = category
    }

    fun toggleVerifiedOnly(verified: Boolean) {
        _verifiedOnly.value = verified
    }

    fun toggleOnlineOnly(online: Boolean) {
        _onlineOnly.value = online
    }

    fun updateSortOption(sort: String) {
        _sortOption.value = sort
    }

    fun selectLawyer(id: String?) {
        _selectedLawyerId.value = id
    }

    fun toggleFeatureLawyer(uid: String) {
        _featuredLawyerIds.value = if (_featuredLawyerIds.value.contains(uid)) {
            _featuredLawyerIds.value - uid
        } else {
            _featuredLawyerIds.value + uid
        }
    }

    fun sendAnnouncement(title: String, text: String, target: String) {
        val formatter = java.text.SimpleDateFormat("dd MMM, yyyy", java.util.Locale.getDefault())
        val dateStr = formatter.format(java.util.Date())
        val announcement = AnnouncementItem(
            title = title,
            text = text,
            target = target,
            dateString = dateStr
        )
        _announcements.value = listOf(announcement) + _announcements.value
    }

    fun updateLawyerVerification(uid: String, isVerified: Boolean) {
        viewModelScope.launch {
            repository.updateLawyerVerification(uid, isVerified)
        }
    }

    fun updateLawyerActiveStatus(uid: String, isActive: Boolean) {
        viewModelScope.launch {
            repository.updateLawyerActiveStatus(uid, isActive)
        }
    }

    fun updateUserActiveStatus(uid: String, isActive: Boolean) {
        viewModelScope.launch {
            repository.updateUserActiveStatus(uid, isActive)
        }
    }

    fun updateLawyerDetails(uid: String, name: String, specialisation: String, experienceYears: Int, consultationFee: Int, courtAppearanceFee: Int) {
        viewModelScope.launch {
            repository.updateLawyerDetails(uid, name, specialisation, experienceYears, consultationFee, courtAppearanceFee)
        }
    }

    fun deleteReviewByAdmin(reviewId: Int) {
        viewModelScope.launch {
            repository.deleteReview(reviewId)
        }
    }

    fun updateReviewVerificationByAdmin(reviewId: Int, isVerifiedClient: Boolean) {
        viewModelScope.launch {
            repository.updateReviewVerification(reviewId, isVerifiedClient)
        }
    }

    fun updateEmergencyStatusByAdmin(id: Int, isResolved: Boolean, assignedLawyerId: String?, assignedLawyerName: String?) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val query = database.getReference("emergencies").orderByChild("id").equalTo(id.toDouble())
                val snapshot = query.get().await()
                for (child in snapshot.children) {
                    val updates = mapOf<String, Any?>(
                        "isResolved" to isResolved,
                        "assignedLawyerId" to assignedLawyerId,
                        "assignedLawyerName" to assignedLawyerName
                    )
                    child.ref.updateChildren(updates).await()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            repository.updateEmergencyStatus(id, isResolved, assignedLawyerId, assignedLawyerName)
        }
    }

    // Advanced Admin & OTP Helper Functions

    fun deleteAccountByAdmin(uid: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                database.getReference("users").child(uid).removeValue().await()
                database.getReference("lawyers").child(uid).removeValue().await()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            repository.deleteUserAndProfile(uid)
        }
    }

    fun fetchBlacklist() {
        viewModelScope.launch {
            try {
                val database = getDb()
                val snapshot = database.getReference("blacklist").get().await()
                val list = snapshot.children.map { doc ->
                    mapOf(
                        "id" to doc.id,
                        "email" to (doc.getString("email") ?: ""),
                        "phone" to (doc.getString("phone") ?: ""),
                        "createdAt" to (doc.getLong("createdAt") ?: System.currentTimeMillis())
                    )
                }
                _blacklist.value = list
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addToBlacklist(email: String, phone: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val data = hashMapOf(
                    "email" to email.trim().lowercase(),
                    "phone" to phone.trim(),
                    "createdAt" to System.currentTimeMillis()
                )
                val docId = if (email.isNotEmpty()) email.trim().lowercase().toSafeKey() else phone.trim().toSafeKey()
                if (docId.isNotEmpty()) {
                    database.getReference("blacklist").child(docId).setValue(data).await()
                    fetchBlacklist()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun removeFromBlacklist(id: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                database.getReference("blacklist").child(id).removeValue().await()
                fetchBlacklist()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun isBlacklisted(email: String, phone: String): Boolean {
        return try {
            val database = getDb()
            val emailClean = email.trim().lowercase()
            val phoneClean = phone.trim()
            if (emailClean.isNotEmpty()) {
                val docEmail = database.getReference("blacklist").child(emailClean.toSafeKey()).get().await()
                if (docEmail.exists()) return true
            }
            if (phoneClean.isNotEmpty()) {
                val docPhone = database.getReference("blacklist").child(phoneClean.toSafeKey()).get().await()
                if (docPhone.exists()) return true
            }
            val qEmail = database.getReference("blacklist").orderByChild("email").equalTo(emailClean).get().await()
            if (!qEmail.isEmpty) return true
            val qPhone = database.getReference("blacklist").orderByChild("phone").equalTo(phoneClean).get().await()
            if (!qPhone.isEmpty) return true
            false
        } catch (e: java.lang.Exception) {
            false
        }
    }

    fun rejectLawyerProfile(uid: String, reason: String, customNote: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val finalReason = if (customNote.isNotEmpty()) "$reason - $customNote" else reason
                val updates = mapOf<String, Any>(
                    "isVerified" to false,
                    "rejectionReason" to finalReason
                )
                database.getReference("lawyers").child(uid).updateChildren(updates).await()
                _rejectionReasons.value = _rejectionReasons.value + (uid to finalReason)
                repository.updateLawyerVerification(uid, false)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun suspendUser(uid: String, durationDays: Int, reason: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val durationMs = durationDays.toLong() * 24 * 60 * 60 * 1000
                val suspendedUntil = System.currentTimeMillis() + durationMs
                val updates = mapOf<String, Any>(
                    "suspendedUntil" to suspendedUntil,
                    "suspensionReason" to reason,
                    "isActive" to false
                )
                database.getReference("users").child(uid).updateChildren(updates).await()
                repository.updateUserActiveStatus(uid, false)
                _suspensions.value = _suspensions.value + (uid to Triple(suspendedUntil, reason, true))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun unsuspendUser(uid: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val updates = mapOf<String, Any>(
                    "suspendedUntil" to 0L,
                    "suspensionReason" to "",
                    "isActive" to true
                )
                database.getReference("users").child(uid).updateChildren(updates).await()
                repository.updateUserActiveStatus(uid, true)
                _suspensions.value = _suspensions.value - uid
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addAdminNote(uid: String, note: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val docRef = database.getReference("users").child(uid)
                val doc = docRef.get().await()
                val currentNotes = (doc.get("adminNotes") as? List<*>)?.map { it.toString() } ?: emptyList()
                val updatedNotes = currentNotes + note
                docRef.child("adminNotes").setValue(updatedNotes).await()
                _adminNotes.value = _adminNotes.value + (uid to updatedNotes)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun fetchAdminNotes(uid: String) {
        viewModelScope.launch {
            try {
                val database = getDb()
                val doc = database.getReference("users").child(uid).get().await()
                val notes = (doc.get("adminNotes") as? List<*>)?.map { it.toString() } ?: emptyList()
                _adminNotes.value = _adminNotes.value + (uid to notes)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // OTP Flow
    fun sendOtp(phone: String, onVerified: () -> Unit) {
        val currentState = _otpState.value
        if (currentState != null && currentState.lockedUntil > System.currentTimeMillis()) {
            val mins = ((currentState.lockedUntil - System.currentTimeMillis()) / 60000) + 1
            throw Exception("Mobile verification locked. Try again in $mins minutes.")
        }
        val generatedOtp = (100000..999999).random().toString()
        android.util.Log.e("LOBBY_OTP", "---------------------------------------------")
        android.util.Log.e("LOBBY_OTP", "SECURITY VERIFICATION SMS OTP: $generatedOtp")
        android.util.Log.e("LOBBY_OTP", "---------------------------------------------")
        _otpState.value = OtpSessionState(
            phone = phone,
            correctOtp = generatedOtp,
            attemptsLeft = 3,
            expiresAt = System.currentTimeMillis() + 5 * 60 * 1000,
            onVerified = onVerified
        )
    }

    fun verifyOtp(enteredOtp: String): Boolean {
        val state = _otpState.value ?: throw Exception("Session expired or inactive.")
        if (state.lockedUntil > System.currentTimeMillis()) {
            val mins = ((state.lockedUntil - System.currentTimeMillis()) / 60000) + 1
            throw Exception("Verification locked. Try again in $mins minutes.")
        }
        if (System.currentTimeMillis() > state.expiresAt) {
            _otpState.value = null
            throw Exception("OTP expired. Resend a new OTP.")
        }
        if (enteredOtp == state.correctOtp) {
            state.onVerified()
            _otpState.value = null
            return true
        } else {
            val nextAttempts = state.attemptsLeft - 1
            if (nextAttempts <= 0) {
                _otpState.value = state.copy(
                    attemptsLeft = 0,
                    lockedUntil = System.currentTimeMillis() + 60 * 60 * 1000
                )
                throw Exception("Locked for 1 hour due to maximum verification attempts.")
            } else {
                _otpState.value = state.copy(attemptsLeft = nextAttempts)
                throw Exception("Incorrect verification code. $nextAttempts trials remaining.")
            }
        }
    }

    fun cancelOtp() {
        _otpState.value = null
    }

    fun resendVerificationEmail(email: String) {
        viewModelScope.launch {
            try {
                val auth = FirebaseAuth.getInstance()
                val user = auth.currentUser
                if (user != null && user.email == email) {
                    user.sendEmailVerification().await()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Auth
    suspend fun signin(email: String, password: String, role: String): Boolean {
        try {
            val auth = FirebaseAuth.getInstance()
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val firebaseUser = authResult.user ?: return false
            val uid = firebaseUser.uid

            val emailClean = email.trim().lowercase()
            val isMockAdmin = emailClean == "baazsingh232023@gmail.com" || emailClean == "admin@lawyerslobby.in"

            if (!isMockAdmin && !firebaseUser.isEmailVerified) {
                throw Exception("EMAIL_NOT_VERIFIED: Your account email is not verified. Please check your inbox and verify before logging in.")
            }

            val database = getDb()
            val userDoc = database.getReference("users").child(uid).get().await()

            if (userDoc.exists()) {
                val suspendedUntil = userDoc.getLong("suspendedUntil") ?: 0L
                if (suspendedUntil > System.currentTimeMillis()) {
                    val reason = userDoc.getString("suspensionReason") ?: "Policy violation"
                    val dateFormatted = java.text.SimpleDateFormat("dd MMM, yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(suspendedUntil))
                    throw Exception("Your account is temporarily suspended until $dateFormatted. Reason: $reason")
                }

                val dbRole = userDoc.getString("role") ?: "client"
                if (dbRole != role) {
                    throw Exception("Signed in successfully, but incorrect role selected! Please select correct role.")
                }

                val user = UserEntity(
                    uid = uid,
                    name = userDoc.getString("name") ?: (userDoc.getString("firstName") ?: "") + " " + (userDoc.getString("lastName") ?: ""),
                    email = userDoc.getString("email") ?: email,
                    phone = userDoc.getString("phone") ?: "",
                    city = userDoc.getString("city") ?: "New Delhi",
                    state = userDoc.getString("state") ?: "Delhi",
                    role = dbRole,
                    profilePhoto = userDoc.getString("profilePhoto") ?: "",
                    createdAt = userDoc.getLong("createdAt") ?: System.currentTimeMillis(),
                    isActive = userDoc.getBoolean("isActive") ?: true
                )

                repository.insertUser(user)

                if (dbRole == "lawyer") {
                    try {
                        val lawyerDoc = database.getReference("lawyers").child(uid).get().await()
                        if (lawyerDoc.exists()) {
                            val lawyer = LawyerEntity(
                                uid = uid,
                                name = lawyerDoc.getString("name") ?: user.name,
                                email = lawyerDoc.getString("email") ?: user.email,
                                phone = lawyerDoc.getString("phone") ?: user.phone,
                                city = lawyerDoc.getString("city") ?: user.city,
                                state = lawyerDoc.getString("state") ?: user.state,
                                barCouncilNumber = lawyerDoc.getString("barCouncilNumber") ?: "",
                                experienceYears = lawyerDoc.getLong("experienceYears")?.toInt() ?: 5,
                                consultationFee = lawyerDoc.getLong("consultationFee")?.toInt() ?: 1000,
                                courtAppearanceFee = lawyerDoc.getLong("courtAppearanceFee")?.toInt() ?: 5000,
                                specialisation = lawyerDoc.getString("specialisation") ?: "General",
                                caseTypes = lawyerDoc.getString("caseTypes") ?: "",
                                languages = lawyerDoc.getString("languages") ?: "Hindi, English",
                                about = lawyerDoc.getString("about") ?: "",
                                officeAddress = lawyerDoc.getString("officeAddress") ?: "",
                                workingHours = lawyerDoc.getString("workingHours") ?: "10:00 AM - 06:00 PM (Mon-Sat)",
                                profilePhoto = lawyerDoc.getString("profilePhoto") ?: user.profilePhoto,
                                officePhotos = lawyerDoc.getString("officePhotos") ?: "",
                                isVerified = lawyerDoc.getBoolean("isVerified") ?: false,
                                isOnline = lawyerDoc.getBoolean("isOnline") ?: true,
                                rating = lawyerDoc.getDouble("rating")?.toFloat() ?: 5.0f,
                                totalReviews = lawyerDoc.getLong("totalReviews")?.toInt() ?: 0,
                                totalCasesWon = lawyerDoc.getLong("totalCasesWon")?.toInt() ?: 0,
                                linkedInUrl = lawyerDoc.getString("linkedInUrl") ?: "",
                                googleProfileUrl = lawyerDoc.getString("googleProfileUrl") ?: "",
                                isActive = lawyerDoc.getBoolean("isActive") ?: true,
                                createdAt = lawyerDoc.getLong("createdAt") ?: System.currentTimeMillis()
                            )
                            repository.registerLawyer(user, lawyer)
                        } else {
                            repository.insertUser(user)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        repository.insertUser(user)
                    }
                } else {
                    repository.setCurrentUser(user)
                }
                return true
            } else {
                val user = UserEntity(
                    uid = uid,
                    name = email.substringBefore("@"),
                    email = email,
                    phone = "",
                    city = "New Delhi",
                    state = "Delhi",
                    role = role,
                    profilePhoto = "",
                    createdAt = System.currentTimeMillis(),
                    isActive = true
                )
                val userMap = hashMapOf(
                    "uid" to uid,
                    "name" to user.name,
                    "email" to user.email,
                    "phone" to user.phone,
                    "city" to user.city,
                    "state" to user.state,
                    "role" to user.role,
                    "profilePhoto" to user.profilePhoto,
                    "createdAt" to user.createdAt,
                    "isActive" to user.isActive
                )
                database.getReference("users").child(uid).setValue(userMap).await()
                repository.insertUser(user)
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            val emailClean = email.trim().lowercase()
            val isAdminEmail = emailClean == "admin@lawyerslobby.in" || emailClean == "baazsingh232023@gmail.com"
            if (isAdminEmail) {
                try {
                    val auth = FirebaseAuth.getInstance()
                    val authResult = auth.createUserWithEmailAndPassword(email, password).await()
                    val firebaseUser = authResult.user
                    if (firebaseUser != null) {
                        val uid = firebaseUser.uid
                        val database = getDb()
                        val name = if (emailClean == "baazsingh232023@gmail.com") "Baaz Singh (Admin)" else "Super Admin"
                        val user = UserEntity(
                            uid = uid,
                            name = name,
                            email = emailClean,
                            phone = "+919999999999",
                            city = "New Delhi",
                            state = "Delhi",
                            role = "client",
                            profilePhoto = "",
                            createdAt = System.currentTimeMillis(),
                            isActive = true
                        )
                        val userMap = hashMapOf(
                            "uid" to uid,
                            "name" to user.name,
                            "email" to user.email,
                            "phone" to user.phone,
                            "city" to user.city,
                            "state" to user.state,
                            "role" to user.role,
                            "profilePhoto" to user.profilePhoto,
                            "createdAt" to user.createdAt,
                            "isActive" to user.isActive
                        )
                        database.getReference("users").child(uid).setValue(userMap).await()
                        repository.insertUser(user)
                        return true
                    }
                } catch (registerEx: Exception) {
                    registerEx.printStackTrace()
                }
            }
            throw e
        }
    }

    private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T = suspendCancellableCoroutine { continuation ->
        addOnCompleteListener { task ->
            if (task.isSuccessful) {
                continuation.resume(task.result)
            } else {
                continuation.resumeWithException(task.exception ?: Exception("Firebase Task failed"))
            }
        }
    }

    fun logout() {
        repository.logout()
    }

    val currentLawyer: StateFlow<LawyerEntity?> = combine(currentUser, allLawyers) { user, lawyers ->
        if (user?.role == "lawyer") {
            lawyers.find { it.uid == user.uid }
        } else {
            null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun updateProfile(
        name: String,
        phone: String,
        city: String,
        barCouncilNumber: String? = null,
        specialisation: String? = null,
        consultationFee: Int? = null,
        languages: String? = null
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val resolvedState = cities.find { it.cityName.equals(city, ignoreCase = true) }?.state ?: user.state
            val updatedUser = user.copy(name = name, phone = phone, city = city, state = resolvedState)
            repository.insertUser(updatedUser)

            if (user.role == "lawyer") {
                val currentLawyerObj = allLawyers.value.find { it.uid == user.uid }
                if (currentLawyerObj != null) {
                    val updatedLawyer = currentLawyerObj.copy(
                        name = name,
                        phone = phone,
                        city = city,
                        state = resolvedState,
                        barCouncilNumber = barCouncilNumber ?: currentLawyerObj.barCouncilNumber,
                        specialisation = specialisation ?: currentLawyerObj.specialisation,
                        consultationFee = consultationFee ?: currentLawyerObj.consultationFee,
                        languages = languages ?: currentLawyerObj.languages
                    )
                    repository.registerLawyer(updatedUser, updatedLawyer)
                }
            }
        }
    }

    fun updateProfilePhoto(photoPath: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val updatedUser = user.copy(profilePhoto = photoPath)
            repository.insertUser(updatedUser)

            if (user.role == "lawyer") {
                val currentLawyerObj = allLawyers.value.find { it.uid == user.uid }
                if (currentLawyerObj != null) {
                    val updatedLawyer = currentLawyerObj.copy(profilePhoto = photoPath)
                    repository.registerLawyer(updatedUser, updatedLawyer)
                }
            }
        }
    }

    fun addOfficePhoto(photoPath: String) {
        val user = currentUser.value ?: return
        if (user.role != "lawyer") return
        viewModelScope.launch {
            val currentLawyerObj = allLawyers.value.find { it.uid == user.uid } ?: return@launch
            val existingPhotos = if (currentLawyerObj.officePhotos.isEmpty()) {
                emptyList()
            } else {
                currentLawyerObj.officePhotos.split(",")
            }
            if (existingPhotos.size < 5) {
                val updatedList = existingPhotos + photoPath
                val updatedLawyer = currentLawyerObj.copy(officePhotos = updatedList.joinToString(","))
                repository.registerLawyer(user, updatedLawyer)
            }
        }
    }

    fun removeOfficePhoto(photoPath: String) {
        val user = currentUser.value ?: return
        if (user.role != "lawyer") return
        viewModelScope.launch {
            val currentLawyerObj = allLawyers.value.find { it.uid == user.uid } ?: return@launch
            val existingPhotos = if (currentLawyerObj.officePhotos.isEmpty()) {
                emptyList()
            } else {
                currentLawyerObj.officePhotos.split(",")
            }
            val updatedList = existingPhotos.filter { it != photoPath }
            val updatedLawyer = currentLawyerObj.copy(officePhotos = updatedList.joinToString(","))
            repository.registerLawyer(user, updatedLawyer)
        }
    }

    // Ongoing cases flow & operations
    private val _ongoingCases = MutableStateFlow<List<LegalCase>>(
        listOf(
            LegalCase("1", "Aarav Sharma", "Property Dispute (BNS Sec 324)", "2026-05-12", "Active"),
            LegalCase("2", "Sunita Verma", "Cheque Bounce (NI Act Sec 138)", "2026-04-28", "Active"),
            LegalCase("3", "Rohan Gupta", "Mutual Divorce Mediation", "2026-03-15", "Closed")
        )
    )
    val ongoingCases: StateFlow<List<LegalCase>> = _ongoingCases.asStateFlow()

    fun addOngoingCase(clientName: String, caseType: String, date: String, status: String) {
        val newCase = LegalCase(
            id = System.currentTimeMillis().toString(),
            clientName = clientName,
            caseType = caseType,
            date = date,
            status = status
        )
        _ongoingCases.value = _ongoingCases.value + newCase
    }

    fun toggleCaseStatus(caseId: String) {
        _ongoingCases.value = _ongoingCases.value.map {
            if (it.id == caseId) {
                it.copy(status = if (it.status == "Active") "Closed" else "Active")
            } else {
                it
            }
        }
    }

    fun deleteCase(caseId: String) {
        _ongoingCases.value = _ongoingCases.value.filter { it.id != caseId }
    }

    // Stored payment keys flow & operations
    private val _paymentKeys = MutableStateFlow<List<PaymentKey>>(
        listOf(
            PaymentKey("1", "UPI", "Primary Chambers UPI ID", "advocate.sharma@paytm"),
            PaymentKey("2", "UPI", "Alternative Office Axis Pay", "sharma.associates@okaxis"),
            PaymentKey("3", "Card", "ICICI Corporate Visa Debit", "•••• •••• •••• 9823")
        )
    )
    val paymentKeys: StateFlow<List<PaymentKey>> = _paymentKeys.asStateFlow()

    fun addPaymentKey(type: String, label: String, value: String) {
        val newKey = PaymentKey(
            id = System.currentTimeMillis().toString(),
            type = type,
            label = label,
            value = value
        )
        _paymentKeys.value = _paymentKeys.value + newKey
    }

    fun deletePaymentKey(id: String) {
        _paymentKeys.value = _paymentKeys.value.filter { it.id != id }
    }

    // Permissions toggles states
    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _locationEnabled = MutableStateFlow(true)
    val locationEnabled: StateFlow<Boolean> = _locationEnabled.asStateFlow()

    private val _cameraEnabled = MutableStateFlow(false)
    val cameraEnabled: StateFlow<Boolean> = _cameraEnabled.asStateFlow()

    fun toggleNotificationPermission() {
        _notificationsEnabled.value = !_notificationsEnabled.value
    }

    fun toggleLocationPermission() {
        _locationEnabled.value = !_locationEnabled.value
    }

    fun toggleCameraPermission() {
        _cameraEnabled.value = !_cameraEnabled.value
    }

    suspend fun registerClient(firstName: String, lastName: String, email: String, phone: String, city: String, password: String) {
        if (isBlacklisted(email, phone)) {
            throw Exception("This account has been permanently banned from Lawyer's Lobby. Contact support.")
        }

        val auth = FirebaseAuth.getInstance()
        val authResult = auth.createUserWithEmailAndPassword(email, password).await()
        val firebaseUser = authResult.user ?: throw Exception("Auth user creation failed")
        val uid = firebaseUser.uid

        try {
            firebaseUser.sendEmailVerification().await()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val user = UserEntity(
            uid = uid,
            name = "$firstName $lastName".trim(),
            email = email,
            phone = phone,
            city = city,
            state = cities.find { it.cityName.equals(city, ignoreCase = true) }?.state ?: "Delhi",
            role = "client"
        )

        // Save on Database "users" node
        val database = getDb()
        val userMap = hashMapOf(
            "uid" to uid,
            "name" to user.name,
            "email" to user.email,
            "phone" to user.phone,
            "city" to user.city,
            "state" to user.state,
            "role" to user.role,
            "profilePhoto" to user.profilePhoto,
            "createdAt" to user.createdAt,
            "isActive" to user.isActive
        )
        database.getReference("users").child(uid).setValue(userMap).await()

        // Insert in local Room database and update current user session
        repository.insertUser(user)
    }

    suspend fun registerLawyerProfile(
        name: String,
        email: String,
        phone: String,
        city: String,
        state: String,
        barCouncil: String,
        experience: Int,
        consultationFee: Int,
        appearanceFee: Int,
        specialisation: String,
        caseTypes: List<String>,
        languages: List<String>,
        onlineConsult: Boolean,
        about: String,
        linkedin: String,
        googleBusiness: String,
        photoPath: String = "",
        password: String
    ) {
        if (isBlacklisted(email, phone)) {
            throw Exception("This account has been permanently banned from Lawyer's Lobby. Contact support.")
        }

        val auth = FirebaseAuth.getInstance()
        val authResult = auth.createUserWithEmailAndPassword(email, password).await()
        val firebaseUser = authResult.user ?: throw Exception("Auth user creation failed")
        val uid = firebaseUser.uid

        try {
            firebaseUser.sendEmailVerification().await()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val user = UserEntity(
            uid = uid,
            name = name,
            email = email,
            phone = phone,
            city = city,
            state = state,
            role = "lawyer",
            profilePhoto = photoPath
        )
        val lawyer = LawyerEntity(
            uid = uid,
            name = name,
            email = email,
            phone = phone,
            city = city,
            state = state,
            barCouncilNumber = barCouncil,
            experienceYears = experience,
            consultationFee = consultationFee,
            courtAppearanceFee = appearanceFee,
            specialisation = specialisation,
            caseTypes = caseTypes.joinToString(", "),
            languages = languages.joinToString(", "),
            isOnline = onlineConsult,
            about = about,
            officeAddress = "Chamber Suite, Old Courts Complex, $city - near District HQ",
            profilePhoto = photoPath,
            isVerified = false, // starts unverified, pending 24hr process
            rating = 5.0f,
            totalReviews = 0,
            totalCasesWon = 0,
            linkedInUrl = linkedin,
            googleProfileUrl = googleBusiness,
            createdAt = System.currentTimeMillis()
        )

        // Save maps on Database
        val database = getDb()

        val userMap = hashMapOf(
            "uid" to uid,
            "name" to user.name,
            "email" to user.email,
            "phone" to user.phone,
            "city" to user.city,
            "state" to user.state,
            "role" to user.role,
            "profilePhoto" to user.profilePhoto,
            "createdAt" to user.createdAt,
            "isActive" to user.isActive
        )

        val lawyerMap = hashMapOf(
            "uid" to lawyer.uid,
            "name" to lawyer.name,
            "email" to lawyer.email,
            "phone" to lawyer.phone,
            "city" to lawyer.city,
            "state" to lawyer.state,
            "barCouncilNumber" to lawyer.barCouncilNumber,
            "experienceYears" to lawyer.experienceYears,
            "consultationFee" to lawyer.consultationFee,
            "courtAppearanceFee" to lawyer.courtAppearanceFee,
            "specialisation" to lawyer.specialisation,
            "caseTypes" to lawyer.caseTypes,
            "languages" to lawyer.languages,
            "isOnline" to lawyer.isOnline,
            "about" to lawyer.about,
            "officeAddress" to lawyer.officeAddress,
            "profilePhoto" to lawyer.profilePhoto,
            "isVerified" to lawyer.isVerified,
            "rating" to lawyer.rating,
            "totalReviews" to lawyer.totalReviews,
            "totalCasesWon" to lawyer.totalCasesWon,
            "linkedInUrl" to lawyer.linkedInUrl,
            "googleProfileUrl" to lawyer.googleProfileUrl,
            "createdAt" to lawyer.createdAt,
            "isActive" to lawyer.isActive
        )

        // Write user to "users" node and lawyer to "lawyers" node in database
        database.getReference("users").child(uid).setValue(userMap).await()
        database.getReference("lawyers").child(uid).setValue(lawyerMap).await()

        // Insert in local Room database and update current user session
        repository.registerLawyer(user, lawyer)
    }

    suspend fun submitReview(lawyerId: String, clientName: String, rating: Int, text: String, caseType: String) {
        val user = currentUser.value
        val database = getDb()
        val ref = database.getReference("reviews").push()
        val reviewIdStr = ref.key ?: System.currentTimeMillis().toString()
        val reviewIdHash = (reviewIdStr.hashCode() and 0xfffffff)
        val reviewMap = hashMapOf(
            "reviewId" to reviewIdHash,
            "lawyerId" to lawyerId,
            "clientId" to (user?.uid ?: "anonymous_client"),
            "clientName" to clientName.ifEmpty { user?.name ?: "Verified Client" },
            "rating" to rating,
            "reviewText" to text,
            "caseType" to caseType,
            "isVerifiedClient" to true,
            "createdAt" to System.currentTimeMillis(),
            "isVisible" to true
        )
        try {
            ref.setValue(reviewMap).await()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val review = ReviewEntity(
            reviewId = reviewIdHash,
            lawyerId = lawyerId,
            clientId = user?.uid ?: "anonymous_client",
            clientName = clientName.ifEmpty { user?.name ?: "Verified Client" },
            rating = rating,
            reviewText = text,
            caseType = caseType,
            isVerifiedClient = true
        )
        repository.insertReview(review)
    }

    suspend fun payChalan(paymentType: String, state: String, courtOrCase: String, amount: Double, name: String, phone: String, method: String) {
        val user = currentUser.value
        val chalan = ChalanEntity(
            userId = user?.uid ?: "anonymous_payee",
            paymentType = paymentType,
            state = state,
            courtNameOrCaseNumber = courtOrCase,
            amount = amount,
            status = "completed",
            paymentMethod = method,
            userName = name,
            contactNumber = phone
        )
        repository.insertChalan(chalan)
    }

    suspend fun submitEmergencyRequest(name: String, phone: String, city: String, type: String, description: String) {
        val database = getDb()
        val ref = database.getReference("emergencies").push()
        val key = ref.key ?: System.currentTimeMillis().toString()
        val localId = (key.hashCode() and 0xfffffff)
        val emergMap = hashMapOf(
            "id" to localId,
            "name" to name,
            "phone" to phone,
            "city" to city,
            "emergencyType" to type,
            "description" to description,
            "createdAt" to System.currentTimeMillis(),
            "isResolved" to false,
            "assignedLawyerId" to null,
            "assignedLawyerName" to null
        )
        try {
            ref.setValue(emergMap).await()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val request = EmergencyRequestEntity(
            id = localId,
            name = name,
            phone = phone,
            city = city,
            emergencyType = type,
            description = description,
            isResolved = false,
            assignedLawyerId = null,
            assignedLawyerName = null
        )
        repository.insertEmergencyRequest(request)
    }

    // =================================================================
    // AUTOMATED AI CHATBOT STATES & METHODS
    // =================================================================
    private val _chatMessages = MutableStateFlow<List<Pair<String, Boolean>>>(
        listOf(
            "Namaste! I am NyayaMitra, your premium AI Legal Companion. How can I assist you with Indian law, court procedures, or finding the right advocate today?" to false
        )
    )
    val chatMessages: StateFlow<List<Pair<String, Boolean>>> = _chatMessages

    private val _isSendingMessage = MutableStateFlow(false)
    val isSendingMessage: StateFlow<Boolean> = _isSendingMessage

    fun initGreetings(user: UserEntity?) {
        val isLawyerMode = user?.role == "lawyer"
        val greeting = if (isLawyerMode) {
            "Greetings Advocate ${user?.name ?: "Counsel"}! 🏛️ I am NyayaCopilot, your high-end AI Law Advisor. I can help you research procedural frameworks under the BNSS, parse BNS details, or draft contract clauses. How may I assist your litigation preparation today?" to false
        } else {
            "Namaste ${user?.name ?: "Citizen"}! 🙏 I am NyayaMitra, your empathetic pre-litigation guide. Please describe your case or dispute (e.g., 'need mutual divorce advice', 'landlord dispute', or 'fake legal notice issue') and I will explain your legal rights and match you with verified advocates." to false
        }
        _chatMessages.value = listOf(greeting)
    }

    fun sendChatMessage(text: String, isLawyerMode: Boolean) {
        val prompt = text.trim()
        if (prompt.isEmpty()) return
        
        val currentList = _chatMessages.value.toMutableList()
        currentList.add(prompt to true)
        _chatMessages.value = currentList

        viewModelScope.launch {
            _isSendingMessage.value = true
            try {
                val response = GeminiService.generateResponse(
                    prompt = prompt,
                    isLawyerMode = isLawyerMode,
                    chatHistory = currentList.dropLast(1),
                    lawyers = allLawyers.value
                )
                val updatedList = _chatMessages.value.toMutableList()
                updatedList.add(response to false)
                _chatMessages.value = updatedList
            } catch (e: Exception) {
                val updatedList = _chatMessages.value.toMutableList()
                updatedList.add("Connection latency occurred. Please try again soon." to false)
                _chatMessages.value = updatedList
            } finally {
                _isSendingMessage.value = false
            }
        }
    }

    fun clearChatHistory(isLawyerMode: Boolean) {
        val user = currentUser.value
        initGreetings(user)
    }
}

private fun String.toSafeKey(): String {
    return this.replace(".", ",")
               .replace("#", "_")
               .replace("$", "_")
               .replace("[", "_")
               .replace("]", "_")
}

private fun com.google.firebase.database.DataSnapshot.getString(path: String): String? =
    child(path).getValue(String::class.java)

private fun com.google.firebase.database.DataSnapshot.getLong(path: String): Long? =
    child(path).getValue(Long::class.java)

private fun com.google.firebase.database.DataSnapshot.getBoolean(path: String): Boolean? =
    child(path).getValue(Boolean::class.java)

private fun com.google.firebase.database.DataSnapshot.getDouble(path: String): Double? =
    child(path).getValue(Double::class.java)

private fun com.google.firebase.database.DataSnapshot.get(path: String): Any? =
    child(path).value

private val com.google.firebase.database.DataSnapshot.id: String
    get() = key ?: ""

private val com.google.firebase.database.DataSnapshot.isEmpty: Boolean
    get() = !exists() || childrenCount == 0L
