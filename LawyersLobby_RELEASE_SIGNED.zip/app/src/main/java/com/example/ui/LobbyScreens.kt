package com.example.ui

import com.example.data.AnalyticsHelper
import android.content.Intent
import android.net.Uri
import coil.compose.AsyncImage
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.activity.compose.BackHandler
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// =================================================================
// IMAGE SELECTION & PERSISTENCE HELPER UTILITIES
// =================================================================
fun createTargetFileUri(context: Context): Pair<File, Uri> {
    val fileName = "profile_photo_${System.currentTimeMillis()}.jpg"
    val file = File(context.filesDir, fileName)
    val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file
    )
    return Pair(file, uri)
}

fun saveUriToInternalStorage(context: Context, uri: Uri): String {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return ""
        val fileName = "profile_photo_${System.currentTimeMillis()}.jpg"
        val destFile = File(context.filesDir, fileName)
        destFile.outputStream().use { output ->
            inputStream.use { input ->
                input.copyTo(output)
            }
        }
        destFile.absolutePath
    } catch (e: Exception) {
        e.printStackTrace()
        ""
    }
}

@Composable
fun PhotoSourceBottomSheet(
    onDismissRequest: () -> Unit,
    onTakePhoto: () -> Unit,
    onChooseGallery: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable { onDismissRequest() }
                .background(Color.Black.copy(alpha = 0.4f)),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = false) {}
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                    )
                    .padding(24.dp)
                    .navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Drag handle bar
                Box(
                    modifier = Modifier
                        .size(40.dp, 4.dp)
                        .background(Color.LightGray, RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = "Select Profile Photo",
                    color = NavyBlue,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(20.dp))
                
                // Option 1: Take Photo
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onTakePhoto()
                            onDismissRequest()
                        }
                        .padding(vertical = 14.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(WarmCream, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Take Photo",
                            tint = SaffronOrange,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "📷 Take Photo (Camera)",
                        color = NavyBlue,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
                
                // Option 2: Choose Gallery
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onChooseGallery()
                            onDismissRequest()
                        }
                        .padding(vertical = 14.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(WarmCream, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Choose Gallery",
                            tint = SaffronOrange,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "🖼️ Choose from Gallery",
                        color = NavyBlue,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Cancel
                OutlinedButton(
                    onClick = onDismissRequest,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancel", color = NavyBlue, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// =================================================================
// DECORATION UTILITIES
// =================================================================

@Composable
fun TricolorStripe(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(5.dp)
    ) {
        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(SaffronOrange))
        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color.White))
        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(IndiaGreen))
    }
}

// =================================================================
// REUSABLE SEARCHABLE DROP-DOWN FOR INDIAN CITIES
// =================================================================
@Composable
fun SearchableCityDropdown(
    label: String,
    selectedCity: String,
    onCitySelected: (String) -> Unit,
    cities: List<String>,
    modifier: Modifier = Modifier,
    isDarkTheme: Boolean = false
) {
    var showDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        OutlinedTextField(
            value = selectedCity,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, color = if (isDarkTheme) Color.White else NavyBlue) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = if (isDarkTheme) Color.White else NavyBlue) },
            colors = OutlinedTextFieldDefaults.colors(
                disabledTextColor = if (isDarkTheme) Color.White else NavyBlue,
                disabledBorderColor = if (isDarkTheme) Color.LightGray else Color.Gray,
                disabledLabelColor = if (isDarkTheme) Color.LightGray else NavyBlue,
                disabledTrailingIconColor = if (isDarkTheme) Color.White else NavyBlue
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDialog = true },
            shape = RoundedCornerShape(8.dp),
            enabled = false
        )
        // Cover container clickable overlay
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable { showDialog = true }
        )
    }

    if (showDialog) {
        var searchQuery by remember { mutableStateOf("") }
        val filteredCities = remember(searchQuery, cities) {
            if (searchQuery.isBlank()) {
                cities
            } else {
                cities.filter { it.contains(searchQuery, ignoreCase = true) }
            }
        }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Column {
                    Text(
                        text = "Select Indian City",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = NavyBlue
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search city (e.g. Pune)") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyBlue) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = NavyBlue)
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = NavyBlue,
                            unfocusedTextColor = NavyBlue,
                            focusedBorderColor = SaffronOrange,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            },
            text = {
                Box(modifier = Modifier.heightIn(max = 350.dp).fillMaxWidth()) {
                    if (filteredCities.isEmpty()) {
                        Text(
                            text = "No cities found matching \"$searchQuery\"",
                            color = Color.Gray,
                            modifier = Modifier.padding(16.dp),
                            textAlign = TextAlign.Center
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(filteredCities) { city ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onCitySelected(city)
                                            showDialog = false
                                        }
                                        .padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = SaffronOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = city,
                                        fontSize = 15.sp,
                                        color = NavyBlue,
                                        fontWeight = if (city == selectedCity) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel", color = SaffronOrange, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

// =================================================================
// REUSABLE SEARCHABLE DROP-DOWN FOR EMERGENCY CATEGORIES
// =================================================================
val emergencyCategories = listOf(
    // CRIMINAL EMERGENCIES
    "Police Arrest / पुलिस गिरफ्तारी",
    "FIR Filed Against Me / मेरे खिलाफ FIR",
    "Anticipatory Bail Needed / अग्रिम जमानत",
    "Regular Bail Needed / जमानत चाहिए",
    "Police Harassment / पुलिस उत्पीड़न",
    "Custody of Family Member / परिवार हिरासत में",
    "Raid on Home or Office / छापेमारी",
    "Fake Case Filed / झूठा मुकदमा",
    "Warrant Received / वारंट मिला",
    "Summons from Court / कोर्ट समन",

    // PROPERTY EMERGENCIES  
    "Illegal Property Possession / अवैध कब्जा",
    "Eviction Notice Received / बेदखली नोटिस",
    "Property Dispute - Urgent / संपत्ति विवाद",
    "Land Encroachment / जमीन पर कब्जा",
    "Builder Not Giving Possession / बिल्डर कब्जा नहीं दे रहा",
    "Demolition Notice / तोड़फोड़ नोटिस",

    // FAMILY EMERGENCIES
    "Domestic Violence / घरेलू हिंसा",
    "Child Kidnapping / बच्चे का अपहरण",
    "Divorce - Urgent Help / तलाक - तुरंत मदद",
    "Child Custody Emergency / बच्चे की कस्टडी",
    "Dowry Harassment / दहेज उत्पीड़न",
    "Missing Family Member / परिवार का सदस्य गायब",
    "Protection Order Needed / सुरक्षा आदेश चाहिए",

    // FINANCIAL EMERGENCIES
    "Bank Account Frozen / बैंक खाता जमा",
    "Cheque Bounce - Urgent / चेक बाउंस",
    "Loan Recovery Agents / वसूली एजेंट परेशान कर रहे",
    "Credit Card Fraud / क्रेडिट कार्ड धोखाधड़ी",
    "Online Financial Fraud / ऑनलाइन वित्तीय धोखा",
    "Money Not Returned / पैसे वापस नहीं मिले",
    "GST Notice - Urgent / GST नोटिस",
    "Income Tax Raid / आयकर छापा",

    // CYBER & ONLINE EMERGENCIES
    "Cybercrime - Online Fraud / साइबर अपराध",
    "Social Media Defamation / सोशल मीडिया बदनामी",
    "Blackmail or Extortion / ब्लैकमेल या जबरदस्ती",
    "Hacking of Accounts / खाता हैक",
    "Morphed Photos/Videos / फोटो/वीडियो छेड़छाड़",
    "Online Harassment / ऑनलाइन उत्पीड़न",

    // WORKPLACE EMERGENCIES
    "Wrongful Termination / गलत बर्खास्तगी",
    "Salary Not Paid / वेतन नहीं मिला",
    "Workplace Harassment / कार्यस्थल उत्पीड़न",
    "PF / ESI Not Given / PF नहीं दिया",
    "Bond/Agreement Dispute / बॉन्ड विवाद",

    // CONSUMER EMERGENCIES
    "Product Defect - Urgent / खराब उत्पाद",
    "Hospital/Doctor Negligence / डॉक्टर लापरवाही",
    "Insurance Claim Rejected / बीमा दावा अस्वीकार",
    "E-Commerce Fraud / ऑनलाइन खरीद धोखा",
    "Travel/Hotel Fraud / यात्रा धोखाधड़ी",

    // ACCIDENT EMERGENCIES
    "Road Accident / सड़क दुर्घटना",
    "Accident - Insurance Claim / दुर्घटना बीमा",
    "Hit and Run Case / हिट एंड रन",
    "Accident - Police Case / दुर्घटना पुलिस केस",

    // GOVERNMENT & LEGAL
    "Government Notice Received / सरकारी नोटिस",
    "RTI Application Urgent / RTI आवेदन",
    "Passport/Visa Legal Issue / पासपोर्ट/विजा समस्या",
    "Court Order Not Followed / कोर्ट आदेश नहीं माना",
    "Contempt of Court / कोर्ट की अवमानना",
    "Execution of Decree / डिक्री का निष्पादन",

    // OTHER
    "Other Emergency / अन्य आपातकाल"
)

@Composable
fun SearchableEmergencyDropdown(
    label: String,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    categories: List<String>,
    modifier: Modifier = Modifier,
    isDarkTheme: Boolean = false
) {
    var showDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        OutlinedTextField(
            value = selectedCategory,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, color = if (isDarkTheme) Color.White else NavyBlue) },
            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = if (isDarkTheme) Color.White else NavyBlue) },
            colors = OutlinedTextFieldDefaults.colors(
                disabledTextColor = if (isDarkTheme) Color.White else NavyBlue,
                disabledBorderColor = if (isDarkTheme) Color.LightGray else Color.Gray,
                disabledLabelColor = if (isDarkTheme) Color.LightGray else NavyBlue,
                disabledTrailingIconColor = if (isDarkTheme) Color.White else NavyBlue
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDialog = true },
            shape = RoundedCornerShape(8.dp),
            enabled = false
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable { showDialog = true }
        )
    }

    if (showDialog) {
        var searchQuery by remember { mutableStateOf("") }
        val filteredCategories = remember(searchQuery, categories) {
            if (searchQuery.isBlank()) {
                categories
            } else {
                categories.filter { it.contains(searchQuery, ignoreCase = true) }
            }
        }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Column {
                    Text(
                        text = "Select Emergency Type",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = NavyBlue
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search category (e.g. bail)") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyBlue) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = NavyBlue)
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = NavyBlue,
                            unfocusedTextColor = NavyBlue,
                            focusedBorderColor = SaffronOrange,
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            },
            text = {
                Box(modifier = Modifier.heightIn(max = 350.dp).fillMaxWidth()) {
                    if (filteredCategories.isEmpty()) {
                        Text(
                            text = "No emergency categories found matching \"$searchQuery\"",
                            color = Color.Gray,
                            modifier = Modifier.padding(16.dp),
                            textAlign = TextAlign.Center
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(filteredCategories) { category ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onCategorySelected(category)
                                            showDialog = false
                                        }
                                        .padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = SaffronOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = category,
                                        fontSize = 14.sp,
                                        color = NavyBlue,
                                        fontWeight = if (category == selectedCategory) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel", color = SaffronOrange, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

// =================================================================
// SCREEN 1: SPLASH SCREEN
// =================================================================
@Composable
fun SplashScreen(navController: NavController) {
    LaunchedEffect(Unit) {
        delay(2500)
        navController.navigate("onboarding") {
            popUpTo("splash") { inclusive = true }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(SaffronOrange, NavyBlue)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            // Large scales of justice emoji
            Text(
                text = "⚖️",
                fontSize = 80.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Text(
                text = "Lawyer's Lobby",
                fontSize = 38.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "India's Trusted Legal Marketplace",
                fontSize = 15.sp,
                color = Color.White.copy(alpha = 0.9f),
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "भारत का कानूनी मंच",
                fontSize = 13.sp,
                fontStyle = FontStyle.Italic,
                color = Color.White.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        }

        TricolorStripe(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 0.dp)
        )
    }
}

// =================================================================
// SCREEN 2: ONBOARDING SCREEN
// =================================================================
@Composable
fun OnboardingScreen(navController: NavController) {
    var currentSlide by remember { mutableStateOf(0) }
    val totalSlides = 3

    val slidesInfo = listOf(
        Triple(
            "🔍",
            "Find Your Lawyer\n(अपना वकील खोजें)",
            "Search verified lawyers across 150+ Indian cities by city, case type and budget.\n\nभारत के किसी भी कोने से अपना वकील खोजें।"
        ),
        Triple(
            "🛡️",
            "Verified Profiles\n(सत्यापित प्रोफाइल)",
            "Every lawyer is Bar Council verified. Read real reviews from real clients before you decide.\n\nबार काउंसिल द्वारा सत्यापित और अनुशंसित वकील।"
        ),
        Triple(
            "🪙",
            "Zero Commission\n(कोई कमीशन नहीं है)",
            "Lawyers set their own fees. You pay them directly. We take absolutely no commission ever.\n\nसीधे वकील को भुगतान करें, एक भी पैसा अतिरिक्त न दें।"
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Top skip check
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = { navController.navigate("auth") },
                    modifier = Modifier.testTag("skip_button")
                ) {
                    Text("Skip", color = NavyBlue, fontWeight = FontWeight.Bold)
                }
            }

            // Slide information visual representation
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f).wrapContentHeight()
            ) {
                Text(
                    text = slidesInfo[currentSlide].first,
                    fontSize = 110.sp,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                Text(
                    text = slidesInfo[currentSlide].second,
                    fontSize = 24.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = NavyBlue,
                    textAlign = TextAlign.Center,
                    lineHeight = 32.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = slidesInfo[currentSlide].third,
                    fontSize = 15.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }

            // Controls Footer
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                // Bottom Dots
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    repeat(totalSlides) { index ->
                        Box(
                            modifier = Modifier
                                .padding(4.dp)
                                .size(if (currentSlide == index) 12.dp else 8.dp)
                                .clip(CircleShape)
                                .background(if (currentSlide == index) SaffronOrange else NavyBlue.copy(alpha = 0.2f))
                        )
                    }
                }

                // Call to action button
                Button(
                    onClick = {
                        if (currentSlide < totalSlides - 1) {
                            currentSlide++
                        } else {
                            navController.navigate("auth")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("onboarding_continue"),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (currentSlide == totalSlides - 1) "Get Started 🇮🇳" else "Next",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// =================================================================
// SCREEN 3: LOGIN / REGISTER SCREEN (OnboardingAuth)
// =================================================================
@Composable
fun OnboardingAuthScreen(
    navController: NavController,
    viewModel: LobbyViewModel
) {
    val coroutineScope = rememberCoroutineScope()
    var isSignInTab by remember { mutableStateOf(true) }
    var userRole by remember { mutableStateOf("client") } // "client" or "lawyer"

    // Common fields
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordConfirm by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var selectedCity by remember { mutableStateOf("New Delhi") }

    // Client fields
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }

    // Lawyer fields
    var lawyerName by remember { mutableStateOf("") }
    var barCouncilNo by remember { mutableStateOf("") }
    var selectedState by remember { mutableStateOf("Delhi") }
    var experience by remember { mutableStateOf("5") }
    var consultFee by remember { mutableStateOf("1000") }
    var appearanceFee by remember { mutableStateOf("5000") }
    var selectedSpecialisation by remember { mutableStateOf("Criminal Defence / आपराधिक बचाव") }
    var aboutMe by remember { mutableStateOf("") }
    var availableOnline by remember { mutableStateOf(true) }
    var registrationPhotoPath by remember { mutableStateOf("") }

    val context = LocalContext.current
    var showRegisterPhotoSheet by remember { mutableStateOf(false) }

    var tempRegisterPhotoFile by remember { mutableStateOf<File?>(null) }
    var tempRegisterPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val registerCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture(),
        onResult = { success ->
            if (success && tempRegisterPhotoFile != null) {
                registrationPhotoPath = tempRegisterPhotoFile!!.absolutePath
            }
        }
    )

    val registerGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                val path = saveUriToInternalStorage(context, uri)
                if (path.isNotEmpty()) {
                    registrationPhotoPath = path
                }
            }
        }
    )

    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyBlue)
                    .padding(vertical = 24.dp)
                    .statusBarsPadding(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⚖️ Lawyer's Lobby", color = Color.White, fontSize = 28.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
                    Text("India's Legal Marketplace", color = SaffronOrange, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
            TricolorStripe()

            // Main Tab Selector
            Row(modifier = Modifier.fillMaxWidth()) {
                TabButton(
                    text = "Sign In",
                    selected = isSignInTab,
                    modifier = Modifier.weight(1f),
                    onClick = { isSignInTab = true }
                )
                TabButton(
                    text = "Create Account",
                    selected = !isSignInTab,
                    modifier = Modifier.weight(1f),
                    onClick = { isSignInTab = false }
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Role Toggle
                Text(
                    text = "I am registering as a:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = NavyBlue,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp)
                ) {
                    RoleSelectButton(
                        text = "👤 Client (क्लाइंट)",
                        selected = userRole == "client",
                        modifier = Modifier.weight(1f),
                        onClick = { userRole = "client" }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    RoleSelectButton(
                        text = "⚖️ Lawyer (वकील)",
                        selected = userRole == "lawyer",
                        modifier = Modifier.weight(1f),
                        onClick = { userRole = "lawyer" }
                    )
                }

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = ErrorRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                if (isSignInTab) {
                    // SIGN IN FIELDS
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = NavyBlue) },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("email_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = NavyBlue) },
                        trailingIcon = {
                            val image = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(image, contentDescription = null)
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("password_input"),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 20.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "Forgot Password?",
                            color = SaffronOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.clickable { }
                        )
                    }

                    Button(
                        onClick = {
                            if (email.isEmpty() || password.isEmpty()) {
                                errorMessage = "Fields cannot be empty"
                                return@Button
                            }
                            val emailClean = email.trim().lowercase()
                            val isAdminEmail = emailClean == "admin@lawyerslobby.in" || emailClean == "baazsingh232023@gmail.com"
                            if (isAdminEmail) {
                                if (password != "admin123" && password != "admin789" && password != "baazAdmin999") {
                                    errorMessage = "Unauthorized admin authentication! Secure password incorrect."
                                    return@Button
                                }
                            }
                            coroutineScope.launch {
                                try {
                                    val success = viewModel.signin(email.trim(), password, userRole)
                                    if (success) {
                                        navController.navigate("home") {
                                            popUpTo("auth") { inclusive = true }
                                        }
                                    } else {
                                        errorMessage = "Authentication failed. Please verify credentials."
                                    }
                                } catch (e: Exception) {
                                    errorMessage = e.message ?: "SignIn failed: Ensure credentials are correct."
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("signin_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Continue to Lobby", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                } else {
                    // REGISTER FIELD GROUP
                    if (userRole == "client") {
                        // CLIENT REGISTER FLOW
                        OutlinedTextField(
                            value = firstName,
                            onValueChange = { firstName = it },
                            label = { Text("First Name") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            label = { Text("Last Name") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = NavyBlue) },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone Number (+91)") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = NavyBlue) },
                            placeholder = { Text("9876543210") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        // Searchable Indian City Dropdown
                        SearchableCityDropdown(
                            label = "Select City",
                            selectedCity = selectedCity,
                            onCitySelected = { selectedCity = it },
                            cities = viewModel.cities.map { it.cityName },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Button(
                            onClick = {
                                if (firstName.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                                    errorMessage = "Please fill in all details"
                                    return@Button
                                }
                                coroutineScope.launch {
                                    try {
                                        if (password.isEmpty() || password.length < 6) {
                                            errorMessage = "Password must be at least 6 characters."
                                            return@launch
                                        }
                                        viewModel.registerClient(firstName, lastName, email, phone, selectedCity, password)
                                        AnalyticsHelper.logUserRegistered("client")
                                        navController.navigate("home") {
                                            popUpTo("auth") { inclusive = true }
                                        }
                                    } catch (e: Exception) {
                                        errorMessage = e.message ?: "Registration failed. Please try again."
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("register_client_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Register as Client Guide", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                    } else {
                        // LAWYER REGISTRATION FLOW
                        // Sheet dialog display when requested
                        if (showRegisterPhotoSheet) {
                            PhotoSourceBottomSheet(
                                onDismissRequest = { showRegisterPhotoSheet = false },
                                onTakePhoto = {
                                    val (file, uri) = createTargetFileUri(context)
                                    tempRegisterPhotoFile = file
                                    tempRegisterPhotoUri = uri
                                    registerCameraLauncher.launch(uri)
                                },
                                onChooseGallery = {
                                    registerGalleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }
                            )
                        }

                        // Photo Upload Section at the top
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            colors = CardDefaults.cardColors(containerColor = WarmCream.copy(alpha = 0.5f)),
                            border = BorderStroke(1.dp, BorderColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(SaffronOrange.copy(alpha = 0.15f))
                                        .border(1.5.dp, SaffronOrange, CircleShape)
                                        .clickable { showRegisterPhotoSheet = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (registrationPhotoPath.isNotEmpty()) {
                                        AsyncImage(
                                            model = registrationPhotoPath,
                                            contentDescription = "Registered Professional Photo",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.AddAPhoto,
                                            contentDescription = "Upload Profile Photo",
                                            tint = SaffronOrange,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.width(16.dp))
                                
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Professional Photo / व्यावसायिक फ़ोटो",
                                        color = NavyBlue,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (registrationPhotoPath.isNotEmpty()) "✓ Photo selected successfully" else "Add a clean face photo for clients to see",
                                        color = if (registrationPhotoPath.isNotEmpty()) IndiaGreen else Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                                
                                TextButton(onClick = { showRegisterPhotoSheet = true }) {
                                    Text(
                                        text = if (registrationPhotoPath.isNotEmpty()) "Change" else "Upload",
                                        color = SaffronOrange,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        var prefixAdv by remember { mutableStateOf(true) }
                        OutlinedTextField(
                            value = lawyerName,
                            onValueChange = { lawyerName = it },
                            label = { Text("Full Name (e.g. Rajesh Sharma)") },
                            leadingIcon = {
                                Row(
                                    modifier = Modifier.padding(start = 12.dp, end = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(checked = prefixAdv, onCheckedChange = { prefixAdv = it })
                                    Text("Adv.", color = NavyBlue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = barCouncilNo,
                            onValueChange = { barCouncilNo = it },
                            label = { Text("Bar Council Reg Number (Mandatory)") },
                            placeholder = { Text("D/2891/2006") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email Address") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone Number (+91)") },
                            placeholder = { Text("e.g. 9811122233") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        // Experience + Fees
                        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            OutlinedTextField(
                                value = experience,
                                onValueChange = { experience = it },
                                label = { Text("Exp (Yrs)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f).padding(end = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            )
                            OutlinedTextField(
                                value = consultFee,
                                onValueChange = { consultFee = it },
                                label = { Text("Consult Fee ₹") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.5f).padding(horizontal = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            )
                            OutlinedTextField(
                                value = appearanceFee,
                                onValueChange = { appearanceFee = it },
                                label = { Text("Court Fee ₹") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.5f).padding(start = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }

                        // Searchable Practice City Dropdown
                        SearchableCityDropdown(
                            label = "Select Practice City",
                            selectedCity = selectedCity,
                            onCitySelected = { selectedCity = it },
                            cities = viewModel.cities.map { it.cityName },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )

                        // Specialisation Dropdown
                        var specExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            OutlinedTextField(
                                value = selectedSpecialisation,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Specialisation Area") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth().clickable { specExpanded = true },
                                shape = RoundedCornerShape(8.dp)
                            )
                            DropdownMenu(
                                expanded = specExpanded,
                                onDismissRequest = { specExpanded = false }
                            ) {
                                viewModel.categories.take(10).forEach { cat ->
                                    val catFullStr = "${cat.nameEnglish} / ${cat.nameHindi}"
                                    DropdownMenuItem(
                                        text = { Text(catFullStr) },
                                        onClick = {
                                            selectedSpecialisation = catFullStr
                                            specExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Online Consult Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Available for Online Video Sessions", fontWeight = FontWeight.Medium, color = NavyBlue)
                            Switch(
                                checked = availableOnline,
                                onCheckedChange = { availableOnline = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = SaffronOrange)
                            )
                        }

                        OutlinedTextField(
                            value = aboutMe,
                            onValueChange = { if (it.length <= 500) aboutMe = it },
                            label = { Text("About Me (Bio - Max 500 chars)") },
                            modifier = Modifier.fillMaxWidth().height(120.dp).padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp),
                            maxLines = 5
                        )

                        // Password Match
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (lawyerName.isEmpty() || barCouncilNo.isEmpty() || email.isEmpty()) {
                                    errorMessage = "Bar Council Number & Name are mandatory"
                                    return@Button
                                }
                                coroutineScope.launch {
                                    try {
                                        if (password.isEmpty() || password.length < 6) {
                                            errorMessage = "Password must be at least 6 characters."
                                            return@launch
                                        }
                                        val finalName = if (prefixAdv) "Adv. $lawyerName" else lawyerName
                                        viewModel.registerLawyerProfile(
                                            finalName,
                                            email,
                                            phone,
                                            selectedCity,
                                            selectedState,
                                            barCouncilNo,
                                            experience.toIntOrNull() ?: 5,
                                            consultFee.toIntOrNull() ?: 1000,
                                            appearanceFee.toIntOrNull() ?: 5000,
                                            selectedSpecialisation,
                                            listOf(selectedSpecialisation.split("/")[0].trim()),
                                            listOf("Hindi", "English"),
                                            availableOnline,
                                            aboutMe,
                                            "https://linkedin.com",
                                            "https://google.com",
                                            registrationPhotoPath,
                                            password
                                        )
                                        AnalyticsHelper.logUserRegistered("lawyer")
                                        navController.navigate("registration_success")
                                    } catch (e: Exception) {
                                        errorMessage = e.message ?: "Registration failed: Try in a few moments."
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("lawyer_register_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Submit Profile for Verification ⚖️", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = "Note: Your profile will be verified within 24 hours.",
                            fontSize = 11.sp,
                            fontStyle = FontStyle.Italic,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "By registering, you agree to our Terms of Service & Privacy Policy.",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun TabButton(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .background(if (selected) WarmCream else Color.White)
            .clickable { onClick() }
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = text,
                color = if (selected) SaffronOrange else NavyBlue,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            if (selected) {
                Spacer(modifier = Modifier.height(4.dp))
                Box(modifier = Modifier.size(24.dp, 3.dp).background(SaffronOrange))
            }
        }
    }
}

@Composable
fun RoleSelectButton(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(46.dp),
        border = BorderStroke(
            2.dp,
            if (selected) SaffronOrange else BorderColor
        ),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (selected) SaffronOrange.copy(alpha = 0.12f) else Color.White
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(text = text, color = if (selected) NavyBlue else TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

// =================================================================
// SCREEN 4: HOME SCREEN (Branching for Lawyer and Client Roles)
// =================================================================
@Composable
fun HomeScreen(navController: NavController, viewModel: LobbyViewModel) {
    val activeUser by viewModel.currentUser.collectAsState()
    val showAds = activeUser?.email != "baazsingh232023@gmail.com"

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.weight(1f)) {
            if (activeUser?.role == "lawyer") {
                LawyerDashboard(navController = navController, viewModel = viewModel)
            } else {
                ClientDashboard(navController = navController, viewModel = viewModel)
            }
        }
        if (showAds) {
            BannerAd(modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun ClientDashboard(navController: NavController, viewModel: LobbyViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val activeUser by viewModel.currentUser.collectAsState()
    val rawSearchQuery by viewModel.searchQuery.collectAsState()
    val filteredLawyers by viewModel.filteredLawyers.collectAsState()

    var activeCityFilter by remember { mutableStateOf("All") }
    var activeCategoryFilter by remember { mutableStateOf("All") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // TOP Rounded Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(NavyBlue, Color(0xFF132A43))
                    ),
                    RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                )
                .statusBarsPadding()
                .padding(bottom = 20.dp, top = 8.dp, start = 20.dp, end = 20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Namaste, ${activeUser?.name ?: "Guest User"}! 🙏",
                            color = SaffronOrange,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "📍 ${activeUser?.city ?: "New Delhi"}, India (Client)",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.1f))
                                .clickable { },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, SaffronOrange, CircleShape)
                                .background(SaffronOrange.copy(alpha = 0.2f))
                                .clickable { navController.navigate("my_profile") },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (activeUser?.name ?: "G").take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Find Your Legal Expert",
                    fontSize = 24.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    lineHeight = 30.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Modern Search Box with GO button inside
                OutlinedTextField(
                    value = rawSearchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search lawyers, case types, cities...", color = TextSecondary, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                    trailingIcon = {
                        Box(
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .background(SaffronOrange, RoundedCornerShape(8.dp))
                                .clickable { navController.navigate("listing") }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("GO", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_bar")
                        .background(Color.White, RoundedCornerShape(12.dp)),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Selector filters inside header
                Row(modifier = Modifier.fillMaxWidth()) {
                    var expandedCity by remember { mutableStateOf(false) }
                    var expandedCat by remember { mutableStateOf(false) }

                    // City Dropdown Filter
                    Box(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { expandedCity = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth().height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (activeCityFilter == "All") "Filter City" else activeCityFilter,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        if (expandedCity) {
                            var searchQuery by remember { mutableStateOf("") }
                            val allCityList = listOf("All") + viewModel.cities.map { it.cityName }
                            val filteredCities = remember(searchQuery) {
                                if (searchQuery.isBlank()) {
                                    allCityList
                                } else {
                                    allCityList.filter { it.contains(searchQuery, ignoreCase = true) }
                                }
                            }

                            AlertDialog(
                                onDismissRequest = { expandedCity = false },
                                title = {
                                    Column {
                                        Text("Filter by Indian City", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = NavyBlue)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = searchQuery,
                                            onValueChange = { searchQuery = it },
                                            placeholder = { Text("Type city name (e.g. Noida)") },
                                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyBlue) },
                                            trailingIcon = {
                                                if (searchQuery.isNotEmpty()) {
                                                    IconButton(onClick = { searchQuery = "" }) {
                                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = NavyBlue)
                                                    }
                                                }
                                            },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = NavyBlue,
                                                unfocusedTextColor = NavyBlue,
                                                focusedBorderColor = SaffronOrange,
                                                unfocusedBorderColor = Color.Gray
                                            )
                                        )
                                    }
                                },
                                text = {
                                    Box(modifier = Modifier.heightIn(max = 300.dp).fillMaxWidth()) {
                                        if (filteredCities.isEmpty()) {
                                            Text(
                                                text = "No cities found matching \"$searchQuery\"",
                                                color = Color.Gray,
                                                modifier = Modifier.padding(16.dp),
                                                textAlign = TextAlign.Center
                                            )
                                        } else {
                                            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                                items(filteredCities) { city ->
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clickable {
                                                                if (city == "All") {
                                                                    activeCityFilter = "All"
                                                                    viewModel.updateCityFilter("All")
                                                                } else {
                                                                    activeCityFilter = city
                                                                    viewModel.updateCityFilter(city)
                                                                }
                                                                expandedCity = false
                                                            }
                                                            .padding(vertical = 12.dp, horizontal = 8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Icon(
                                                            Icons.Default.LocationOn,
                                                            contentDescription = null,
                                                            tint = SaffronOrange,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(12.dp))
                                                        Text(text = city, fontSize = 15.sp, color = NavyBlue, fontWeight = if (city == activeCityFilter) FontWeight.Bold else FontWeight.Normal)
                                                    }
                                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                                }
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    TextButton(onClick = { expandedCity = false }) {
                                        Text("Close", color = SaffronOrange, fontWeight = FontWeight.Bold)
                                    }
                                },
                                containerColor = Color.White,
                                shape = RoundedCornerShape(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Case type dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { expandedCat = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth().height(38.dp),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (activeCategoryFilter == "All") "Case Type" else activeCategoryFilter,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        DropdownMenu(expanded = expandedCat, onDismissRequest = { expandedCat = false }) {
                            DropdownMenuItem(text = { Text("All Categories") }, onClick = {
                                activeCategoryFilter = "All"
                                viewModel.updateCategoryFilter("All")
                                expandedCat = false
                            })
                            viewModel.categories.forEach { cat ->
                                DropdownMenuItem(text = { Text(cat.nameEnglish) }, onClick = {
                                    activeCategoryFilter = cat.nameEnglish
                                    viewModel.updateCategoryFilter(cat.nameEnglish)
                                    expandedCat = false
                                })
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            navController.navigate("listing")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                        modifier = Modifier.height(38.dp),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Text("Search", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        TricolorStripe(modifier = Modifier.shadow(2.dp))

        // Luxury Options Quick Access Center
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "🇮🇳 SMART CITIZEN LEGAL ACCESS",
                    color = NavyBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Chatbot Quick Action
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { navController.navigate("ai_messenger") }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(SaffronOrange.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Face, contentDescription = null, tint = SaffronOrange, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("NyayaMitra AI", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                    }

                    // Emergency Center
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { navController.navigate("emergency") }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color.Red.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Urgent Bail", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                    }

                    // Court Fees
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { navController.navigate("pay_fees") }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(NavyBlue.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Gavel, contentDescription = null, tint = NavyBlue, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Pay Fees", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                    }

                    // Feedbacks
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { navController.navigate("reviews") }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(IndiaGreen.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = IndiaGreen, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Feedbacks", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                    }
                }
            }
        }

        // Dynamic High-Density Scrolling Body
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Screen Section 1: Categories Section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text("Legal Practice Sectors", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 16.sp)
                    Text(
                        text = "See All",
                        color = SaffronOrange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable { navController.navigate("categories") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Beautiful High-density 4-column grid (criminal, divorce, property, corporate)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val homeCategories = viewModel.categories.take(4)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        homeCategories.forEach { category ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.updateCategoryFilter(category.nameEnglish)
                                        navController.navigate("listing")
                                    }
                                    .padding(vertical = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(Color.White, RoundedCornerShape(16.dp))
                                        .border(BorderStroke(1.dp, BorderColor), RoundedCornerShape(16.dp))
                                        .shadow(1.dp, RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(category.icon, fontSize = 24.sp)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = category.nameEnglish,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyBlue,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = category.nameHindi,
                                    fontSize = 9.sp,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Screen Section 2: Top Rated Near You
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text("Top Rated Near You", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 16.sp)
                    Text(
                        text = "See All",
                        color = SaffronOrange,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable { navController.navigate("listing") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val nearby = filteredLawyers.take(4)
                if (nearby.isEmpty()) {
                    Text(
                        text = "No lawyers found matching current filters.",
                        color = TextSecondary,
                        modifier = Modifier.padding(20.dp),
                        style = androidx.compose.ui.text.TextStyle(fontStyle = FontStyle.Italic),
                        fontSize = 12.sp
                    )
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(nearby) { lawyer ->
                            LawyerHomeCard(lawyer = lawyer, onClick = {
                                viewModel.selectLawyer(lawyer.uid)
                                navController.navigate("profile_detail/${lawyer.uid}")
                            })
                        }
                    }
                }
            }

            // Screen Section 3: Emergency Assistance Block
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clickable { navController.navigate("emergency") },
                    colors = CardDefaults.cardColors(containerColor = ErrorRed),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "URGENT HELP",
                                color = Color.White.copy(alpha = 0.8f),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Need Emergency Bail?",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Available 24/7 with on-duty litigators",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp
                            )
                        }
                        Button(
                            onClick = { navController.navigate("emergency") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("FIND NOW 🚨", color = ErrorRed, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }
            }

            // Screen Section 4: Daily Information/Blog Content
            item {
                Text(
                    text = "Legal Awareness & Tips",
                    fontWeight = FontWeight.Bold,
                    color = NavyBlue,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        BlogCard(
                            emoji = "⚖️",
                            category = "FIR Right",
                            title = "How to register a free Zero FIR in India?",
                            subtitle = "जीरो एफआईआर पुलिस स्टेशन सीमा के बिना दर्ज की जा सकती है",
                            readTime = "3 min read"
                        )
                    }
                    item {
                        BlogCard(
                            emoji = "🏠",
                            category = "RERA",
                            title = "Builder Delay: What RERA covers?",
                            subtitle = "बिल्डर की देरी पर मुआवजा और नियम जानें",
                            readTime = "5 min read"
                        )
                    }
                    item {
                        BlogCard(
                            emoji = "💼",
                            category = "Corporate",
                            title = "Essential drafts for a new startup company",
                            subtitle = "नया स्टार्टअप शुरू करने की कानूनी शर्तें",
                            readTime = "4 min read"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LawyerDashboard(navController: NavController, viewModel: LobbyViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val activeUser by viewModel.currentUser.collectAsState()
    val allLawyers by viewModel.allLawyers.collectAsState()
    val allEmergencyRequests by viewModel.allEmergencyRequests.collectAsState()
    val allReviews by viewModel.allReviews.collectAsState()

    val lawyerProfile = remember(activeUser, allLawyers) {
        allLawyers.find { it.uid == activeUser?.uid }
    }

    var onlineStatus by remember { mutableStateOf(lawyerProfile?.isOnline == true) }
    var activeActionNotification by remember { mutableStateOf<String?>(null) }

    // Sync online state with DB
    LaunchedEffect(lawyerProfile) {
        if (lawyerProfile != null) {
            onlineStatus = lawyerProfile.isOnline
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // TOP Rounded Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(NavyBlue, Color(0xFF0F1E30))
                    ),
                    RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                )
                .statusBarsPadding()
                .padding(bottom = 20.dp, top = 8.dp, start = 20.dp, end = 20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "ADVOCATE PORTAL",
                                color = SaffronOrange,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Box(
                                modifier = Modifier
                                    .background(SuccessGreen, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text("BCI REGISTERED", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Namaste, ${activeUser?.name ?: "Counsel"}! 🏛️",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                        Text(
                            text = "📍 ${activeUser?.city ?: "New Delhi"}, ${activeUser?.state ?: "Delhi"} • ${lawyerProfile?.barCouncilNumber ?: "BCI Verified"}",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, SaffronOrange, CircleShape)
                            .background(SaffronOrange.copy(alpha = 0.15f))
                            .clickable { navController.navigate("my_profile") },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (activeUser?.name ?: "A").take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        TricolorStripe(modifier = Modifier.shadow(2.dp))

        // Professional Notification simulation
        AnimatedVisibility(
            visible = activeActionNotification != null,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                colors = CardDefaults.cardColors(containerColor = SuccessGreen),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = activeActionNotification ?: "", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { activeActionNotification = null }, modifier = Modifier.size(16.dp)) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // Section 1: Real-Time Practice Toggle
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "⚖️ Practice Stream Status",
                                color = NavyBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (onlineStatus) "Active & Available for instant consultation" else "Offline / Not accepting active queries",
                                color = if (onlineStatus) SuccessGreen else Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Switch(
                            checked = onlineStatus,
                            onCheckedChange = { isChecked ->
                                onlineStatus = isChecked
                                coroutineScope.launch {
                                    activeUser?.uid?.let { uid ->
                                        viewModel.repository.setOnlineStatus(uid, isChecked)
                                    }
                                }
                                activeActionNotification = if (isChecked) {
                                    "Your Practice Status is now ACTIVE. You are discoverable to clients nearby!"
                                } else {
                                    "Your Practice Status has been set to OFFLINE."
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SaffronOrange,
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = Color.LightGray
                            )
                        )
                    }
                }
            }

            // Section 2: Metrics Analytics Card Grid
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Text(
                        text = "Professional Performance Index",
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Rate
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("CONSULT FEE", fontSize = 9.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("₹${lawyerProfile?.consultationFee?.toInt() ?: 1500}/hr", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                                Text("Appr: ₹${lawyerProfile?.courtAppearanceFee?.toInt() ?: 4500}", fontSize = 8.sp, color = SaffronOrange, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Experience
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("EXPERIENCE", fontSize = 9.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("${lawyerProfile?.experienceYears ?: 10}+ Years", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                                Text(lawyerProfile?.specialisation?.split(",")?.firstOrNull() ?: "Criminal Law", fontSize = 8.sp, color = IndiaGreen, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Rating
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("RATING SCORE", fontSize = 9.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("4.9 ★ Score", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                                Text("Verified Feedbacks", fontSize = 8.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            // Section 3: Premium AI Lawyer Assistant Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clickable { navController.navigate("ai_messenger") },
                    colors = CardDefaults.cardColors(containerColor = NavyBlue),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ADVANCED RESEARCH COMPANION",
                                color = SaffronOrange,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Launch NyayaCopilot AI Research ⚖️",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Analyze litigation strategies, search relevant penal codes, and review boilerplate contracts.",
                                color = Color.White.copy(alpha = 0.82f),
                                fontSize = 11.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Face, contentDescription = null, tint = SaffronOrange, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Section 4: LIVE CITIZEN DISTRESS ALERTS
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color.Red, CircleShape)
                            )
                            Text(
                                text = "🚨 Live Citizen Distress Alerts",
                                fontWeight = FontWeight.Bold,
                                color = NavyBlue,
                                fontSize = 15.sp
                            )
                        }

                        Text(
                            text = "${allEmergencyRequests.size} Active",
                            color = Color.Red,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    if (allEmergencyRequests.isEmpty()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp).fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("📡 Monitoring emergency frequencies...", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("No citizen bail or arrest distress calls logged in this state currently.", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            allEmergencyRequests.take(5).forEach { alert ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.3f)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .background(Color.Red.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text(alert.emergencyType.uppercase(), color = Color.Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Text(
                                                text = "URGENT DISTRESS",
                                                color = SaffronOrange,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(
                                            text = "Citizen: ${alert.name}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NavyBlue
                                        )
                                        Text(
                                            text = "City: ${alert.city} • Contact: ${alert.phone}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Text(
                                            text = alert.description.ifEmpty { "Urgent arrest or police detainment advisory needed immediately raw facts pending." },
                                            fontSize = 11.sp,
                                            color = TextSecondary,
                                            lineHeight = 15.sp
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    activeActionNotification = "Dialing Client +91 ${alert.phone} via secure legal bridge line..."
                                                },
                                                border = BorderStroke(1.dp, NavyBlue),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NavyBlue),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f).height(32.dp),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("📞 Direct Dial", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = {
                                                    activeActionNotification = "Advocate representation officially logged for Client ${alert.name}."
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1.2f).height(32.dp),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("🏛️ Represent Client", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 5: Recent feedback Left for them
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    Text(
                        text = "Counsel Feedbacks & Reviews",
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    val myReviews = allReviews.filter { it.lawyerId == activeUser?.uid }
                    if (myReviews.isEmpty()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp).fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("No reviews logged yet.", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            myReviews.forEach { review ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(review.clientName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                                            Text("★".repeat(review.rating), fontSize = 10.sp, color = SaffronOrange)
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(review.reviewText, fontSize = 11.sp, color = TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryHomeChip(
    category: CategoryItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .clickable { onClick() }
            .width(130.dp),
        colors = CardDefaults.cardColors(containerColor = WarmCream),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(category.icon, fontSize = 28.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                category.nameEnglish,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = NavyBlue,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                category.nameHindi,
                fontSize = 10.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun LawyerHomeCard(
    lawyer: LawyerEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(230.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderColor),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular Portrait Photo via Coil with Green Verify badge
                Box(modifier = Modifier.size(52.dp)) {
                    if (!lawyer.profilePhoto.isNullOrBlank()) {
                        AsyncImage(
                            model = lawyer.profilePhoto,
                            contentDescription = "Advocate ${lawyer.name}",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, NavyBlue.copy(alpha = 0.2f), CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE5E7EB)),
                            contentAlignment = Alignment.Center
                        ) {
                            val isFemale = lawyer.name.contains("Priya", ignoreCase = true) || 
                                           lawyer.name.contains("Meera", ignoreCase = true) || 
                                           lawyer.name.contains("Ananya", ignoreCase = true) || 
                                           lawyer.name.contains("Ritu", ignoreCase = true) || 
                                           lawyer.name.contains("Ashi", ignoreCase = true) || 
                                           lawyer.name.contains("Neha", ignoreCase = true) || 
                                           lawyer.name.contains("Shweta", ignoreCase = true)
                            Text(
                                text = if (isFemale) "👩‍⚖️" else "👨‍⚖️",
                                fontSize = 24.sp
                            )
                        }
                    }
                    if (lawyer.isVerified) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(IndiaGreen)
                                .border(1.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✓", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = lawyer.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NavyBlue,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = lawyer.specialisation.split("/")[0].trim(),
                        fontSize = 10.sp,
                        color = SaffronOrange,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text("★★★★★", color = SaffronOrange, fontSize = 10.sp)
                        Text(
                            text = "${lawyer.rating}",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CONSULTATION FEE",
                        fontSize = 8.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "₹${lawyer.consultationFee}",
                        fontSize = 14.sp,
                        color = IndiaGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("VIEW PROFILE", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BlogCard(
    emoji: String,
    category: String,
    title: String,
    subtitle: String,
    readTime: String
) {
    Card(
        modifier = Modifier.width(220.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, fontSize = 20.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .background(SaffronOrange.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(category, fontSize = 9.sp, color = NavyBlue, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, fontSize = 11.sp, color = TextSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(8.dp))
            Text(readTime, fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
        }
    }
}

// =================================================================
// SCREEN 5: LAWYER LISTING / SEARCH SCREEN (LawyerListing)
// =================================================================
@Composable
fun LawyerListingScreen(navController: NavController, viewModel: LobbyViewModel) {
    val currentSearchQuery by viewModel.searchQuery.collectAsState()
    val filteredLawyers by viewModel.filteredLawyers.collectAsState()
    val activeSort by viewModel.sortOption.collectAsState()
    val onlineOnly by viewModel.onlineOnly.collectAsState()
    val verifiedOnly by viewModel.verifiedOnly.collectAsState()
    val activeUser by viewModel.currentUser.collectAsState()
    val showAds = activeUser?.email != "baazsingh232023@gmail.com"

    LaunchedEffect(currentSearchQuery) {
        if (currentSearchQuery.isNotBlank()) {
            AnalyticsHelper.logSearchPerformed(currentSearchQuery, filteredLawyers.size)
        }
    }

    var showSortMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // App Topbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏛️ Expert Litigators", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, fontFamily = FontFamily.Serif)
            Spacer(modifier = Modifier.weight(1f))
        }
        TricolorStripe(modifier = Modifier.shadow(2.dp))

        // Persistent Search Input inside listing
        Box(modifier = Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = currentSearchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search by name, city, case type...", color = TextSecondary, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("listing_search_input")
                    .background(Color.White, RoundedCornerShape(12.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
        }

        val activeCityFilter by viewModel.selectedCityFilter.collectAsState()
        var expandedCityListing by remember { mutableStateOf(false) }

        // Horizontal Filters Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterBadgeChip(
                text = if (activeCityFilter == "All") "📍 All Cities" else "📍 $activeCityFilter",
                selected = activeCityFilter != "All",
                onClick = { expandedCityListing = true }
            )
            FilterBadgeChip(
                text = "✅ Verified Only",
                selected = verifiedOnly,
                onClick = { viewModel.toggleVerifiedOnly(!verifiedOnly) }
            )
            FilterBadgeChip(
                text = "📹 Online Consultation",
                selected = onlineOnly,
                onClick = { viewModel.toggleOnlineOnly(!onlineOnly) }
            )
        }

        if (expandedCityListing) {
            var searchQuery by remember { mutableStateOf("") }
            val allCityList = listOf("All") + viewModel.cities.map { it.cityName }
            val filteredCities = remember(searchQuery) {
                if (searchQuery.isBlank()) {
                    allCityList
                } else {
                    allCityList.filter { it.contains(searchQuery, ignoreCase = true) }
                }
            }

            AlertDialog(
                onDismissRequest = { expandedCityListing = false },
                title = {
                    Column {
                        Text("Filter by Indian City", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = NavyBlue)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Type city name (e.g. Pune)") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyBlue) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = NavyBlue)
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = NavyBlue,
                                unfocusedTextColor = NavyBlue,
                                focusedBorderColor = SaffronOrange,
                                unfocusedBorderColor = Color.Gray
                            )
                        )
                    }
                },
                text = {
                    Box(modifier = Modifier.heightIn(max = 300.dp).fillMaxWidth()) {
                        if (filteredCities.isEmpty()) {
                            Text(
                                text = "No cities found matching \"$searchQuery\"",
                                color = Color.Gray,
                                modifier = Modifier.padding(16.dp),
                                textAlign = TextAlign.Center
                            )
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(filteredCities) { city ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (city == "All") {
                                                    viewModel.updateCityFilter("All")
                                                } else {
                                                    viewModel.updateCityFilter(city)
                                                }
                                                expandedCityListing = false
                                            }
                                            .padding(vertical = 12.dp, horizontal = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.LocationOn,
                                            contentDescription = null,
                                            tint = SaffronOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(text = city, fontSize = 15.sp, color = NavyBlue, fontWeight = if (city == activeCityFilter) FontWeight.Bold else FontWeight.Normal)
                                    }
                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { expandedCityListing = false }) {
                        Text("Close", color = SaffronOrange, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            )
        }

        // Sort Control Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${filteredLawyers.size} lawyers found",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )

            // Sort Selector Box
            Box {
                Button(
                    onClick = { showSortMenu = true },
                    colors = ButtonDefaults.buttonColors(containerColor = WarmCream),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Sort: $activeSort ▼", color = NavyBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                    DropdownMenuItem(text = { Text("Rating (उच्च रेटिंग)") }, onClick = {
                        viewModel.updateSortOption("Rating")
                        showSortMenu = false
                    })
                    DropdownMenuItem(text = { Text("Fees: Low to High (कम शुल्क)") }, onClick = {
                        viewModel.updateSortOption("Fees")
                        showSortMenu = false
                    })
                    DropdownMenuItem(text = { Text("Years of Experience (अनुभव)") }, onClick = {
                        viewModel.updateSortOption("Experience")
                        showSortMenu = false
                    })
                    DropdownMenuItem(text = { Text("Newest (नवीनतम)") }, onClick = {
                        viewModel.updateSortOption("Newest")
                        showSortMenu = false
                    })
                }
            }
        }

        // Vertical List
        if (filteredLawyers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No lawyers found matched.", color = TextSecondary, modifier = Modifier.padding(bottom = 12.dp))
                    Button(
                        onClick = {
                            viewModel.updateSearchQuery("")
                            viewModel.updateCityFilter("All")
                            viewModel.updateCategoryFilter("All")
                            viewModel.toggleOnlineOnly(false)
                            viewModel.toggleVerifiedOnly(false)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
                    ) {
                        Text("Reset All Filters", color = Color.White)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("lawyer_list_column"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (showAds) {
                    val itemsList = mutableListOf<Any>()
                    filteredLawyers.forEachIndexed { index, lawyer ->
                        itemsList.add(lawyer)
                        if ((index + 1) % 5 == 0) {
                            itemsList.add("NATIVE_AD")
                        }
                    }
                    items(itemsList) { item ->
                        if (item is LawyerEntity) {
                            LawyerRowItem(lawyer = item, onClick = {
                                viewModel.selectLawyer(item.uid)
                                navController.navigate("profile_detail/${item.uid}")
                            })
                        } else {
                            NativeAdListItem()
                        }
                    }
                } else {
                    items(filteredLawyers) { lawyer ->
                        LawyerRowItem(lawyer = lawyer, onClick = {
                            viewModel.selectLawyer(lawyer.uid)
                            navController.navigate("profile_detail/${lawyer.uid}")
                        })
                    }
                }
            }
        }
        if (showAds) {
            BannerAd(modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun FilterBadgeChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(
                if (selected) SaffronOrange else Color.Transparent,
                RoundedCornerShape(16.dp)
            )
            .border(
                1.dp,
                if (selected) SaffronOrange else BorderColor,
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else NavyBlue,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun LawyerRowItem(
    lawyer: LawyerEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderColor),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                // Dynamic Profile image by Coil or standard emoji fallback
                if (!lawyer.profilePhoto.isNullOrBlank()) {
                    AsyncImage(
                        model = lawyer.profilePhoto,
                        contentDescription = "Advocate ${lawyer.name}",
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, NavyBlue.copy(alpha = 0.1f), RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE5E7EB)),
                        contentAlignment = Alignment.Center
                    ) {
                        val isFemale = lawyer.name.contains("Priya", ignoreCase = true) || 
                                       lawyer.name.contains("Meera", ignoreCase = true) || 
                                       lawyer.name.contains("Ananya", ignoreCase = true) || 
                                       lawyer.name.contains("Ritu", ignoreCase = true) || 
                                       lawyer.name.contains("Ashi", ignoreCase = true) || 
                                       lawyer.name.contains("Neha", ignoreCase = true) || 
                                       lawyer.name.contains("Shweta", ignoreCase = true)
                        Text(
                            text = if (isFemale) "👩‍⚖️" else "👨‍⚖️",
                            fontSize = 32.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(lawyer.name, fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        if (lawyer.isVerified) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFE6F4EA), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Verified ✅", color = SuccessGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Text(lawyer.specialisation, fontWeight = FontWeight.Bold, color = SaffronOrange, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📍 ${lawyer.city}, ${lawyer.state}", fontSize = 11.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("💼 ${lawyer.experienceYears} Yrs Exp", fontSize = 11.sp, color = NavyBlue, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Tags/Case types inside card (take first 2-3 tags)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val tags = lawyer.caseTypes.split(",").take(2)
                        tags.forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .background(WarmCream, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(tag.trim(), fontSize = 9.sp, color = NavyBlue)
                            }
                        }
                        if (lawyer.caseTypes.split(",").size > 2) {
                            Box(
                                modifier = Modifier
                                    .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("+2 more", fontSize = 9.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Consultation Fee", fontSize = 10.sp, color = TextSecondary)
                    Text("₹${lawyer.consultationFee}", fontSize = 15.sp, color = IndiaGreen, fontWeight = FontWeight.Bold)
                }

                Row {
                    if (lawyer.isOnline) {
                        Box(
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .border(1.dp, SaffronOrange, RoundedCornerShape(6.dp))
                                .align(Alignment.CenterVertically)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("📹 Live Online", color = SaffronOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("View Profile", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// =================================================================
// SCREEN 6: LAWYER PROFILE DETAIL SCREEN (LawyerProfile)
// =================================================================
@Composable
fun LawyerProfileScreen(
    navController: NavController,
    viewModel: LobbyViewModel,
    lawyerId: String
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val lawyers by viewModel.allLawyers.collectAsState()
    val reviews by viewModel.getReviewsForLawyer(lawyerId).collectAsState(initial = emptyList())

    val lawyer = lawyers.find { it.uid == lawyerId }

    if (lawyer == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Lawyer profile details not found error.", color = ErrorRed)
                Button(onClick = { navController.popBackStack() }) {
                    Text("Back")
                }
            }
        }
        return
    }

    val activeUser by viewModel.currentUser.collectAsState()
    val showAds = activeUser?.email != "baazsingh232023@gmail.com"
    val activity = remember(context) { context.findActivity() }

    LaunchedEffect(lawyer) {
        AnalyticsHelper.logLawyerProfileViewed(lawyer.name, lawyer.city)
        if (activity != null) {
            AdMobHelper.incrementProfileViewAndShowIfThresholdReached(activity, showAds)
        }
    }

    var selectedTab by remember { mutableStateOf(0) } // 0 = About, 1 = Reviews, 2 = Fee Structure

    // Bottom sheet dialog simulation state for writing reviews
    var showReviewDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // PROFILE HERO AREA (Navy Brush Gradient)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(NavyBlue, NavyBlue.copy(alpha = 0.85f))
                    )
                )
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Color.White)
                    }
                    Text(
                        text = "Counsel Profile",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = {}) {
                        Icon(Icons.Outlined.FavoriteBorder, contentDescription = null, tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    if (!lawyer.profilePhoto.isNullOrBlank()) {
                        AsyncImage(
                            model = lawyer.profilePhoto,
                            contentDescription = "Advocate ${lawyer.name}",
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .border(2.dp, SaffronOrange, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(SaffronOrange),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = lawyer.name.replace("Adv. ", "").take(1),
                                color = Color.White,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = lawyer.name,
                            fontSize = 21.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = lawyer.specialisation,
                            color = SaffronOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📍 ${lawyer.city}, India", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                            if (lawyer.isVerified) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(SuccessGreen, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Bar Council Verified ✅", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
        TricolorStripe()

        // COUNSEL STATISTICS BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 16.dp)
                .background(WarmCream.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "${lawyer.experienceYears}+ Yrs", fontWeight = FontWeight.Bold, color = NavyBlue)
                Text("Experience", fontSize = 10.sp, color = TextSecondary)
            }
            Divider(modifier = Modifier.height(28.dp).width(1.dp), color = BorderColor)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "⭐ ${lawyer.rating}", fontWeight = FontWeight.Bold, color = NavyBlue)
                Text("${lawyer.totalReviews} Reviews", fontSize = 10.sp, color = TextSecondary)
            }
            Divider(modifier = Modifier.height(28.dp).width(1.dp), color = BorderColor)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = lawyer.workingHours.split("(")[0], fontWeight = FontWeight.Bold, color = NavyBlue)
                Text("Working Hours", fontSize = 10.sp, color = TextSecondary)
            }
        }

        // TABS
        Row(modifier = Modifier.fillMaxWidth()) {
            TabButton(text = "About", selected = selectedTab == 0, modifier = Modifier.weight(1f), onClick = { selectedTab = 0 })
            TabButton(text = "Client Reviews", selected = selectedTab == 1, modifier = Modifier.weight(1f), onClick = { selectedTab = 1 })
            TabButton(text = "Practice details", selected = selectedTab == 2, modifier = Modifier.weight(1f), onClick = { selectedTab = 2 })
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> {
                    // ABOUT TAB
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text("Attorney Bio", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyBlue)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lawyer.about,
                            fontSize = 14.sp,
                            lineHeight = 22.sp,
                            color = TextSecondary
                        )

                        val clientOfficePhotosList = if (lawyer.officePhotos.isNullOrEmpty()) {
                            emptyList()
                        } else {
                            lawyer.officePhotos.split(",").filter { it.isNotEmpty() }
                        }

                        if (clientOfficePhotosList.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                "🏢 Office Showcase",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = NavyBlue,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(clientOfficePhotosList) { photoPath ->
                                    Card(
                                        modifier = Modifier
                                            .size(160.dp, 120.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, BorderColor)
                                    ) {
                                        AsyncImage(
                                            model = photoPath,
                                            contentDescription = "Office Showcase Photo",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderColor)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Pricing & Payment Policy", fontWeight = FontWeight.Bold, color = NavyBlue)
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("General consultation fee:", fontSize = 13.sp)
                                    Text("₹${lawyer.consultationFee}", fontWeight = FontWeight.Bold, color = IndiaGreen)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Court hearing appearance fee:", fontSize = 13.sp)
                                    Text("₹${lawyer.courtAppearanceFee}", fontWeight = FontWeight.Bold, color = IndiaGreen)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Divider(color = BorderColor)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "💡 Fees are defined directly by the legal counselor. Lawyer's Lobby takes 0% commission on case outcomes or booking sessions.",
                                    fontSize = 11.sp,
                                    color = SaffronOrange,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }

                1 -> {
                    // REVIEWS TAB
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Client Feedback",
                                fontWeight = FontWeight.Bold,
                                color = NavyBlue,
                                fontSize = 15.sp
                            )
                            Button(
                                onClick = { showReviewDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Write Review", fontSize = 11.sp, color = Color.White)
                            }
                        }

                        if (reviews.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f), contentAlignment = Alignment.Center
                            ) {
                                Text("No reviews posted yet. Be the first to leave a feedback!")
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(reviews) { review ->
                                    ReviewCardItem(review = review)
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // PRACTICE DETAILS TAB
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text("Office chamber location & contact", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(lawyer.officeAddress, color = TextSecondary, fontSize = 13.sp)

                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Registration Number", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                        Text(lawyer.barCouncilNumber, color = SaffronOrange, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Languages spoken", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                        Text(lawyer.languages, color = TextSecondary, fontSize = 13.sp)

                        Spacer(modifier = Modifier.height(16.dp))

                        Text("Services Offered", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyBlue)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            lawyer.caseTypes.split(",").forEach { item ->
                                Box(
                                    modifier = Modifier
                                        .background(WarmCream, RoundedCornerShape(4.dp))
                                        .border(1.dp, SaffronOrange.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(item.trim(), fontSize = 11.sp, color = NavyBlue)
                                }
                            }
                        }
                    }
                }
            }
        }

        // STICKY BAR ACTIONS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .background(Color.White)
                .border(1.dp, BorderColor)
                .padding(12.dp)
        ) {
            Button(
                onClick = {
                    try {
                        AnalyticsHelper.logCallButtonTapped(lawyer.name)
                        val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${lawyer.phone}"))
                        context.startActivity(callIntent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .padding(end = 4.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("📞 Call Counsel", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Button(
                onClick = {
                    try {
                        AnalyticsHelper.logWhatsappButtonTapped(lawyer.name)
                        val formattedNumber = lawyer.phone.replace(" ", "").replace("-", "")
                        val cleanNumber = if (formattedNumber.length == 10) "91$formattedNumber" else formattedNumber
                        val messageText = Uri.encode("Hello Advocate ${lawyer.name}, I found your contact on Lawyer's Lobby app and would like to request legal advice.")
                        val whatsappUri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanNumber&text=$messageText")
                        val whatsappIntent = Intent(Intent.ACTION_VIEW, whatsappUri)
                        context.startActivity(whatsappIntent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), // WhatsApp Color
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .padding(horizontal = 4.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("💬 WhatsApp", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            if (lawyer.isOnline) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            // Show booking notice/placeholder
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    modifier = Modifier
                        .weight(1.5f)
                        .height(44.dp)
                        .padding(start = 4.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("📹 Book Video Slot", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }

    if (showReviewDialog) {
        WriteReviewDialog(
            onDismiss = { showReviewDialog = false },
            onSubmit = { client, rating, text, case ->
                coroutineScope.launch {
                    viewModel.submitReview(lawyerId, client, rating, text, case)
                    showReviewDialog = false
                }
            }
        )
    }
}

@Composable
fun ReviewCardItem(review: ReviewEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderColor)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NavyBlue.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(review.clientName.take(1), fontWeight = FontWeight.Bold, color = NavyBlue)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(review.clientName, fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 13.sp)
                        Text(review.caseType, fontSize = 10.sp, color = SaffronOrange, fontWeight = FontWeight.Bold)
                    }
                }
                Text("⭐".repeat(review.rating), fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(review.reviewText, fontSize = 13.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(4.dp))
            if (review.isVerifiedClient) {
                Text("✔ Verified Client (सत्यापित क्लाइंट)", fontSize = 10.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun WriteReviewDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, Int, String, String) -> Unit
) {
    var reviewerName by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf(5) }
    var reviewText by remember { mutableStateOf("") }
    var caseType by remember { mutableStateOf("Consultation") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Write a Client Review") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = reviewerName,
                    onValueChange = { reviewerName = it },
                    label = { Text("Your Name (Optional)") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                Text("Rating (सितारे):", modifier = Modifier.padding(vertical = 4.dp), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(5) { i ->
                        val index = i + 1
                        val color = if (index <= rating) SaffronOrange else Color.LightGray
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = color,
                            modifier = Modifier
                                .size(32.dp)
                                .clickable { rating = index }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = caseType,
                    onValueChange = { caseType = it },
                    label = { Text("Case/Matter Type (e.g. Bail, Advice)") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                OutlinedTextField(
                    value = reviewText,
                    onValueChange = { reviewText = it },
                    label = { Text("Provide details of your experience (Min 20 chars)") },
                    modifier = Modifier.fillMaxWidth().height(100.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reviewText.length >= 10) {
                        onSubmit(reviewerName, rating, reviewText, caseType)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange)
            ) {
                Text("Submit Review", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = NavyBlue)
            }
        }
    )
}

// =================================================================
// SCREEN 7: LEGAL CATEGORIES SCREEN
// =================================================================
@Composable
fun LegalCategoriesScreen(navController: NavController, viewModel: LobbyViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏛️ Practice Sectors", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, fontFamily = FontFamily.Serif)
        }
        TricolorStripe(modifier = Modifier.shadow(2.dp))

        Column(modifier = Modifier.padding(20.dp)) {
            Text("Legal Categories", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = NavyBlue)
            Text("Select a specialisation to find expert lawyers near you", fontSize = 13.sp, color = TextSecondary)
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("categories_grid"),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(viewModel.categories) { category ->
                Card(
                    modifier = Modifier
                        .clickable {
                            viewModel.updateCategoryFilter(category.nameEnglish)
                            navController.navigate("listing")
                        }
                        .height(115.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(category.icon, fontSize = 26.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            category.nameEnglish,
                            fontWeight = FontWeight.Bold,
                            color = NavyBlue,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            category.nameHindi,
                            fontSize = 10.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

// =================================================================
// SCREEN 8: CLIENT REVIEWS SCREEN
// =================================================================
@Composable
fun ClientReviewsScreen(viewModel: LobbyViewModel) {
    val reviews by viewModel.allReviews.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("⭐ Public Reviews", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, fontFamily = FontFamily.Serif)
        }
        TricolorStripe(modifier = Modifier.shadow(2.dp))

        // Overall rating Display stats
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            color = Color.White,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, BorderColor),
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("4.8", fontSize = 42.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                    Text("out of 5", fontSize = 12.sp, color = TextSecondary)
                }

                Spacer(modifier = Modifier.width(20.dp))

                Column {
                    Text("Verified Client Rating Tracker", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 14.sp)
                    Text("Backed by active Bar Council compliance audits across all courts in India.", fontSize = 11.sp, color = TextSecondary, lineHeight = 16.sp)
                }
            }
        }

        Text(
            text = "Latest Reviews Across India",
            fontWeight = FontWeight.Bold,
            color = NavyBlue,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            fontSize = 16.sp
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("global_reviews_list"),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(reviews) { review ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(review.clientName, fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 14.sp)
                            Text("⭐".repeat(review.rating), fontSize = 12.sp)
                        }
                        Text(review.caseType, fontSize = 11.sp, color = SaffronOrange, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(review.reviewText, fontSize = 13.sp, color = Color.Black)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("✔ Bar Council Checked Client", fontSize = 10.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// =================================================================
// SCREEN 9: PAY CHALAN / COURT FEES SCREEN (Court Chalan Payment)
// =================================================================
@Composable
fun PayChalanScreen(viewModel: LobbyViewModel) {
    val coroutineScope = rememberCoroutineScope()
    var selectedType by remember { mutableStateOf("Court Fee") }

    var stateSelected by remember { mutableStateOf("Delhi") }
    var courtDetails by remember { mutableStateOf("") }
    var payAmount by remember { mutableStateOf("") }
    var payerName by remember { mutableStateOf("") }
    var phoneNo by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("UPI") }

    var paymentStatusMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏛️ Quick Court Payments", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp, fontFamily = FontFamily.Serif)
        }
        TricolorStripe(modifier = Modifier.shadow(2.dp))

        Column(modifier = Modifier.padding(20.dp)) {
            Text("Pay Court Fees & Chalans", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = NavyBlue)
            Text("न्यायालय शुल्क ऑनलाइन जमा करें", fontSize = 13.sp, color = TextSecondary)
            Spacer(modifier = Modifier.height(16.dp))

            // Sub-Selectors grid
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                PaymentTypeBox("Court Fee", selectedType == "Court Fee", modifier = Modifier.weight(1f)) { selectedType = "Court Fee" }
                Spacer(modifier = Modifier.width(8.dp))
                PaymentTypeBox("Chalan", selectedType == "Chalan", modifier = Modifier.weight(1f)) { selectedType = "Chalan" }
            }
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                PaymentTypeBox("Stamp Duty", selectedType == "Stamp Duty", modifier = Modifier.weight(1f)) { selectedType = "Stamp Duty" }
                Spacer(modifier = Modifier.width(8.dp))
                PaymentTypeBox("Court Fine", selectedType == "Court Fine", modifier = Modifier.weight(1f)) { selectedType = "Court Fine" }
            }

            if (paymentStatusMessage.isNotEmpty()) {
                Text(
                    text = paymentStatusMessage,
                    color = SuccessGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            // FORM
            var stateExpanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                OutlinedTextField(
                    value = stateSelected,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Selected State (राज्य चुनें)") },
                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().clickable { stateExpanded = true },
                    shape = RoundedCornerShape(8.dp)
                )
                DropdownMenu(expanded = stateExpanded, onDismissRequest = { stateExpanded = false }) {
                    viewModel.states.forEach { state ->
                        DropdownMenuItem(text = { Text(state) }, onClick = {
                            stateSelected = state
                            stateExpanded = false
                        })
                    }
                }
            }

            OutlinedTextField(
                value = courtDetails,
                onValueChange = { courtDetails = it },
                label = { Text("Court / Case or vehicle registration number") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = payAmount,
                onValueChange = { payAmount = it },
                label = { Text("Amount under Rupee (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = payerName,
                onValueChange = { payerName = it },
                label = { Text("Depositor Full Name") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = phoneNo,
                onValueChange = { phoneNo = it },
                label = { Text("Contact mobile number (+91)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                shape = RoundedCornerShape(8.dp)
            )

            // Method Picker (UPI or Debit Card)
            Text("Select Payment Method:", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 14.sp)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 20.dp)) {
                MethodSelectItem("💳 GPay/UPI", selectedPaymentMethod == "UPI", modifier = Modifier.weight(1f)) { selectedPaymentMethod = "UPI" }
                Spacer(modifier = Modifier.width(8.dp))
                MethodSelectItem("🏧 Debit Card", selectedPaymentMethod == "Card", modifier = Modifier.weight(1f)) { selectedPaymentMethod = "Card" }
            }

            Button(
                onClick = {
                    if (payerName.isEmpty() || phoneNo.isEmpty() || payAmount.isEmpty()) {
                        paymentStatusMessage = "Warning: Filling critical fields is mandatory"
                        return@Button
                    }
                    val amtVal = payAmount.toDoubleOrNull() ?: 0.0
                    AnalyticsHelper.logChalanPaymentInitiated(amtVal, stateSelected)
                    coroutineScope.launch {
                        viewModel.payChalan(selectedType, stateSelected, courtDetails, amtVal, payerName, phoneNo, selectedPaymentMethod)
                        paymentStatusMessage = "Successfully Deposited ₹$amtVal towards $selectedType! Receipt generated 📄"
                        // Reset forms
                        courtDetails = ""
                        payAmount = ""
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("pay_secure_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Pay Now Securely 🔒", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun PaymentTypeBox(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(52.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) SaffronOrange else Color.White)
            .border(1.dp, if (selected) SaffronOrange else BorderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else NavyBlue,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
fun MethodSelectItem(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) SaffronOrange else Color.White)
            .border(1.dp, if (selected) SaffronOrange else BorderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else NavyBlue,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

// =================================================================
// SCREEN 10: MY PROFILE SCREEN
// =================================================================
@Composable
fun MyProfileScreen(
    navController: NavController,
    viewModel: LobbyViewModel
) {
    var activeSubScreen by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = activeSubScreen != null) {
        activeSubScreen = null
    }

    if (activeSubScreen != null) {
        when (activeSubScreen) {
            "personal_details" -> PersonalDetailsSubScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
            "ongoing_cases" -> OngoingCasesSubScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
            "payment_keys" -> PaymentKeysSubScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
            "help_support" -> HelpSupportSubScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
            "permissions_privacy" -> PermissionsPrivacySubScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
            "admin_panel" -> AdminPanelSubScreen(viewModel = viewModel, onBack = { activeSubScreen = null })
        }
    } else {
        val coroutineScope = rememberCoroutineScope()
        val activeUser by viewModel.currentUser.collectAsState()
        val lawyerEntity by viewModel.currentLawyer.collectAsState()
        val context = LocalContext.current
        var showPhotoSheet by remember { mutableStateOf(false) }

        var tempPhotoFile by remember { mutableStateOf<File?>(null) }
        var tempPhotoUri by remember { mutableStateOf<Uri?>(null) }

        val cameraLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.TakePicture(),
            onResult = { success ->
                if (success && tempPhotoFile != null) {
                    viewModel.updateProfilePhoto(tempPhotoFile!!.absolutePath)
                }
            }
        )

        val galleryLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri ->
                if (uri != null) {
                    val path = saveUriToInternalStorage(context, uri)
                    if (path.isNotEmpty()) {
                        viewModel.updateProfilePhoto(path)
                    }
                }
            }
        )

        if (showPhotoSheet) {
            PhotoSourceBottomSheet(
                onDismissRequest = { showPhotoSheet = false },
                onTakePhoto = {
                    val (file, uri) = createTargetFileUri(context)
                    tempPhotoFile = file
                    tempPhotoUri = uri
                    cameraLauncher.launch(uri)
                },
                onChooseGallery = {
                    galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            )
        }

        // Office Showcase Photo launcher & state
        var showOfficePhotoSheet by remember { mutableStateOf(false) }
        var tempOfficePhotoFile by remember { mutableStateOf<File?>(null) }
        var tempOfficePhotoUri by remember { mutableStateOf<Uri?>(null) }

        val officeCameraLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.TakePicture(),
            onResult = { success ->
                if (success && tempOfficePhotoFile != null) {
                    viewModel.addOfficePhoto(tempOfficePhotoFile!!.absolutePath)
                }
            }
        )

        val officeGalleryLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri ->
                if (uri != null) {
                    val path = saveUriToInternalStorage(context, uri)
                    if (path.isNotEmpty()) {
                        viewModel.addOfficePhoto(path)
                    }
                }
            }
        )

        if (showOfficePhotoSheet) {
            PhotoSourceBottomSheet(
                onDismissRequest = { showOfficePhotoSheet = false },
                onTakePhoto = {
                    val (file, uri) = createTargetFileUri(context)
                    tempOfficePhotoFile = file
                    tempOfficePhotoUri = uri
                    officeCameraLauncher.launch(uri)
                },
                onChooseGallery = {
                    officeGalleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmCream)
        ) {
            // TOP Visual Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(6.dp, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(NavyBlue, Color(0xFF132A43))
                        ),
                        RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                    )
                    .statusBarsPadding()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(80.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(SaffronOrange)
                                .clickable { showPhotoSheet = true },
                            contentAlignment = Alignment.Center
                        ) {
                            if (!activeUser?.profilePhoto.isNullOrEmpty()) {
                                AsyncImage(
                                    model = activeUser?.profilePhoto,
                                    contentDescription = "Profile Photo",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(
                                    text = (activeUser?.name ?: "G").take(1).uppercase(),
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        IconButton(
                            onClick = { showPhotoSheet = true },
                            modifier = Modifier
                                .size(28.dp)
                                .align(Alignment.BottomEnd)
                                .background(SaffronOrange, CircleShape)
                                .border(1.5.dp, Color.White, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Edit Profile Photo",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = activeUser?.name ?: "Guest Client",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 21.sp,
                        fontFamily = FontFamily.Serif
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .background(SaffronOrange, RoundedCornerShape(4.dp))
                            .padding(horizontal = 10.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (activeUser?.role == "lawyer") "⚖️ Verified Lawyer" else "👤 Client Account",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            TricolorStripe(modifier = Modifier.shadow(2.dp))

            // Menu Rows (Scrollable vertical list)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))

                    if (activeUser?.role == "lawyer") {
                        val officePhotosList = if (lawyerEntity?.officePhotos.isNullOrEmpty()) {
                            emptyList()
                        } else {
                            lawyerEntity?.officePhotos!!.split(",").filter { it.isNotEmpty() }
                        }
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "💼 Office Showcase Photos",
                                            color = NavyBlue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            fontFamily = FontFamily.Serif
                                        )
                                        Text(
                                            text = "Add up to 5 photos of your office or chambers",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                    }
                                    if (officePhotosList.size < 5) {
                                        IconButton(
                                            onClick = { showOfficePhotoSheet = true },
                                            modifier = Modifier
                                                .size(36.dp)
                                                .background(SaffronOrange, CircleShape)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = "Add Office Photos",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                if (officePhotosList.isEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(90.dp)
                                            .background(WarmCream.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                            .border(BorderStroke(1.dp, BorderColor.copy(alpha = 0.5f)), RoundedCornerShape(8.dp))
                                            .clickable { showOfficePhotoSheet = true },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Default.PhotoLibrary,
                                                contentDescription = null,
                                                tint = Color.Gray.copy(alpha = 0.7f),
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "No office photos added. Tap to add! 🖼️",
                                                color = Color.Gray,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                } else {
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        items(officePhotosList) { photoPath ->
                                            Box(
                                                modifier = Modifier
                                                    .size(100.dp, 80.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            ) {
                                                AsyncImage(
                                                    model = photoPath,
                                                    contentDescription = "Office Photo",
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                                IconButton(
                                                    onClick = { viewModel.removeOfficePhoto(photoPath) },
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .align(Alignment.TopEnd)
                                                        .padding(2.dp)
                                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Close,
                                                        contentDescription = "Delete Photo",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                            }
                                        }
                                        
                                        if (officePhotosList.size < 5) {
                                            item {
                                                Box(
                                                    modifier = Modifier
                                                        .size(100.dp, 80.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(WarmCream.copy(alpha = 0.5f))
                                                        .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                                                        .clickable { showOfficePhotoSheet = true },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                        Icon(
                                                            imageVector = Icons.Default.AddAPhoto,
                                                            contentDescription = null,
                                                            tint = SaffronOrange,
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                        Spacer(modifier = Modifier.height(2.dp))
                                                        Text(
                                                            text = "Add more",
                                                            color = SaffronOrange,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Photo quota: ${officePhotosList.size} / 5 photos uploaded",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (officePhotosList.size >= 5) SaffronOrange else Color.Gray
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    
                    ProfileMenuRow(icon = Icons.Default.Person, title = "Personal Details", subtitle = "Securely manage legal identity keys") {
                        activeSubScreen = "personal_details"
                    }

                    ProfileMenuRow(icon = Icons.Default.List, title = "Ongoing Legal Cases", subtitle = "Tracking active or closed disputes") {
                        activeSubScreen = "ongoing_cases"
                    }

                    ProfileMenuRow(icon = Icons.Default.Payment, title = "Stored Payment Keys", subtitle = "Saved UPI IDs, cards and billing records") {
                        activeSubScreen = "payment_keys"
                    }

                    ProfileMenuRow(icon = Icons.Default.Info, title = "Help & Support Lobby", subtitle = "FAQ guide and instant assistance") {
                        activeSubScreen = "help_support"
                    }

                    ProfileMenuRow(icon = Icons.Default.Security, title = "Permissions & System Privacy", subtitle = "Manage system location checks") {
                        activeSubScreen = "permissions_privacy"
                    }

                    val activeUserEmail = activeUser?.email?.lowercase() ?: ""
                    val isAdmin = activeUserEmail == "admin@lawyerslobby.in" || activeUserEmail == "baazsingh232023@gmail.com"
                    if (isAdmin) {
                        ProfileMenuRow(icon = Icons.Default.Lock, title = "Admin Panel Console 🏛️", subtitle = "Approve practitioners, ban users & announcements") {
                            activeSubScreen = "admin_panel"
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.logout()
                            navController.navigate("auth") {
                                popUpTo(0) { inclusive = true }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp)
                            .height(44.dp)
                            .testTag("logout_button")
                    ) {
                        Text("Deauthorize / Logout (लॉग आउट करें)", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(30.dp))

                    Text(
                        text = "Lawyer's Lobby v1.0\nMade with ❤️ in India 🇮🇳",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun ProfileMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NavyBlue, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 14.sp)
            Text(subtitle, color = TextSecondary, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
    }
}

// =================================================================
// SCREEN 11: LAWYER REGISTRATION SUCCESS SCREEN
// =================================================================
@Composable
fun LawyerRegistrationSuccessScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Large Success Check
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(SuccessGreen.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text("🎉", fontSize = 56.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Profile Submitted! 👍",
                fontSize = 26.sp,
                color = NavyBlue,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Your practitioner profile is under official review",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                border = BorderStroke(1.dp, BorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("What happens next?", fontWeight = FontWeight.Bold, color = NavyBlue, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("1. Bar Council Verification: We cross-reference credentials with active registries.\n2. Go Live: Your profile goes live to millions looking for assistance.\n3. Case Inquiries: Start receiving direct callbacks securely.", fontSize = 12.sp, lineHeight = 20.sp, color = NavyBlue)
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Button(
                onClick = {
                    navController.navigate("home") {
                        popUpTo("auth") { inclusive = true }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("success_confirm"),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Go to My Profile", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// =================================================================
// SCREEN 12: EMERGENCY LAWYER SCREEN
// =================================================================
@Composable
fun EmergencyLawyerScreen(
    navController: NavController,
    viewModel: LobbyViewModel
) {
    val coroutineScope = rememberCoroutineScope()
    var clientName by remember { mutableStateOf("") }
    var phoneNo by remember { mutableStateOf("") }
    var selectedCity by remember { mutableStateOf("New Delhi") }
    var selectedEmergencyType by remember { mutableStateOf("Police Arrest / पुलिस गिरफ्तारी") }
    var caseNarrative by remember { mutableStateOf("") }

    var confirmationMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF151515)) // Urgent dark background
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Red)
                .statusBarsPadding()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Color.White)
            }
            Text("🚨 EMERGENCY HELPLINE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        TricolorStripe()

        Column(modifier = Modifier.padding(20.dp)) {
            Text("Request Instant Callback", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            Text("Available 24/7 with on-duty criminal litigators near you.", color = Color.LightGray, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(16.dp))

            if (confirmationMessage.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF138808))
                ) {
                    Text(
                        text = confirmationMessage,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(14.dp),
                        fontSize = 13.sp
                    )
                }
            }

            // Forms
            OutlinedTextField(
                value = clientName,
                onValueChange = { clientName = it },
                label = { Text("Your Name", color = Color.White) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = SaffronOrange,
                    unfocusedBorderColor = Color.LightGray
                ),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = phoneNo,
                onValueChange = { phoneNo = it },
                label = { Text("Phone Number (+91)", color = Color.White) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = SaffronOrange,
                    unfocusedBorderColor = Color.LightGray
                ),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("emergency_phone"),
                shape = RoundedCornerShape(8.dp)
            )

            // Select city dropdown with type search
            SearchableCityDropdown(
                label = "Emergency Location City",
                selectedCity = selectedCity,
                onCitySelected = { selectedCity = it },
                cities = viewModel.cities.map { it.cityName },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                isDarkTheme = true
            )

            // Select emergency type dropdown with live search
            SearchableEmergencyDropdown(
                label = "Emergency Category",
                selectedCategory = selectedEmergencyType,
                onCategorySelected = { selectedEmergencyType = it },
                categories = emergencyCategories,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                isDarkTheme = true
            )

            OutlinedTextField(
                value = caseNarrative,
                onValueChange = { caseNarrative = it },
                label = { Text("Brief description of emergency scenario", color = Color.White) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = SaffronOrange,
                    unfocusedBorderColor = Color.LightGray
                ),
                modifier = Modifier.fillMaxWidth().height(100.dp).padding(bottom = 20.dp),
                shape = RoundedCornerShape(8.dp)
            )

            Button(
                onClick = {
                    if (phoneNo.isEmpty()) {
                        confirmationMessage = "Warning: A contact number is required to dial a callback."
                        return@Button
                    }
                    coroutineScope.launch {
                        viewModel.submitEmergencyRequest(clientName, phoneNo, selectedCity, selectedEmergencyType, caseNarrative)
                        AnalyticsHelper.logEmergencyRequestSubmitted(selectedEmergencyType)
                        confirmationMessage = "🚨 Alert received! Police/Bail on-duty litigation advisor will dial +91 $phoneNo within 30 minutes! Stay safe."
                        caseNarrative = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("emergency_submit_btn"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("SEND EMERGENCY REQUEST 🚨", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

// =================================================================
// NEW SCREEN: PREMIUM AUTOMATED AI CHATBOT SCREEN (AIChatbot)
// =================================================================
@Composable
fun AIChatbotScreen(navController: NavController, viewModel: LobbyViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isSending by viewModel.isSendingMessage.collectAsState()
    val activeUser by viewModel.currentUser.collectAsState()
    val isLawyerMode = activeUser?.role == "lawyer"

    var currentInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Scroll to bottom when new messages arrive
    LaunchedEffect(chatMessages.size, isSending) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    LaunchedEffect(activeUser) {
        viewModel.initGreetings(activeUser)
    }

    // Dynamic filtering of layers based on user's case description keywords or locations
    val allLawyers by viewModel.allLawyers.collectAsState()
    val matchedLawyers = remember(chatMessages, allLawyers) {
        val lastUserMessage = chatMessages.findLast { it.second }?.first?.lowercase() ?: ""
        if (lastUserMessage.isNotEmpty() && !isLawyerMode) {
            allLawyers.filter { lawyer ->
                lawyer.specialisation.contains(lastUserMessage, ignoreCase = true) ||
                lawyer.caseTypes.contains(lastUserMessage, ignoreCase = true) ||
                lawyer.city.contains(lastUserMessage, ignoreCase = true) ||
                lastUserMessage.contains(lawyer.city.lowercase()) ||
                (lastUserMessage.contains("bail") && (lawyer.specialisation.contains("criminal", ignoreCase = true) || lawyer.caseTypes.contains("bail", ignoreCase = true))) ||
                (lastUserMessage.contains("divorce") && lawyer.specialisation.contains("family", ignoreCase = true)) ||
                ((lastUserMessage.contains("business") || lastUserMessage.contains("corporate") || lastUserMessage.contains("startup") || lastUserMessage.contains("contract")) && lawyer.specialisation.contains("corporate", ignoreCase = true)) ||
                (lastUserMessage.contains("tax") && lawyer.specialisation.contains("tax", ignoreCase = true)) ||
                (lastUserMessage.contains("cyber") && (lawyer.specialisation.contains("cyber", ignoreCase = true) || lawyer.caseTypes.contains("cyber", ignoreCase = true)))
            }.take(4)
        } else {
            emptyList()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Luxury TopBar Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(6.dp, RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(NavyBlue, Color(0xFF132A43))
                    ),
                    RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                )
                .statusBarsPadding()
                .padding(vertical = 16.dp, horizontal = 20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.12f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isLawyerMode) "🏛️ NyayaCopilot AI" else "🤖 NyayaMitra AI",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        fontFamily = FontFamily.Serif
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(SuccessGreen, CircleShape)
                        )
                        Text(
                            text = if (isLawyerMode) "Advocate Counsel Protocol Online" else "Citizen Smart Guide Mode Online",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.clearChatHistory(isLawyerMode) },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.12f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear Chat",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        TricolorStripe(modifier = Modifier.shadow(2.dp))

        // Quick Suggestion Chips for luxury fast prompt input
        val suggestionChips = if (isLawyerMode) {
            listOf(
                "Bail Procedure under Sec 480 BNSS",
                "Draft Indemnification Clause Sample",
                "Sec 138 NI Act Legal Notice guidelines",
                "Digital Signature evidence admissibility"
            )
        } else {
            listOf(
                "My rights if arrested by police",
                "Mutual Consent Divorce timeline",
                "How to file commercial recovery suit",
                "What is a Zero FIR in India?"
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            // Main Messages Scroller
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(top = 16.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(chatMessages) { pair ->
                    val messageText = pair.first
                    val isUser = pair.second
                    
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            shape = if (isUser) {
                                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 2.dp)
                            } else {
                                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 2.dp)
                            },
                            color = if (isUser) SaffronOrange else Color.White,
                            border = if (isUser) null else BorderStroke(1.dp, BorderColor),
                            shadowElevation = 1.dp,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = messageText,
                                    color = if (isUser) Color.White else Color.Black,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                if (isSending) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                        ) {
                            CircularProgressIndicator(
                                color = NavyBlue,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                "Analyzing Indian legal codes...",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                style = androidx.compose.ui.text.TextStyle(fontStyle = FontStyle.Italic)
                            )
                        }
                    }
                }
            }

            if (matchedLawyers.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "⚖️ AI ASSOCIATE MATCH ES (TAP TO CONSULT)",
                    fontSize = 9.sp,
                    color = SaffronOrange,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 6.dp, start = 4.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    items(matchedLawyers) { lawyer ->
                        Card(
                            modifier = Modifier
                                .width(250.dp)
                                .clickable {
                                    viewModel.selectLawyer(lawyer.uid)
                                    navController.navigate("profile_detail/${lawyer.uid}")
                                },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (!lawyer.profilePhoto.isNullOrBlank()) {
                                    AsyncImage(
                                        model = lawyer.profilePhoto,
                                        contentDescription = "Advocate ${lawyer.name}",
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, NavyBlue.copy(alpha = 0.2f), CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(NavyBlue.copy(alpha = 0.1f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = lawyer.name.take(1),
                                            color = NavyBlue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            fontFamily = FontFamily.Serif
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.width(10.dp))
                                
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Adv. ${lawyer.name}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyBlue,
                                        maxLines = 1,
                                        fontFamily = FontFamily.Serif
                                    )
                                    Text(
                                        text = lawyer.specialisation,
                                        fontSize = 9.sp,
                                        color = IndiaGreen,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "${lawyer.rating}★",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SaffronOrange
                                        )
                                        Text(
                                            text = "• ${lawyer.city}",
                                            fontSize = 8.sp,
                                            color = Color.Gray
                                        )
                                        Text(
                                            text = "• ₹${lawyer.consultationFee}",
                                            fontSize = 9.sp,
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Suggestions Carousel directly above the input bar
            Text(
                "SUGGESTED DISCOVERY PROMPTS",
                fontSize = 9.sp,
                color = TextSecondary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 6.dp, start = 4.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                items(suggestionChips) { chipText ->
                    Surface(
                        modifier = Modifier.clickable {
                            currentInput = chipText
                        },
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, BorderColor),
                        tonalElevation = 1.dp
                    ) {
                        Text(
                            text = chipText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NavyBlue,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Luxury Bottom Send Area
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = currentInput,
                    onValueChange = { currentInput = it },
                    placeholder = { Text("Ask your legal question...", color = Color.Gray, fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color.White, RoundedCornerShape(14.dp)),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = SaffronOrange,
                        unfocusedBorderColor = BorderColor
                    ),
                    shape = RoundedCornerShape(14.dp),
                    maxLines = 3,
                    singleLine = false
                )

                IconButton(
                    onClick = {
                        if (currentInput.isNotBlank()) {
                            viewModel.sendChatMessage(currentInput, isLawyerMode)
                            AnalyticsHelper.logNyayamitraQuestionAsked(currentInput)
                            currentInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(NavyBlue, RoundedCornerShape(14.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
        val showAdsByCheck = activeUser?.email != "baazsingh232023@gmail.com"
        if (showAdsByCheck) {
            BannerAd(modifier = Modifier.fillMaxWidth())
        }
    }
}

// =================================================================
// MY PROFILE SUB-SCREENS
// =================================================================

@Composable
fun PersonalDetailsSubScreen(
    viewModel: LobbyViewModel,
    onBack: () -> Unit
) {
    val activeUser by viewModel.currentUser.collectAsState()
    val lawyerEntity by viewModel.currentLawyer.collectAsState()

    var name by remember(activeUser) { mutableStateOf(activeUser?.name ?: "") }
    var phone by remember(activeUser) { mutableStateOf(activeUser?.phone ?: "") }
    var city by remember(activeUser) { mutableStateOf(activeUser?.city ?: "") }
    val email = activeUser?.email ?: ""

    // Lawyer-specific fields
    var barCouncilNumber by remember(lawyerEntity) { mutableStateOf(lawyerEntity?.barCouncilNumber ?: "") }
    var specialisation by remember(lawyerEntity) { mutableStateOf(lawyerEntity?.specialisation ?: "") }
    var consultationFee by remember(lawyerEntity) { mutableStateOf(lawyerEntity?.consultationFee?.toString() ?: "1000") }
    var languages by remember(lawyerEntity) { mutableStateOf(lawyerEntity?.languages ?: "") }

    var saveSuccessMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Personal Details",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif
            )
        }
        TricolorStripe()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Edit Core Identity Records",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )
            Text(
                text = "Updating these fields modifies your profile visible to clients/colleagues inside the Lawyers Lobby directory.",
                fontSize = 13.sp,
                color = TextSecondary
            )

            if (saveSuccessMessage.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = saveSuccessMessage, color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            // FIELDS
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Lawyer/Client Name") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NavyBlue,
                    unfocusedTextColor = NavyBlue,
                    focusedBorderColor = SaffronOrange,
                    unfocusedBorderColor = Color.Gray
                ),
                shape = RoundedCornerShape(8.dp),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = NavyBlue) }
            )

            OutlinedTextField(
                value = email,
                onValueChange = {},
                label = { Text("Logon Email Address (Permanent)") },
                modifier = Modifier.fillMaxWidth(),
                enabled = false,
                colors = OutlinedTextFieldDefaults.colors(
                    disabledTextColor = Color.Gray,
                    disabledBorderColor = Color.LightGray,
                    disabledLabelColor = Color.Gray
                ),
                shape = RoundedCornerShape(8.dp),
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = Color.Gray) }
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Contact Number") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = NavyBlue,
                    unfocusedTextColor = NavyBlue,
                    focusedBorderColor = SaffronOrange,
                    unfocusedBorderColor = Color.Gray
                ),
                shape = RoundedCornerShape(8.dp),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = NavyBlue) }
            )

            SearchableCityDropdown(
                label = "Primary Operating City",
                selectedCity = city,
                onCitySelected = { city = it },
                cities = viewModel.cities.map { it.cityName },
                modifier = Modifier.fillMaxWidth()
            )

            // Lawyer-specific Block
            if (activeUser?.role == "lawyer") {
                HorizontalDivider(color = Color.LightGray, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                
                Text(
                    text = "Professional Accreditation Records",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyBlue
                )

                OutlinedTextField(
                    value = barCouncilNumber,
                    onValueChange = { barCouncilNumber = it },
                    label = { Text("Bar Council of India License No.") },
                    placeholder = { Text("e.g. MAH/7123/2019") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NavyBlue,
                        unfocusedTextColor = NavyBlue,
                        focusedBorderColor = SaffronOrange,
                        unfocusedBorderColor = Color.Gray
                    ),
                    shape = RoundedCornerShape(8.dp),
                    leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = NavyBlue) }
                )

                OutlinedTextField(
                    value = specialisation,
                    onValueChange = { specialisation = it },
                    label = { Text("Primary Specialisation Class") },
                    placeholder = { Text("e.g. Criminal Defence, Property Law") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NavyBlue,
                        unfocusedTextColor = NavyBlue,
                        focusedBorderColor = SaffronOrange,
                        unfocusedBorderColor = Color.Gray
                    ),
                    shape = RoundedCornerShape(8.dp),
                    leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, tint = NavyBlue) }
                )

                OutlinedTextField(
                    value = consultationFee,
                    onValueChange = { consultationFee = it.filter { c -> c.isDigit() } },
                    label = { Text("Initial Consultation Fee (₹)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NavyBlue,
                        unfocusedTextColor = NavyBlue,
                        focusedBorderColor = SaffronOrange,
                        unfocusedBorderColor = Color.Gray
                    ),
                    shape = RoundedCornerShape(8.dp),
                    leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = NavyBlue) }
                )

                OutlinedTextField(
                    value = languages,
                    onValueChange = { languages = it },
                    label = { Text("Practiced Languages (Comma separated)") },
                    placeholder = { Text("e.g. English, Hindi, Marathi") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = NavyBlue,
                        unfocusedTextColor = NavyBlue,
                        focusedBorderColor = SaffronOrange,
                        unfocusedBorderColor = Color.Gray
                    ),
                    shape = RoundedCornerShape(8.dp),
                    leadingIcon = { Icon(Icons.Default.List, contentDescription = null, tint = NavyBlue) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (name.isBlank() || phone.isBlank() || city.isBlank()) {
                        saveSuccessMessage = "Please complete Name, Phone, and City fields."
                        return@Button
                    }
                    val parsedFee = consultationFee.toIntOrNull() ?: 1000
                    viewModel.updateProfile(
                        name = name,
                        phone = phone,
                        city = city,
                        barCouncilNumber = barCouncilNumber,
                        specialisation = specialisation,
                        consultationFee = parsedFee,
                        languages = languages
                    )
                    saveSuccessMessage = "Profile metrics saved offline securely!"
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save & Complete Profile Updates", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun OngoingCasesSubScreen(
    viewModel: LobbyViewModel,
    onBack: () -> Unit
) {
    val cases by viewModel.ongoingCases.collectAsState()
    
    var showAddDialog by remember { mutableStateOf(false) }
    var newClientName by remember { mutableStateOf("") }
    var newCaseType by remember { mutableStateOf("") }
    var newDate by remember { mutableStateOf("2026-06-06") }
    var newStatus by remember { mutableStateOf("Active") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Ongoing Legal Cases",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif
            )
        }
        TricolorStripe()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Active Case Inventory",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )
                    Text(
                        text = "Track litigations and mediation schedules",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
                
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Case", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (cases.isEmpty()) {
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.List, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(60.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No ongoing cases registered yet", color = Color.Gray, fontSize = 14.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(cases) { legalCase ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(NavyBlue.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = legalCase.clientName.take(1).uppercase(),
                                                color = NavyBlue,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = legalCase.clientName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = NavyBlue
                                            )
                                            Text(
                                                text = "Filed on: ${legalCase.date}",
                                                fontSize = 12.sp,
                                                color = TextSecondary
                                            )
                                        }
                                    }

                                    // Status Badge
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (legalCase.status == "Active") SuccessGreen.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = legalCase.status,
                                            color = if (legalCase.status == "Active") SuccessGreen else Color.DarkGray,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Case Dispute: " + legalCase.caseType,
                                    color = NavyBlue,
                                    fontSize = 13.sp
                                )

                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { viewModel.toggleCaseStatus(legalCase.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp)
                                    ) {
                                        Text(
                                            text = if (legalCase.status == "Active") "Mark Closed" else "Mark Active",
                                            color = SaffronOrange,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = { viewModel.deleteCase(legalCase.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Case", tint = ErrorRed, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Record New Ongoing Case", fontWeight = FontWeight.Bold, color = NavyBlue) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = newClientName,
                        onValueChange = { newClientName = it },
                        label = { Text("Client Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SaffronOrange)
                    )
                    OutlinedTextField(
                        value = newCaseType,
                        onValueChange = { newCaseType = it },
                        label = { Text("Case Type (Dispute)") },
                        placeholder = { Text("e.g. Criminal Bail Hearing") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SaffronOrange)
                    )
                    OutlinedTextField(
                        value = newDate,
                        onValueChange = { newDate = it },
                        label = { Text("Filing Date (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SaffronOrange)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newClientName.isNotBlank() && newCaseType.isNotBlank()) {
                            viewModel.addOngoingCase(newClientName, newCaseType, newDate, newStatus)
                            newClientName = ""
                            newCaseType = ""
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Add Case Records", color = SaffronOrange, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun PaymentKeysSubScreen(
    viewModel: LobbyViewModel,
    onBack: () -> Unit
) {
    val keys by viewModel.paymentKeys.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    var inputType by remember { mutableStateOf("UPI") }
    var inputLabel by remember { mutableStateOf("") }
    var inputValue by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Stored Payment Keys",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif
            )
        }
        TricolorStripe()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "UPI Accounts & Saved Methods",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )
                    Text(
                        text = "Authorized keys for prompt court fee deposits.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Key", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (keys.isEmpty()) {
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(60.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No payment keys saved yet", color = Color.Gray, fontSize = 14.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(keys) { key ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (key.type == "UPI") SaffronOrange.copy(alpha = 0.12f)
                                                else NavyBlue.copy(alpha = 0.12f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (key.type == "UPI") "⚡" else "💳",
                                            fontSize = 20.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = key.label,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = NavyBlue
                                        )
                                        Text(
                                            text = key.value,
                                            fontSize = 13.sp,
                                            color = TextSecondary,
                                            fontFamily = if (key.type == "Card") FontFamily.Monospace else FontFamily.Default
                                        )
                                    }
                                }

                                IconButton(onClick = { viewModel.deletePaymentKey(key.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete key", tint = ErrorRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Stored Payment Key", fontWeight = FontWeight.Bold, color = NavyBlue) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { inputType = "UPI" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (inputType == "UPI") NavyBlue else Color.LightGray
                            )
                        ) {
                            Text("UPI PIN ID")
                        }
                        Button(
                            onClick = { inputType = "Card" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (inputType == "Card") NavyBlue else Color.LightGray
                            )
                        ) {
                            Text("Credit/Debit Card")
                        }
                    }

                    OutlinedTextField(
                        value = inputLabel,
                        onValueChange = { inputLabel = it },
                        label = { Text("Account Label (e.g., GPay Personal)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SaffronOrange)
                    )

                    OutlinedTextField(
                        value = inputValue,
                        onValueChange = { inputValue = it },
                        label = { Text(if (inputType == "UPI") "UPI VPA ID (e.g. advocate@okhdfc)" else "Card Number (16 Digits)") },
                        placeholder = { Text(if (inputType == "UPI") "advocate.sharma@paytm" else "4111 2222 3333 4444") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SaffronOrange)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (inputLabel.isNotBlank() && inputValue.isNotBlank()) {
                            val finalValue = if (inputType == "Card") {
                                val clean = inputValue.filter { it.isDigit() }
                                if (clean.length >= 4) "•••• •••• •••• " + clean.takeLast(4) else inputValue
                            } else {
                                inputValue
                            }
                            viewModel.addPaymentKey(inputType, inputLabel, finalValue)
                            inputLabel = ""
                            inputValue = ""
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Securely Link Key", color = SaffronOrange, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun HelpSupportSubScreen(
    viewModel: LobbyViewModel,
    onBack: () -> Unit
) {
    var showTicketDialog by remember { mutableStateOf(false) }
    var ticketProblemText by remember { mutableStateOf("") }
    var ticketSuccessMessage by remember { mutableStateOf("") }

    val faqItems = listOf(
        "Is My Legal Data Kept Private?" to "Absolutely. All ongoing case entries, UPI credentials, and licensing details are stored securely using local Android Room sandbox environments. Your sensitive information is never shared with any background advertisers.",
        "How Do I Get the Verified Advocate Tag?" to "We sync directly with State Bar Councils. To check your status, navigate to Personal Details and save your valid BCI accreditation/license number (e.g. MAH/3144/2021). Our servers will flag you 'Verified' upon matching records.",
        "Are e-Court Fees Paid instantly?" to "Yes. Court fee, chalan, and stamp-duty payments initiated inside 'Quick Payments' route immediately through authorized Bharat UPI gateways. A digital receipt with transaction hash gets generated instantly offline.",
        "How to coordinate in Legal SOS emergency?" to "When you tap the 'SOS Panic' trigger, the system broadcast sends critical alerts with your current GPS coordinate grid to 5 active, top-rated criminal lawyers located within a 5km radius for instant legal mediation."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Help & Support Lobby",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif
            )
        }
        TricolorStripe()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Frequently Checked Inquiries",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )
            Text(
                text = "Tap on any question card below to unravel comprehensive explanations regarding features, payments, or verification.",
                fontSize = 12.sp,
                color = TextSecondary
            )

            // Accordion Items
            faqItems.forEach { (question, answer) ->
                var expanded by remember { mutableStateOf(false) }
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = question,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = NavyBlue,
                                modifier = Modifier.weight(0.9f)
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = SaffronOrange,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        
                        AnimatedVisibility(visible = expanded) {
                            Column {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = answer,
                                    fontSize = 13.sp,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = NavyBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Need Instant Human Assistance?",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Generate a priority concierge ticket. Our litigation coordinators will contact you within 2 business hours.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (ticketSuccessMessage.isNotEmpty()) {
                        Text(
                            text = ticketSuccessMessage,
                            color = SaffronOrange,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Button(
                        onClick = { showTicketDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Submit App Feedback & Bug Report", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    if (showTicketDialog) {
        val sheetContext = LocalContext.current
        AppFeedbackDialog(
            onDismissRequest = { showTicketDialog = false },
            onFeedbackSubmitted = { category, rating, description ->
                sendFeedbackEmail(sheetContext, category, rating, description)
                showTicketDialog = false
                ticketSuccessMessage = "Feedback report draft generated successfully! Sent to baazsingh232023@gmail.com"
            }
        )
    }
}

@Composable
fun PermissionsPrivacySubScreen(
    viewModel: LobbyViewModel,
    onBack: () -> Unit
) {
    val notesEnabled by viewModel.notificationsEnabled.collectAsState()
    val locEnabled by viewModel.locationEnabled.collectAsState()
    val camEnabled by viewModel.cameraEnabled.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Permissions & Privacy",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif
            )
        }
        TricolorStripe()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "System Access Authorizations",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyBlue
            )
            Text(
                text = "Configure low-level Android device permissions required for active cases, locator features, or client-lawyer scheduling.",
                fontSize = 13.sp,
                color = TextSecondary
            )

            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f), thickness = 0.5.dp)

            // 1. Notifications Row
            PermissionToggleItem(
                title = "Push Notifications (पुश सूचनाएं)",
                description = "Receive instant alerts regarding active consultation updates, ongoing case schedules, and court date warnings.",
                enabled = notesEnabled,
                onToggle = { viewModel.toggleNotificationPermission() }
            )

            // 2. Location Row
            PermissionToggleItem(
                title = "Access Device Location (स्थान अनुमति)",
                description = "Required to match you with criminal advocates in close proximity and broadcast SOS panic location files in legal distress.",
                enabled = locEnabled,
                onToggle = { viewModel.toggleLocationPermission() }
            )

            // 3. Camera Row
            PermissionToggleItem(
                title = "Camera Access (कैमरा एक्सेस)",
                description = "Mandatory for scanning physical QR payments, attaching case chalan files, or taking official identity headshots.",
                enabled = camEnabled,
                onToggle = { viewModel.toggleCameraPermission() }
            )
            
            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f), thickness = 0.5.dp)

            Card(
                colors = CardDefaults.cardColors(containerColor = SaffronOrange.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = SaffronOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Security Seal: All permissions respect Android runtime rules. Disabling any item instantly stops relevant background threads.",
                        color = NavyBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionToggleItem(
    title: String,
    description: String,
    enabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(0.75f)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = NavyBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )
        }
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Switch(
            checked = enabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = SaffronOrange,
                uncheckedThumbColor = Color.LightGray,
                uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
            )
        )
    }
}

// ==========================================
// ADMIN PANEL CONSOLE SUB-SCREEN & VIEWS
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelSubScreen(
    viewModel: LobbyViewModel,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("📊 Stats", "⚖️ Lawyers", "👤 Clients", "🚫 Blacklist", "⭐ Reviews", "📢 Broadcast", "🚨 Emergencies")

    val allLawyers by viewModel.allLawyers.collectAsState()
    val allReviews by viewModel.allReviews.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val allEmergencyRequests by viewModel.allEmergencyRequests.collectAsState()
    val featuredLawyerIds by viewModel.featuredLawyerIds.collectAsState()
    val announcements by viewModel.announcements.collectAsState()

    val context = LocalContext.current
    var adminMessage by remember { mutableStateOf("") }

    LaunchedEffect(adminMessage) {
        if (adminMessage.isNotEmpty()) {
            android.widget.Toast.makeText(context, adminMessage, android.widget.Toast.LENGTH_LONG).show()
            adminMessage = ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmCream)
    ) {
        // TOP Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyBlue)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Admin Panel Console 🏛️",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                fontFamily = FontFamily.Serif
            )
        }
        TricolorStripe()

        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = NavyBlue,
            edgePadding = 16.dp
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp,
                            color = if (selectedTab == index) NavyBlue else Color.Gray
                        )
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> AdminDashboardStatsView(
                    allLawyers = allLawyers,
                    allUsers = allUsers,
                    allReviews = allReviews,
                    allEmergencyRequests = allEmergencyRequests
                )
                1 -> AdminLawyerManagementView(
                    allLawyers = allLawyers,
                    featuredLawyerIds = featuredLawyerIds,
                    viewModel = viewModel,
                    onShowMessage = { adminMessage = it }
                )
                2 -> AdminClientManagementView(
                    allUsers = allUsers,
                    viewModel = viewModel,
                    onShowMessage = { adminMessage = it }
                )
                3 -> AdminBlacklistManagementView(
                    viewModel = viewModel,
                    onShowMessage = { adminMessage = it }
                )
                4 -> AdminReviewsModerationView(
                    allReviews = allReviews,
                    viewModel = viewModel,
                    onShowMessage = { adminMessage = it }
                )
                5 -> AdminAnnouncementsView(
                    announcements = announcements,
                    viewModel = viewModel,
                    onShowMessage = { adminMessage = it }
                )
                6 -> AdminEmergenciesView(
                    allEmergencyRequests = allEmergencyRequests,
                    allLawyers = allLawyers,
                    viewModel = viewModel,
                    onShowMessage = { adminMessage = it }
                )
            }
        }
    }
}

@Composable
fun AdminDashboardStatsView(
    allLawyers: List<LawyerEntity>,
    allUsers: List<UserEntity>,
    allReviews: List<ReviewEntity>,
    allEmergencyRequests: List<EmergencyRequestEntity>
) {
    val totalLawyers = allLawyers.size
    val verifiedLawyers = allLawyers.count { it.isVerified && it.isActive }
    val pendingLawyers = allLawyers.count { !it.isVerified && it.isActive }
    val bannedLawyers = allLawyers.count { !it.isActive }

    val clients = allUsers.filter { it.role == "client" }
    val activeClientsCount = clients.count { it.isActive }
    val bannedClientsCount = clients.count { !it.isActive }

    val totalReviews = allReviews.size
    val verifiedReviews = allReviews.count { it.isVerifiedClient }

    // Enhanced metrics math
    val curTime = System.currentTimeMillis()
    val startOfToday = curTime - (24 * 60 * 60 * 1000)
    val startOfWeek = curTime - (7 * 24 * 60 * 60 * 1000)
    val startOfMonth = curTime - (30L * 24 * 60 * 60 * 1000)

    val registeredUsersToday = allUsers.count { it.createdAt >= startOfToday }
    val registeredUsersThisWeek = allUsers.count { it.createdAt >= startOfWeek }
    val registeredUsersThisMonth = allUsers.count { it.createdAt >= startOfMonth }

    val newLawyersRegisteredToday = allLawyers.count { it.createdAt >= startOfToday }
    val pendingVerificationsCount = pendingLawyers
    val bannedAccountsCount = bannedLawyers + bannedClientsCount

    val emergencyRequestsToday = allEmergencyRequests.count { it.createdAt >= startOfToday }
    
    // Dynamic simulated metrics based on stable computation:
    val mostSearchedCity = "New Delhi"
    val mostSearchedCaseType = "Criminal Defence"
    val nyayaMitraQuestionsToday = ((curTime / 10000) % 20 + 25).toString()
    val activeUsersRightNow = (((curTime / 60000) % 15) + 38).toString()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner Header
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyBlue),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("📊 Advanced Governance Analytics", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Live dashboard tracking client journeys, practitioner velocity, and legal directory diagnostics.", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            }
        }

        Text(
            text = "Registration Statistics",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = NavyBlue,
            fontFamily = FontFamily.Serif
        )

        // Row of Registration Counts
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                StatCard(
                    title = "Registered Today",
                    value = registeredUsersToday.toString(),
                    subtitle = "Last 24 hours",
                    accentColor = NavyBlue,
                    icon = "⏰"
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                StatCard(
                    title = "Registered This Week",
                    value = registeredUsersThisWeek.toString(),
                    subtitle = "Last 7 days",
                    accentColor = IndiaGreen,
                    icon = "📅"
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                StatCard(
                    title = "Registered This Month",
                    value = registeredUsersThisMonth.toString(),
                    subtitle = "Last 30 days",
                    accentColor = SaffronOrange,
                    icon = "💼"
                )
            }
        }

        Text(
            text = "Practitioners & Moderation Diagnostics",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = NavyBlue,
            fontFamily = FontFamily.Serif
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(240.dp) // Fixed height block for Grid layout
        ) {
            item {
                StatCard(
                    title = "New Lawyers Today",
                    value = newLawyersRegisteredToday.toString(),
                    subtitle = "Lawyers registered",
                    accentColor = NavyBlue,
                    icon = "⚖️"
                )
            }
            item {
                StatCard(
                    title = "Pending Verification",
                    value = pendingVerificationsCount.toString(),
                    subtitle = "Awaiting review",
                    accentColor = SaffronOrange,
                    icon = "⌛"
                )
            }
            item {
                StatCard(
                    title = "Banned Accounts",
                    value = bannedAccountsCount.toString(),
                    subtitle = "Banned/Suspended",
                    accentColor = ErrorRed,
                    icon = "🚫"
                )
            }
            item {
                StatCard(
                    title = "Active Users Now",
                    value = activeUsersRightNow,
                    subtitle = "Last 5 minutes",
                    accentColor = IndiaGreen,
                    icon = "🟢"
                )
            }
        }

        Text(
            text = "Marketplace Insights & Intelligence",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = NavyBlue,
            fontFamily = FontFamily.Serif
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.height(240.dp)
        ) {
            item {
                StatCard(
                    title = "Most Searched City",
                    value = mostSearchedCity,
                    subtitle = "Highest volume",
                    accentColor = NavyBlue,
                    icon = "📍"
                )
            }
            item {
                StatCard(
                    title = "Most Searched Case",
                    value = mostSearchedCaseType,
                    subtitle = "Trending query",
                    accentColor = IndiaGreen,
                    icon = "📂"
                )
            }
            item {
                StatCard(
                    title = "Emergency Requests",
                    value = emergencyRequestsToday.toString(),
                    subtitle = "Alert trigger rate",
                    accentColor = ErrorRed,
                    icon = "🚨"
                )
            }
            item {
                StatCard(
                    title = "NyayaMitra Today",
                    value = nyayaMitraQuestionsToday,
                    subtitle = "AI interactions",
                    accentColor = Color(0xFF673AB7),
                    icon = "🤖"
                )
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    icon: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderColor),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(text = icon, fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor,
                fontFamily = FontFamily.Serif
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLawyerManagementView(
    allLawyers: List<LawyerEntity>,
    featuredLawyerIds: Set<String>,
    viewModel: LobbyViewModel,
    onShowMessage: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("All") } // "All", "Pending", "Verified", "Banned"
    var editingLawyer by remember { mutableStateOf<LawyerEntity?>(null) }

    // Advanced admin dialog states
    var viewingFullProfileLawyer by remember { mutableStateOf<LawyerEntity?>(null) }
    var rejectingLawyerReasonByAdmin by remember { mutableStateOf<LawyerEntity?>(null) }
    var suspendingUserByAdmin by remember { mutableStateOf<LawyerEntity?>(null) }
    var deletingLawyerForConfirm by remember { mutableStateOf<LawyerEntity?>(null) }

    // Active multi-selection state
    var selectedLawyerUids by remember { mutableStateOf(setOf<String>()) }

    // Admin notes dialog
    var addingNoteForLawyer by remember { mutableStateOf<LawyerEntity?>(null) }
    var noteInputString by remember { mutableStateOf("") }

    val adminNotes by viewModel.adminNotes.collectAsState()

    val filtered = allLawyers.filter { lawyer ->
        val matchesSearch = lawyer.name.contains(searchQuery, ignoreCase = true) ||
                lawyer.barCouncilNumber.contains(searchQuery, ignoreCase = true) ||
                lawyer.specialisation.contains(searchQuery, ignoreCase = true)

        val matchesStatus = when (statusFilter) {
            "Pending" -> !lawyer.isVerified && lawyer.isActive
            "Verified" -> lawyer.isVerified && lawyer.isActive
            "Banned" -> !lawyer.isActive
            else -> true
        }

        matchesSearch && matchesStatus
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search Bar Council No, Name, Specialisation...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyBlue) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            shape = RoundedCornerShape(8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All", "Pending", "Verified", "Banned").forEach { status ->
                val selected = statusFilter == status
                Card(
                    onClick = { statusFilter = status },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) NavyBlue else Color.White
                    ),
                    border = BorderStroke(1.dp, if (selected) NavyBlue else BorderColor),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 8.dp).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = status,
                            color = if (selected) Color.White else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- BULK ACTIONS FLOATING TOOLBAR ---
        if (selectedLawyerUids.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyBlue),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(8.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${selectedLawyerUids.size} Selected",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                selectedLawyerUids.forEach { uid ->
                                    viewModel.updateLawyerVerification(uid, true)
                                }
                                onShowMessage("Bulk Approved ${selectedLawyerUids.size} practitioners!")
                                selectedLawyerUids = emptySet()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndiaGreen),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("APPROVE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                selectedLawyerUids.forEach { uid ->
                                    viewModel.updateLawyerActiveStatus(uid, false)
                                    viewModel.addToBlacklist("", "")
                                }
                                onShowMessage("Bulk Banned ${selectedLawyerUids.size} practitioners!")
                                selectedLawyerUids = emptySet()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("BAN", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                selectedLawyerUids.forEach { uid ->
                                    viewModel.deleteAccountByAdmin(uid)
                                }
                                onShowMessage("Bulk Deleted ${selectedLawyerUids.size} accounts from system!")
                                selectedLawyerUids = emptySet()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("DEL", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No matching practitioners found.", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered) { lawyer ->
                    val isFeatured = featuredLawyerIds.contains(lawyer.uid)
                    val cardBorder = if (isFeatured) {
                        BorderStroke(1.5.dp, SaffronOrange)
                    } else {
                        BorderStroke(1.dp, BorderColor)
                    }
                    val isSelected = selectedLawyerUids.contains(lawyer.uid)

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = cardBorder,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = { checked ->
                                            selectedLawyerUids = if (checked) {
                                                selectedLawyerUids + lawyer.uid
                                            } else {
                                                selectedLawyerUids - lawyer.uid
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = lawyer.name,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyBlue,
                                        fontFamily = FontFamily.Serif
                                    )
                                    if (lawyer.isVerified && lawyer.isActive) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.Verified,
                                            contentDescription = "Verified Status",
                                            tint = IndiaGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    if (isFeatured) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "Featured Advantage",
                                            tint = SaffronOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Badge(
                                    containerColor = when {
                                        !lawyer.isActive -> ErrorRed
                                        !lawyer.isVerified -> SaffronOrange
                                        else -> IndiaGreen.copy(alpha = 0.2f)
                                    },
                                    contentColor = when {
                                        !lawyer.isActive -> Color.White
                                        !lawyer.isVerified -> Color.White
                                        else -> IndiaGreen
                                    }
                                ) {
                                    Text(
                                        text = when {
                                            !lawyer.isActive -> "BANNED"
                                            !lawyer.isVerified -> "PENDING"
                                            else -> "ACTIVE"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text("Bar Council No: ${lawyer.barCouncilNumber}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("📍 ${lawyer.city}, ${lawyer.state} • ${lawyer.experienceYears} Yrs Exp", fontSize = 11.sp, color = Color.Gray)
                            Text("Fees: Consultation ₹${lawyer.consultationFee} • Hearing ₹${lawyer.courtAppearanceFee}", fontSize = 11.sp, color = Color.Gray)
                            Text("Specialisation: ${lawyer.specialisation}", fontSize = 11.sp, color = NavyBlue, fontWeight = FontWeight.Medium)

                            // --- ADMIN NOTES BADGE INDICATOR ---
                            val notesList = adminNotes[lawyer.uid] ?: emptyList()
                            if (notesList.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Notes, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Admin Notes (${notesList.size} notes logged)",
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action buttons row 1
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { viewingFullProfileLawyer = lawyer },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1.2f)
                                ) {
                                    Text("VIEW PROFILE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { editingLawyer = lawyer },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(0.8f)
                                ) {
                                    Text("EDIT", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        viewModel.updateLawyerActiveStatus(lawyer.uid, !lawyer.isActive)
                                        if (lawyer.isActive) {
                                            viewModel.addToBlacklist(lawyer.email, lawyer.phone)
                                        }
                                        val statusLabel = if (lawyer.isActive) "BANNED & BLACKLISTED" else "UNBANNED/SAFE"
                                        onShowMessage("Practitioner ${lawyer.name} flag updated: $statusLabel")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (lawyer.isActive) ErrorRed else Color.LightGray),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(0.9f)
                                ) {
                                    Text(if (lawyer.isActive) "BAN" else "UNBAN", fontSize = 9.sp, color = if (lawyer.isActive) Color.White else NavyBlue, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Action buttons row 2
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { suspendingUserByAdmin = lawyer },
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1f)
                                ) {
                                    Text("SUSPEND", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { deletingLawyerForConfirm = lawyer },
                                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1f)
                                ) {
                                    Text("DELETE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        addingNoteForLawyer = lawyer
                                        viewModel.fetchAdminNotes(lawyer.uid)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1f)
                                ) {
                                    Text("ADMIN NOTES", fontSize = 9.sp, color = NavyBlue, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (lawyer.isActive && !lawyer.isVerified) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.updateLawyerVerification(lawyer.uid, true)
                                            onShowMessage("Advocate ${lawyer.name} verified successfully! BCI credentials logged.")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = IndiaGreen),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(36.dp).weight(1f).testTag("approve_button_${lawyer.uid}")
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("APPROVE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { rejectingLawyerReasonByAdmin = lawyer },
                                        colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(36.dp).weight(1f).testTag("reject_button_${lawyer.uid}")
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("REJECT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- REJECT PROFILE REASON DIALOG ---
    if (rejectingLawyerReasonByAdmin != null) {
        val lawyer = rejectingLawyerReasonByAdmin!!
        var selectedReasonIndex by remember { mutableStateOf(0) }
        val reasons = listOf(
            "Invalid Bar Council Number",
            "Incomplete Profile Information",
            "Inappropriate Content",
            "Duplicate Account"
        )
        var customNoteText by remember { mutableStateOf("") }
        var showDropdownMenu by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { rejectingLawyerReasonByAdmin = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Reject Practitioner Profile Summary",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )
                    Text(
                        text = "Advocate: ${lawyer.name}\nBar Council No: ${lawyer.barCouncilNumber}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { showDropdownMenu = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Reason: ${reasons[selectedReasonIndex]} ▾", color = Color.DarkGray)
                        }

                        DropdownMenu(
                            expanded = showDropdownMenu,
                            onDismissRequest = { showDropdownMenu = false }
                        ) {
                            reasons.forEachIndexed { i, reason ->
                                DropdownMenuItem(
                                    text = { Text(reason) },
                                    onClick = {
                                        selectedReasonIndex = i
                                        showDropdownMenu = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customNoteText,
                        onValueChange = { customNoteText = it },
                        label = { Text("Custom rejection note (optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { rejectingLawyerReasonByAdmin = null }) {
                            Text("CANCEL", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.rejectLawyerProfile(lawyer.uid, reasons[selectedReasonIndex], customNoteText)
                                onShowMessage("Dispatched rejection: ${reasons[selectedReasonIndex]} to ${lawyer.email}")
                                rejectingLawyerReasonByAdmin = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                        ) {
                            Text("SUBMIT REJECTION", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // --- SUSPENSION DIALOG ---
    if (suspendingUserByAdmin != null) {
        val lawyer = suspendingUserByAdmin!!
        var suspensionDays by remember { mutableStateOf(1) }
        var customReason by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { suspendingUserByAdmin = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Configure Account Temporary Suspension ⏳",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )
                    Text("Select suspension timeframe and provide the enforcement reason block below.", fontSize = 11.sp, color = Color.Gray)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(1, 3, 7, 30).forEach { days ->
                            val active = suspensionDays == days
                            Card(
                                onClick = { suspensionDays = days },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (active) SaffronOrange else Color.LightGray
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(2.dp)
                            ) {
                                Text(
                                    text = "$days Days",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (active) Color.White else Color.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customReason,
                        onValueChange = { customReason = it },
                        label = { Text("Enforcement Reason (Policy infringement description)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { suspendingUserByAdmin = null }) {
                            Text("CLOSE", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.suspendUser(lawyer.uid, suspensionDays, customReason.ifEmpty { "Violation of Service Agreement Policy Rules" })
                                onShowMessage("Suspended ${lawyer.name}'s account active session for $suspensionDays days.")
                                suspendingUserByAdmin = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                        ) {
                            Text("ENFORCE SUSPENSION", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // --- ADMIN NOTES LOG DIALOG ---
    if (addingNoteForLawyer != null) {
        val lawyer = addingNoteForLawyer!!
        val notesList = adminNotes[lawyer.uid] ?: emptyList()

        Dialog(onDismissRequest = { addingNoteForLawyer = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Administrative Logging: Notes on Profile ✍️",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )

                    if (notesList.isEmpty()) {
                        Text("No audit notes recorded on this practitioner yet.", color = Color.Gray, fontSize = 12.sp)
                    } else {
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(notesList) { note ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F9F9)),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = note,
                                        fontSize = 11.sp,
                                        color = Color.DarkGray,
                                        modifier = Modifier.padding(6.dp)
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = noteInputString,
                        onValueChange = { noteInputString = it },
                        label = { Text("Record new internal compliance note") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { addingNoteForLawyer = null }) {
                            Text("DONE", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (noteInputString.isNotEmpty()) {
                                    viewModel.addAdminNote(lawyer.uid, noteInputString)
                                    onShowMessage("Compliance note recorded safely.")
                                    noteInputString = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyBlue)
                        ) {
                            Text("SAVE NOTE")
                        }
                    }
                }
            }
        }
    }

    // --- VIEW FULL PROFILE DIALOG ---
    if (viewingFullProfileLawyer != null) {
        val lawyer = viewingFullProfileLawyer!!
        val regDate = if (lawyer.createdAt > 0L) java.text.DateFormat.getDateInstance().format(java.util.Date(lawyer.createdAt)) else "Recently"
        Dialog(onDismissRequest = { viewingFullProfileLawyer = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Complete Practitioner Directory Portfolio 🏛️",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue,
                        fontFamily = FontFamily.Serif
                    )

                    Divider(color = BorderColor)

                    Text("👤 Name: ${lawyer.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("📧 Email: ${lawyer.email}", fontSize = 13.sp)
                    Text("📞 Contact Phone: +91 ${lawyer.phone}", fontSize = 13.sp)
                    Text("🏛️ Bar Council ID: ${lawyer.barCouncilNumber}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("🎓 Experience Duration: ${lawyer.experienceYears} Years", fontSize = 13.sp)
                    Text("📍 Address: ${lawyer.officeAddress}", fontSize = 13.sp)
                    Text("⏱️ Timing Profile: ${lawyer.workingHours}", fontSize = 13.sp)
                    Text("⚖️ Prime Specialisation: ${lawyer.specialisation}", fontSize = 13.sp)
                    Text("📁 Core Practice Domains: ${lawyer.caseTypes}", fontSize = 13.sp)
                    Text("🗣️ Active Language Profile: ${lawyer.languages}", fontSize = 13.sp)
                    Text("💳 Consultaion Fee: ₹${lawyer.consultationFee}", fontSize = 13.sp)
                    Text("🚪 Hearing Appearance Fee: ₹${lawyer.courtAppearanceFee}", fontSize = 13.sp)
                    Text("⏳ System Onboarding: $regDate", fontSize = 13.sp)
                    Text("📱 Registry Device telemetry: Android build Emulator Core", fontSize = 11.sp, color = Color.Gray)

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { viewingFullProfileLawyer = null },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyBlue)
                        ) {
                            Text("DISMISS PORTFOLIO", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // --- DELETE CONFIRMATION DIALOG ---
    if (deletingLawyerForConfirm != null) {
        val lawyer = deletingLawyerForConfirm!!
        AlertDialog(
            onDismissRequest = { deletingLawyerForConfirm = null },
            title = { Text("Confirm Account Permanent Deletion ⚠️", fontWeight = FontWeight.Bold, color = ErrorRed) },
            text = { Text("Are you sure? This cannot be undone. Completely removes the record from both primary Firebase Realtime Database nodes ('users', 'lawyers') and the secure offline local Room database.", fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAccountByAdmin(lawyer.uid)
                        onShowMessage("Practitioner ${lawyer.name}'s account has been permanently expunged from all registries.")
                        deletingLawyerForConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("PERMANENTLY Expunge", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingLawyerForConfirm = null }) {
                    Text("CANCEL", color = Color.Gray)
                }
            }
        )
    }

    if (editingLawyer != null) {
        EditLawyerDialog(
            lawyer = editingLawyer!!,
            onDismiss = { editingLawyer = null },
            onSave = { name, spec, exp, consult, appear ->
                viewModel.updateLawyerDetails(editingLawyer!!.uid, name, spec, exp, consult, appear)
                onShowMessage("Advocate details updated successfully!")
                editingLawyer = null
            }
        )
    }
}

@Composable
fun EditLawyerDialog(
    lawyer: LawyerEntity,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, Int) -> Unit
) {
    var name by remember { mutableStateOf(lawyer.name) }
    var specialisation by remember { mutableStateOf(lawyer.specialisation) }
    var experienceYears by remember { mutableStateOf(lawyer.experienceYears.toString()) }
    var consultationFee by remember { mutableStateOf(lawyer.consultationFee.toString()) }
    var courtAppearanceFee by remember { mutableStateOf(lawyer.courtAppearanceFee.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Edit Practitioner Details ✍️",
                    style = MaterialTheme.typography.titleLarge,
                    color = NavyBlue,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = specialisation,
                    onValueChange = { specialisation = it },
                    label = { Text("Specialisation") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = experienceYears,
                    onValueChange = { experienceYears = it },
                    label = { Text("Experience Years") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = consultationFee,
                    onValueChange = { consultationFee = it },
                    label = { Text("Consultation Fee (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = courtAppearanceFee,
                    onValueChange = { courtAppearanceFee = it },
                    label = { Text("Hearing Fee (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val exp = experienceYears.toIntOrNull() ?: lawyer.experienceYears
                            val consult = consultationFee.toIntOrNull() ?: lawyer.consultationFee
                            val appear = courtAppearanceFee.toIntOrNull() ?: lawyer.courtAppearanceFee
                            onSave(name, specialisation, exp, consult, appear)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyBlue)
                    ) {
                        Text("Save Changes", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminClientManagementView(
    allUsers: List<UserEntity>,
    viewModel: LobbyViewModel,
    onShowMessage: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val clients = allUsers.filter { it.role == "client" }

    // Advanced admin dialog states
    var viewingFullProfileClient by remember { mutableStateOf<UserEntity?>(null) }
    var suspendingClientByAdmin by remember { mutableStateOf<UserEntity?>(null) }
    var deletingClientForConfirm by remember { mutableStateOf<UserEntity?>(null) }

    // Active multi-selection state
    var selectedClientUids by remember { mutableStateOf(setOf<String>()) }

    // Admin notes dialog
    var addingNoteForClient by remember { mutableStateOf<UserEntity?>(null) }
    var noteInputString by remember { mutableStateOf("") }

    val adminNotes by viewModel.adminNotes.collectAsState()

    val filtered = clients.filter { client ->
        client.name.contains(searchQuery, ignoreCase = true) ||
                client.email.contains(searchQuery, ignoreCase = true) ||
                client.phone.contains(searchQuery, ignoreCase = true) ||
                client.city.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search client name, email, contact, city...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyBlue) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(8.dp)
        )

        // --- BULK ACTIONS FLOATING TOOLBAR ---
        if (selectedClientUids.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyBlue),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(8.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${selectedClientUids.size} Clients Selected",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                selectedClientUids.forEach { uid ->
                                    viewModel.updateUserActiveStatus(uid, false)
                                    viewModel.addToBlacklist("", "")
                                }
                                onShowMessage("Bulk Banned ${selectedClientUids.size} Client accounts!")
                                selectedClientUids = emptySet()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("BAN ALL", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                selectedClientUids.forEach { uid ->
                                    viewModel.deleteAccountByAdmin(uid)
                                }
                                onShowMessage("Bulk Deleted ${selectedClientUids.size} Client registers!")
                                selectedClientUids = emptySet()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("DELETE ALL", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No matching clients registered.", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered) { client ->
                    val isSelected = selectedClientUids.contains(client.uid)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, if (client.isActive) BorderColor else ErrorRed.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = { checked ->
                                            selectedClientUids = if (checked) {
                                                selectedClientUids + client.uid
                                            } else {
                                                selectedClientUids - client.uid
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (client.isActive) IndiaGreen.copy(alpha = 0.1f) else ErrorRed.copy(alpha = 0.1f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = client.name.take(1).uppercase(),
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (client.isActive) IndiaGreen else ErrorRed
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = client.name,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = NavyBlue,
                                            fontFamily = FontFamily.Serif
                                        )
                                        Text(
                                            text = client.email,
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Badge(
                                    containerColor = if (client.isActive) IndiaGreen.copy(alpha = 0.2f) else ErrorRed.copy(alpha = 0.2f),
                                    contentColor = if (client.isActive) IndiaGreen else ErrorRed
                                ) {
                                    Text(
                                        text = if (client.isActive) "ACTIVE" else "BANNED",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("📞 Contact: +91 ${client.phone}", fontSize = 12.sp, color = TextSecondary)
                            Text("📍 Location: ${client.city}, ${client.state}", fontSize = 12.sp, color = TextSecondary)
                            Text("⏳ Registered: " + if (client.createdAt > 0) java.text.DateFormat.getDateInstance().format(java.util.Date(client.createdAt)) else "Recently", fontSize = 11.sp, color = Color.Gray)

                            // --- ADMIN NOTES BADGE INDICATOR ---
                            val notesList = adminNotes[client.uid] ?: emptyList()
                            if (notesList.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Notes, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Admin Notes (${notesList.size} notes logged)",
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action buttons row 1
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.updateUserActiveStatus(client.uid, !client.isActive)
                                        if (client.isActive) {
                                            viewModel.addToBlacklist(client.email, client.phone)
                                        }
                                        val logLabel = if (client.isActive) "BANNED & BLACKLISTED" else "UNBANNED/RESTORED"
                                        onShowMessage("Client ${client.name} updated: $logLabel")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (client.isActive) ErrorRed else NavyBlue),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1.2f).testTag("client_ban_button_${client.uid}")
                                ) {
                                    Text(
                                        text = if (client.isActive) "BAN CLIENT" else "ACTIVATE CLIENT",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Button(
                                    onClick = { viewingFullProfileClient = client },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(0.9f)
                                ) {
                                    Text("VIEW FULL", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        addingNoteForClient = client
                                        viewModel.fetchAdminNotes(client.uid)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1f)
                                ) {
                                    Text("ADMIN NOTES", fontSize = 9.sp, color = NavyBlue, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Action buttons row 2
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { suspendingClientByAdmin = client },
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1f)
                                ) {
                                    Text("SUSPEND ACCOUNT", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { deletingClientForConfirm = client },
                                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(32.dp).weight(1f)
                                ) {
                                    Text("DELETE REGISTRY", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- VIEW FULL PROFILE DIALOG ---
    if (viewingFullProfileClient != null) {
        val client = viewingFullProfileClient!!
        val regDate = if (client.createdAt > 0L) java.text.DateFormat.getDateInstance().format(java.util.Date(client.createdAt)) else "Recently"
        Dialog(onDismissRequest = { viewingFullProfileClient = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Client Account Portfolio 👤",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue,
                        fontFamily = FontFamily.Serif
                    )

                    Divider(color = BorderColor)

                    Text("👤 Name: ${client.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("📧 Email: ${client.email}", fontSize = 13.sp)
                    Text("📞 Contact Phone: +91 ${client.phone}", fontSize = 13.sp)
                    Text("📍 Location City: ${client.city}", fontSize = 13.sp)
                    Text("🗺️ State: ${client.state}", fontSize = 13.sp)
                    Text("⏳ System Onboarding: $regDate", fontSize = 13.sp)
                    Text("🛡️ Authorization Role: CLIENT", fontSize = 13.sp, color = IndiaGreen, fontWeight = FontWeight.Bold)
                    Text("📱 Registry Device telemetry: Android build Emulator Core", fontSize = 11.sp, color = Color.Gray)

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { viewingFullProfileClient = null },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyBlue)
                        ) {
                            Text("DISMISS PORTFOLIO", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // --- SUSPENSION DIALOG ---
    if (suspendingClientByAdmin != null) {
        val client = suspendingClientByAdmin!!
        var suspensionDays by remember { mutableStateOf(1) }
        var customReason by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { suspendingClientByAdmin = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Configure Client Account Temporary Suspension ⏳",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )
                    Text("Select suspension timeframe and provide the enforcement reason block below.", fontSize = 11.sp, color = Color.Gray)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(1, 3, 7, 30).forEach { days ->
                            val active = suspensionDays == days
                            Card(
                                onClick = { suspensionDays = days },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (active) SaffronOrange else Color.LightGray
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(2.dp)
                            ) {
                                Text(
                                    text = "$days Days",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (active) Color.White else Color.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customReason,
                        onValueChange = { customReason = it },
                        label = { Text("Enforcement Reason (Policy infringement description)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { suspendingClientByAdmin = null }) {
                            Text("CLOSE", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.suspendUser(client.uid, suspensionDays, customReason.ifEmpty { "Violation of Service Agreement Policy Rules" })
                                onShowMessage("Suspended client ${client.name}'s account active session for $suspensionDays days.")
                                suspendingClientByAdmin = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                        ) {
                            Text("ENFORCE SUSPENSION", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // --- CONFIRMATION ACCOUNT DELETE DIALOG ---
    if (deletingClientForConfirm != null) {
        val client = deletingClientForConfirm!!
        AlertDialog(
            onDismissRequest = { deletingClientForConfirm = null },
            title = { Text("Confirm Account Permanent Deletion ⚠️", fontWeight = FontWeight.Bold, color = ErrorRed) },
            text = { Text("Are you sure? This cannot be undone. Completely removes client ${client.name} from primary Firebase Realtime Database node 'users' and the secure offline local Room database.", fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAccountByAdmin(client.uid)
                        onShowMessage("Client ${client.name}'s account has been permanently expunged from all registries.")
                        deletingClientForConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("PERMANENTLY Expunge", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingClientForConfirm = null }) {
                    Text("CANCEL", color = Color.Gray)
                }
            }
        )
    }

    // --- ADMIN NOTES LOG DIALOG ---
    if (addingNoteForClient != null) {
        val client = addingNoteForClient!!
        val notesList = adminNotes[client.uid] ?: emptyList()

        Dialog(onDismissRequest = { addingNoteForClient = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Administrative Logging: Notes on Profile ✍️",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyBlue
                    )

                    if (notesList.isEmpty()) {
                        Text("No audit notes recorded on this client yet.", color = Color.Gray, fontSize = 12.sp)
                    } else {
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 120.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(notesList) { note ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F9F9)),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = note,
                                        fontSize = 11.sp,
                                        color = Color.DarkGray,
                                        modifier = Modifier.padding(6.dp)
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = noteInputString,
                        onValueChange = { noteInputString = it },
                        label = { Text("Record new internal compliance note") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { addingNoteForClient = null }) {
                            Text("DONE", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (noteInputString.isNotEmpty()) {
                                    viewModel.addAdminNote(client.uid, noteInputString)
                                    onShowMessage("Compliance note recorded safely.")
                                    noteInputString = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyBlue)
                        ) {
                            Text("SAVE NOTE")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminReviewsModerationView(
    allReviews: List<ReviewEntity>,
    viewModel: LobbyViewModel,
    onShowMessage: (String) -> Unit
) {
    if (allReviews.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No lawyer reviews have been submitted yet.", color = Color.Gray, fontSize = 14.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(allReviews) { review ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, if (review.rating <= 2) ErrorRed.copy(alpha = 0.4f) else BorderColor),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "Client: ${review.clientName}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyBlue
                                )
                                Text(text = "Lawyer ID: ${review.lawyerId}", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row {
                                    repeat(5) { i ->
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = if (i < review.rating) SaffronOrange else Color.LightGray,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            Badge(
                                containerColor = if (review.isVerifiedClient) IndiaGreen.copy(alpha = 0.15f) else Color.LightGray,
                                contentColor = if (review.isVerifiedClient) IndiaGreen else Color.DarkGray
                            ) {
                                Text(
                                    text = if (review.isVerifiedClient) "🛡️ GENUINE CHECK" else "UNVERIFIED CLIENT",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Specialty: ${review.caseType}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NavyBlue
                        )
                        Text(
                            text = "“${review.reviewText}”",
                            fontSize = 13.sp,
                            fontStyle = FontStyle.Italic,
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!review.isVerifiedClient) {
                                Button(
                                    onClick = {
                                        viewModel.updateReviewVerificationByAdmin(review.reviewId, true)
                                        onShowMessage("Review verified as 100% genuine active client!")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = IndiaGreen),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(36.dp).weight(1f).testTag("verify_review_${review.reviewId}")
                                ) {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("VERIFY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Button(
                                onClick = {
                                    viewModel.deleteReviewByAdmin(review.reviewId)
                                    onShowMessage("Review moderated and deleted permanently from the database")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(36.dp).weight(1f).testTag("delete_review_${review.reviewId}")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("DELETE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAnnouncementsView(
    announcements: List<AnnouncementItem>,
    viewModel: LobbyViewModel,
    onShowMessage: (String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var targetAudience by remember { mutableStateOf("ALL") } // "ALL", "LAWYERS", "CLIENTS"
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderColor),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "📢 Publish Broadcast Notification",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyBlue,
                    fontFamily = FontFamily.Serif
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notification Title (e.g., 'Maintenance at 2 AM')") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp)
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Announcement Body/Message...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    shape = RoundedCornerShape(6.dp)
                )

                // Select Target Dropdown
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, BorderColor),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Target Audience: " + when (targetAudience) {
                                "LAWYERS" -> "⚖️ Only Verf. Lawyers"
                                "CLIENTS" -> "👤 Only Active Clients"
                                else -> "🌎 Live Public (ALL)"
                            },
                            color = NavyBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.fillMaxWidth().background(Color.White)
                    ) {
                        DropdownMenuItem(
                            text = { Text("🌎 Live Public (ALL)") },
                            onClick = {
                                targetAudience = "ALL"
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("⚖️ Only Verf. Lawyers") },
                            onClick = {
                                targetAudience = "LAWYERS"
                                expanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("👤 Only Active Clients") },
                            onClick = {
                                targetAudience = "CLIENTS"
                                expanded = false
                            }
                        )
                    }
                }

                Button(
                    onClick = {
                        if (title.isBlank() || content.isBlank()) {
                            onShowMessage("Please specify notification title and body description.")
                            return@Button
                        }
                        viewModel.sendAnnouncement(title, content, targetAudience)
                        onShowMessage("FCM Push success: Notification broadcasted target: $targetAudience")
                        title = ""
                        content = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SEND FCM BROADCAST", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        Text(
            text = "📬 Sent Notifications Log",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = NavyBlue,
            fontFamily = FontFamily.Serif
        )

        announcements.forEach { announcement ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.8f)),
                border = BorderStroke(1.dp, BorderColor.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = announcement.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = NavyBlue
                        )
                        Badge(
                            containerColor = when (announcement.target) {
                                "LAWYERS" -> NavyBlue.copy(alpha = 0.15f)
                                "CLIENTS" -> IndiaGreen.copy(alpha = 0.15f)
                                else -> SaffronOrange.copy(alpha = 0.15f)
                            },
                            contentColor = when (announcement.target) {
                                "LAWYERS" -> NavyBlue
                                "CLIENTS" -> IndiaGreen
                                else -> SaffronOrange
                            }
                        ) {
                            Text(
                                text = announcement.target,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = announcement.text, fontSize = 12.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Broadcasted: ${announcement.dateString}", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun AdminEmergenciesView(
    allEmergencyRequests: List<EmergencyRequestEntity>,
    allLawyers: List<LawyerEntity>,
    viewModel: LobbyViewModel,
    onShowMessage: (String) -> Unit
) {
    var expandedRequestById by remember { mutableStateOf<Int?>(null) }
    val activeLawyers = allLawyers.filter { it.isVerified && it.isActive }

    if (allEmergencyRequests.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No emergency arrest/bail alerts active.", color = Color.Gray, fontSize = 14.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(allEmergencyRequests) { request ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, if (request.isResolved) BorderColor else ErrorRed.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🚨 " + request.emergencyType,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (request.isResolved) NavyBlue else ErrorRed,
                                fontFamily = FontFamily.Serif
                            )

                            Badge(
                                containerColor = if (request.isResolved) IndiaGreen.copy(alpha = 0.2f) else ErrorRed.copy(alpha = 0.2f),
                                contentColor = if (request.isResolved) IndiaGreen else ErrorRed
                            ) {
                                Text(
                                    text = if (request.isResolved) "RESOLVED" else "CRITICAL HELP NEEDED",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Client: ${request.name}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NavyBlue)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = "Contact: +91 ${request.phone} • City: ${request.city}", fontSize = 12.sp, color = TextSecondary)
                        Text(text = "Details: ${request.description}", fontSize = 12.sp, color = TextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Created: " + java.text.DateFormat.getDateTimeInstance().format(java.util.Date(request.createdAt)),
                            fontSize = 10.sp,
                            color = Color.Gray
                        )

                        if (!request.assignedLawyerId.isNullOrEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = NavyBlue.copy(alpha = 0.05f)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CardTravel, contentDescription = null, tint = NavyBlue, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Assigned Practitioner: ${request.assignedLawyerName}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyBlue
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (!request.isResolved) {
                                Button(
                                    onClick = {
                                        viewModel.updateEmergencyStatusByAdmin(request.id, true, request.assignedLawyerId, request.assignedLawyerName)
                                        onShowMessage("Case marked as fully resolved. Safe status broadcasted.")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = IndiaGreen),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(36.dp).weight(1f).testTag("resolve_button_${request.id}")
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("RESOLVE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Box(modifier = Modifier.weight(1f)) {
                                Button(
                                    onClick = {
                                        expandedRequestById = if (expandedRequestById == request.id) null else request.id
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyBlue),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(36.dp).fillMaxWidth().testTag("assign_button_${request.id}")
                                ) {
                                    Icon(Icons.Default.AssignmentInd, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ASSIGN ADV.", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                DropdownMenu(
                                    expanded = expandedRequestById == request.id,
                                    onDismissRequest = { expandedRequestById = null },
                                    modifier = Modifier.background(Color.White)
                                ) {
                                    if (activeLawyers.isEmpty()) {
                                        DropdownMenuItem(
                                            text = { Text("No active verified lawyers to assign") },
                                            onClick = { expandedRequestById = null }
                                        )
                                    } else {
                                        activeLawyers.forEach { lawyer ->
                                            DropdownMenuItem(
                                                text = { Text(lawyer.name + " (" + lawyer.experienceYears + " Yrs)") },
                                                onClick = {
                                                    viewModel.updateEmergencyStatusByAdmin(request.id, request.isResolved, lawyer.uid, lawyer.name)
                                                    onShowMessage("Case Assigned to: ${lawyer.name} successfully!")
                                                    expandedRequestById = null
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminBlacklistManagementView(
    viewModel: LobbyViewModel,
    onShowMessage: (String) -> Unit
) {
    var emailInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    val blacklist by viewModel.blacklist.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.fetchBlacklist()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderColor),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Shield System: Add to Permanently Banned Blacklist 🚫",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = NavyBlue,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it },
                    label = { Text("Email to ban permanently") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    shape = RoundedCornerShape(8.dp)
                )
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Phone number to ban permanently") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    shape = RoundedCornerShape(8.dp)
                )
                Button(
                    onClick = {
                        if (emailInput.isEmpty() && phoneInput.isEmpty()) {
                            onShowMessage("Please enter at least an email or phone number to blacklist.")
                            return@Button
                        }
                        viewModel.addToBlacklist(emailInput, phoneInput)
                        onShowMessage("Added ${emailInput.ifEmpty { phoneInput }} to secure permanent blacklist.")
                        emailInput = ""
                        phoneInput = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ADD TO SECURE PERMANENT BLACKLIST", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Text(
            text = "Permanently Banned Blacklist Directory (${blacklist.size} records)",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.DarkGray,
            modifier = Modifier.padding(bottom = 8.dp),
            fontFamily = FontFamily.Serif
        )

        if (blacklist.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("Secure blacklist directory is currently empty.", color = Color.Gray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(blacklist) { record ->
                    val recordId = record["id"].toString()
                    val email = record["email"].toString()
                    val phone = record["phone"].toString()
                    val date = record["createdAt"] as? Long ?: System.currentTimeMillis()
                    val dateStr = java.text.DateFormat.getDateTimeInstance().format(java.util.Date(date))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                if (email.isNotEmpty()) {
                                    Text("📧 Email: $email", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NavyBlue)
                                }
                                if (phone.isNotEmpty()) {
                                    Text("📞 Phone: +91 $phone", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NavyBlue)
                                }
                                Text("✍️ Banned on: $dateStr", fontSize = 10.sp, color = Color.Gray)
                            }
                            IconButton(onClick = {
                                viewModel.removeFromBlacklist(recordId)
                                onShowMessage("Removed record $recordId from permanent blacklist.")
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove from Blacklist", tint = ErrorRed)
                            }
                        }
                    }
                }
            }
        }
    }
}

