package com.example.data

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics

object AnalyticsHelper {
    private const val TAG = "AnalyticsHelper"
    private var firebaseAnalytics: FirebaseAnalytics? = null
    private var firebaseCrashlytics: FirebaseCrashlytics? = null

    fun init(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
                Log.d(TAG, "Manual FirebaseApp initialization complete")
            }
            firebaseAnalytics = FirebaseAnalytics.getInstance(context)
            firebaseCrashlytics = FirebaseCrashlytics.getInstance()
            Log.d(TAG, "Firebase Analytics & Crashlytics initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Firebase SDKs: ${e.message}. Falling back to safe logging.")
        }
    }

    fun logEvent(name: String, params: Bundle = Bundle()) {
        Log.d(TAG, "Logging event [ $name ] with params: ${bundleToMap(params)}")
        try {
            firebaseAnalytics?.logEvent(name, params)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to log event dynamically: ${e.message}")
        }
    }

    fun recordException(throwable: Throwable) {
        Log.e(TAG, "Recording Exception:", throwable)
        try {
            firebaseCrashlytics?.recordException(throwable)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to record crashlytics exception: ${e.message}")
        }
    }

    fun logScreenView(screenName: String) {
        val bundle = Bundle().apply {
            putString(FirebaseAnalytics.Param.SCREEN_NAME, screenName)
            putString(FirebaseAnalytics.Param.SCREEN_CLASS, screenName)
        }
        logEvent("screen_view", bundle)
    }

    fun logLawyerProfileViewed(lawyerName: String, city: String) {
        val bundle = Bundle().apply {
            putString("lawyer_name", lawyerName)
            putString("city", city)
        }
        logEvent("lawyer_profile_viewed", bundle)
    }

    fun logSearchPerformed(searchTerm: String, resultsCount: Int) {
        val bundle = Bundle().apply {
            putString("search_term", searchTerm)
            putInt("results_count", resultsCount)
        }
        logEvent("search_performed", bundle)
    }

    fun logCallButtonTapped(lawyerName: String) {
        val bundle = Bundle().apply {
            putString("lawyer_name", lawyerName)
        }
        logEvent("call_button_tapped", bundle)
    }

    fun logWhatsappButtonTapped(lawyerName: String) {
        val bundle = Bundle().apply {
            putString("lawyer_name", lawyerName)
        }
        logEvent("whatsapp_button_tapped", bundle)
    }

    fun logNyayamitraQuestionAsked(questionText: String) {
        val bundle = Bundle().apply {
            putString("question_text", questionText)
        }
        logEvent("nyayamitra_question_asked", bundle)
    }

    fun logEmergencyRequestSubmitted(category: String) {
        val bundle = Bundle().apply {
            putString("category", category)
        }
        logEvent("emergency_request_submitted", bundle)
    }

    fun logChalanPaymentInitiated(amount: Double, state: String) {
        val bundle = Bundle().apply {
            putDouble("amount", amount)
            putString("state", state)
        }
        logEvent("chalan_payment_initiated", bundle)
    }

    fun logUserRegistered(role: String) {
        val bundle = Bundle().apply {
            putString("role", role)
        }
        logEvent("user_registered", bundle)
    }

    private fun bundleToMap(bundle: Bundle): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        try {
            for (key in bundle.keySet()) {
                map[key] = bundle.get(key)
            }
        } catch (e: Exception) {
            // Safe fallback
        }
        return map
    }
}
