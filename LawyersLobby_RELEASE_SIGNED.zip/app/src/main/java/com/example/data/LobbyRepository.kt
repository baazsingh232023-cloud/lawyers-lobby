package com.example.data

import android.content.Context
import com.example.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first

class LobbyRepository private constructor(private val database: LobbyDatabase) {

    private val userDao = database.userDao()
    private val lawyerDao = database.lawyerDao()
    private val reviewDao = database.reviewDao()
    private val chalanDao = database.chalanDao()
    private val emergencyRequestDao = database.emergencyRequestDao()

    // Active streams
    val allLawyers: Flow<List<LawyerEntity>> = lawyerDao.getAllLawyers()
    val allReviews: Flow<List<ReviewEntity>> = reviewDao.getAllReviews()
    val allEmergencyRequests: Flow<List<EmergencyRequestEntity>> = emergencyRequestDao.getAllEmergencyRequests()
    val allUsers: Flow<List<UserEntity>> = userDao.getAllUsers()

    // Active session state (simulates Firebase Auth)
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser

    fun getReviewsForLawyer(lawyerId: String): Flow<List<ReviewEntity>> {
        return reviewDao.getReviewsForLawyer(lawyerId)
    }

    fun getPaymentsForUser(userId: String): Flow<List<ChalanEntity>> {
        return chalanDao.getPaymentsForUser(userId)
    }

    suspend fun insertUser(user: UserEntity) {
        userDao.insertUser(user)
        // If the user being registered is the current one, update session
        if (_currentUser.value == null || _currentUser.value?.uid == user.uid) {
            _currentUser.value = user
        }
    }

    suspend fun registerLawyer(user: UserEntity, lawyer: LawyerEntity) {
        userDao.insertUser(user)
        lawyerDao.insertLayerOrReplace(lawyer)
        _currentUser.value = user
    }

    suspend fun insertChalan(chalan: ChalanEntity) {
        chalanDao.insertChalan(chalan)
    }

    suspend fun insertEmergencyRequest(request: EmergencyRequestEntity) {
        emergencyRequestDao.insertEmergencyRequest(request)
    }

    suspend fun insertReview(review: ReviewEntity) {
        reviewDao.insertReview(review)
        // Re-calculate rating for lawyer
        val lawyerId = review.lawyerId
        val reviews = reviewDao.getReviewsForLawyer(lawyerId).first()
        if (reviews.isNotEmpty()) {
            val avgRating = reviews.map { it.rating }.average().toFloat()
            val totalCount = reviews.size
            lawyerDao.updateRating(lawyerId, avgRating, totalCount)
        }
    }

    suspend fun setOnlineStatus(lawyerId: String, isOnline: Boolean) {
        lawyerDao.updateOnlineStatus(lawyerId, isOnline)
    }

    suspend fun updateUserActiveStatus(uid: String, isActive: Boolean) {
        userDao.updateUserActiveStatus(uid, isActive)
    }

    suspend fun updateLawyerVerification(uid: String, isVerified: Boolean) {
        lawyerDao.updateLawyerVerification(uid, isVerified)
    }

    suspend fun updateLawyerActiveStatus(uid: String, isActive: Boolean) {
        lawyerDao.updateLawyerActiveStatus(uid, isActive)
    }

    suspend fun updateLawyerDetails(uid: String, name: String, specialisation: String, experienceYears: Int, consultationFee: Int, courtAppearanceFee: Int) {
        lawyerDao.updateLawyerDetails(uid, name, specialisation, experienceYears, consultationFee, courtAppearanceFee)
    }

    suspend fun deleteReview(reviewId: Int) {
        reviewDao.deleteReviewById(reviewId)
    }

    suspend fun updateReviewVerification(reviewId: Int, isVerifiedClient: Boolean) {
        reviewDao.updateReviewVerification(reviewId, isVerifiedClient)
    }

    suspend fun updateEmergencyStatus(id: Int, isResolved: Boolean, assignedLawyerId: String?, assignedLawyerName: String?) {
        emergencyRequestDao.updateEmergencyStatus(id, isResolved, assignedLawyerId, assignedLawyerName)
    }

    suspend fun deleteUserAndProfile(uid: String) {
        userDao.deleteUserByUid(uid)
        lawyerDao.deleteLawyerByUid(uid)
    }

    suspend fun loginUser(email: String, role: String): Boolean {
        // Try to matching user in local storage
        val users = userDao.getAllUsers().first()
        val found = users.find { it.email.equals(email, ignoreCase = true) && it.role == role }
        return if (found != null) {
            _currentUser.value = found
            true
        } else {
            // Auto generate standard mock account for convenience if not registered yet
            val defaultName = if (role == "client") "Suresh Tripathi" else "Adv. Rajesh Kumar"
            val mockUser = UserEntity(
                uid = "uid_" + email.hashCode().toString(),
                name = defaultName,
                email = email,
                phone = "+919876543210",
                city = "New Delhi",
                state = "Delhi",
                role = role
            )
            userDao.insertUser(mockUser)
            _currentUser.value = mockUser
            true
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    fun setCurrentUser(user: UserEntity?) {
        _currentUser.value = user
    }

    // Support clean helper extensions inside Room
    private suspend fun LawyerDao.insertLayerOrReplace(lawyer: LawyerEntity) {
        this.insertLawyer(lawyer)
    }

    suspend fun seedDatabaseIfEmpty() {
        val existingLawyers = lawyerDao.getAllLawyers().first()
        if (existingLawyers.isEmpty()) {
            // Seed Lawyers
            val sampleLawyers = listOf(
                LawyerEntity(
                    uid = "lawyer_1",
                    name = "Adv. Rajesh Kumar Sharma",
                    email = "rajesh.court@lawyerslobby.com",
                    phone = "+919811122233",
                    city = "New Delhi",
                    state = "Delhi",
                    barCouncilNumber = "D/2891/2006",
                    experienceYears = 18,
                    consultationFee = 1500,
                    courtAppearanceFee = 5000,
                    specialisation = "Criminal Defence / आपराधिक बचाव",
                    caseTypes = "Criminal Defence, Bail Application, FIR, Court Hearing",
                    languages = "Hindi, English, Punjabi",
                    about = "Senior criminal defense lawyer with 18 years of active practice at the High Court of Delhi and District Courts. Handled over 500+ sensitive cases, specialized in secure bail applications, trial strategy, and FIR compounding.",
                    officeAddress = "Chamber 45, Patiala House Courts, New Delhi - 110001",
                    workingHours = "10:00 AM - 07:00 PM (Mon-Sat)",
                    isOnline = true,
                    isVerified = true,
                    rating = 4.8f,
                    totalReviews = 1,
                    totalCasesWon = 420,
                    linkedInUrl = "https://linkedin.com/in/adv-rajesh-kumar",
                    googleProfileUrl = "https://g.co/maps/rajesh-chambers",
                    profilePhoto = "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=250&auto=format&fit=crop"
                ),
                LawyerEntity(
                    uid = "lawyer_2",
                    name = "Adv. Priya Nair",
                    email = "priya.nair@lawyerslobby.com",
                    phone = "+919822233344",
                    city = "Mumbai",
                    state = "Maharashtra",
                    barCouncilNumber = "MH/4521/2012",
                    experienceYears = 12,
                    consultationFee = 2000,
                    courtAppearanceFee = 7000,
                    specialisation = "Divorce & Family / तलाक और परिवार",
                    caseTypes = "Divorce, Child Custody, Matrimonial Disputes, Domestic Violence, Alimony",
                    languages = "Hindi, English, Marathi",
                    about = "Expert family law mediator with 12 years of core litigation experience in Mumbai Family Courts. Highly trusted for sensitive, secure, and stress-free dispute resolution processes.",
                    officeAddress = "Suite 22, Nariman Point, Marine Drive, Mumbai - 400021",
                    workingHours = "10:30 AM - 05:30 PM (Mon-Fri)",
                    isOnline = true,
                    isVerified = true,
                    rating = 4.6f,
                    totalReviews = 1,
                    totalCasesWon = 280,
                    linkedInUrl = "https://linkedin.com/in/adv-priya-nair",
                    googleProfileUrl = "https://g.co/maps/priya-familylegal",
                    profilePhoto = "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=250&auto=format&fit=crop"
                ),
                LawyerEntity(
                    uid = "lawyer_3",
                    name = "Adv. Harpreet Singh Grewal",
                    email = "harpreet.grewal@lawyerslobby.com",
                    phone = "+919833344455",
                    city = "Chandigarh",
                    state = "Punjab",
                    barCouncilNumber = "PB/1102/2009",
                    experienceYears = 15,
                    consultationFee = 1200,
                    courtAppearanceFee = 4500,
                    specialisation = "Property Dispute / संपत्ति विवाद",
                    caseTypes = "Property Dispute, Land Acquisition, Tenant Issues, Mutation of Papers",
                    languages = "Hindi, Punjabi, English",
                    about = "Accomplished real estate and civil attorney in Chandigarh. Specializes in solving ancestral property disputes, landlord-tenant arbitration, and real estate litigation under RERA guidelines.",
                    officeAddress = "SCO 104-105, Sector 17-D, Chandigarh - 160017",
                    workingHours = "09:30 AM - 06:30 PM (Mon-Sat)",
                    isOnline = false,
                    isVerified = true,
                    rating = 4.5f,
                    totalReviews = 1,
                    totalCasesWon = 310,
                    linkedInUrl = "https://linkedin.com/in/adv-harpreet-grewal",
                    googleProfileUrl = "https://g.co/maps/harpreet-property-law",
                    profilePhoto = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=250&auto=format&fit=crop"
                ),
                LawyerEntity(
                    uid = "lawyer_4",
                    name = "Adv. Ananya Krishnamurthy",
                    email = "ananya.corporate@lawyerslobby.com",
                    phone = "+919844455566",
                    city = "Bengaluru",
                    state = "Karnataka",
                    barCouncilNumber = "KA/3345/2015",
                    experienceYears = 9,
                    consultationFee = 2500,
                    courtAppearanceFee = 10000,
                    specialisation = "Corporate & Startup / कॉर्पोरेट",
                    caseTypes = "Corporate Compliance, Startup Consulting, IP Registration, Trademark Filing, Contract Drafting",
                    languages = "English, Kannada, Tamil, Hindi",
                    about = "Passionate business lawyer advising emerging startups and tech corporations across India. Focuses on investment term-sheets, patent filings, and corporate legal audits.",
                    officeAddress = "Block B, 4th Floor, Indiranagar, Bengaluru - 560038",
                    workingHours = "10:00 AM - 06:00 PM (Mon-Fri)",
                    isOnline = true,
                    isVerified = true,
                    rating = 4.9f,
                    totalReviews = 1,
                    totalCasesWon = 150,
                    linkedInUrl = "https://linkedin.com/in/adv-ananya-k",
                    googleProfileUrl = "https://g.co/maps/ananya-corp-chambers",
                    profilePhoto = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=250&auto=format&fit=crop"
                ),
                LawyerEntity(
                    uid = "lawyer_5",
                    name = "Adv. Mohammed Farooq Ahmed",
                    email = "farooq.ahmed@lawyerslobby.com",
                    phone = "+919855566677",
                    city = "Hyderabad",
                    state = "Telangana",
                    barCouncilNumber = "TS/2210/2013",
                    experienceYears = 11,
                    consultationFee = 1000,
                    courtAppearanceFee = 4000,
                    specialisation = "Cheque Bounce / चेक बाउंस",
                    caseTypes = "Cheque Bounce, NI Act Section 138, Banking Claims, Debt Recovery Tribunal",
                    languages = "Urdu, Hindi, Telugu, English",
                    about = "Seasoned banking recovery litigator practicing at Hyderabad District Courts. Specializes in Section 138 Negotiable Instruments Act with swift recovery timescales.",
                    officeAddress = "Chalk Building Main Road, Nampally, Hyderabad - 500001",
                    workingHours = "10:00 AM - 05:00 PM (Mon-Sat)",
                    isOnline = true,
                    isVerified = true,
                    rating = 4.4f,
                    totalReviews = 1,
                    totalCasesWon = 190,
                    linkedInUrl = "https://linkedin.com/in/adv-farooq-ahmed",
                    googleProfileUrl = "https://g.co/maps/farooq-legal-associates",
                    profilePhoto = "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=250&auto=format&fit=crop"
                ),
                LawyerEntity(
                    uid = "lawyer_6",
                    name = "Adv. Kavita Pillai",
                    email = "kavita.tax@lawyerslobby.com",
                    phone = "+919866677788",
                    city = "Kochi",
                    state = "Kerala",
                    barCouncilNumber = "KL/2201/2014",
                    experienceYears = 10,
                    consultationFee = 1800,
                    courtAppearanceFee = 6000,
                    specialisation = "GST & Income Tax / जीएसटी और कर",
                    caseTypes = "GST Compliance, Income Tax Appeals, Tax Audits, Assessment Challenges",
                    languages = "Malayalam, English, Hindi, Tamil",
                    about = "Highly professional tax litigation lawyer guiding individuals and direct-to-consumer businesses. Focuses on complex commercial disputes and GST audit appeals.",
                    officeAddress = "Kaloor Chambers, Kochi, Kerala - 682017",
                    workingHours = "09:00 AM - 05:00 PM (Mon-Sat)",
                    isOnline = true,
                    isVerified = true,
                    rating = 4.6f,
                    totalReviews = 1,
                    totalCasesWon = 130,
                    linkedInUrl = "https://linkedin.com/in/adv-kavita-pillai",
                    googleProfileUrl = "https://g.co/maps/kavita-pillai-tax",
                    profilePhoto = "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=250&auto=format&fit=crop"
                )
            )

            // Seed users corresponding to lawyers for correct login structure
            for (lawyer in sampleLawyers) {
                userDao.insertUser(
                    UserEntity(
                        uid = lawyer.uid,
                        name = lawyer.name,
                        email = lawyer.email,
                        phone = lawyer.phone,
                        city = lawyer.city,
                        state = lawyer.state,
                        role = "lawyer",
                        profilePhoto = lawyer.profilePhoto
                    )
                )
                lawyerDao.insertLayerOrReplace(lawyer)
            }

            // Seed reviews corresponding to user requirements
            reviewDao.insertReview(
                ReviewEntity(
                    lawyerId = "lawyer_1",
                    clientId = "client_suresh",
                    clientName = "Suresh T.",
                    rating = 5,
                    reviewText = "Got bail within 48 hours! Rajesh sir was available even at midnight. Truly exceptional service and communication.",
                    caseType = "Criminal Defence"
                )
            )
            reviewDao.insertReview(
                ReviewEntity(
                    lawyerId = "lawyer_2",
                    clientId = "client_meena",
                    clientName = "Meena R.",
                    rating = 5,
                    reviewText = "Handled my divorce with full sensitivity. Got child custody without a messy battle. Eternally thankful to Priya mam.",
                    caseType = "Divorce & Family"
                )
            )
            reviewDao.insertReview(
                ReviewEntity(
                    lawyerId = "lawyer_4",
                    clientId = "client_rohit",
                    clientName = "Rohit D.",
                    rating = 5,
                    reviewText = "Startup registered in 3 days, trademark in 10 days. Best corporate lawyer in Bangalore! Extremely responsive.",
                    caseType = "Corporate & Startup"
                )
            )
            reviewDao.insertReview(
                ReviewEntity(
                    lawyerId = "lawyer_5",
                    clientId = "client_imran",
                    clientName = "Imran K.",
                    rating = 4,
                    reviewText = "Cheque bounce case won in 8 months. Very reasonable fees and weekly updates on status.",
                    caseType = "Cheque Bounce"
                )
            )
            reviewDao.insertReview(
                ReviewEntity(
                    lawyerId = "lawyer_6",
                    clientId = "client_pradeep",
                    clientName = "Pradeep S.",
                    rating = 5,
                    reviewText = "Helped me respond to a GST notice that scared me for months. Cleared in 3 weeks! Excellent and professional.",
                    caseType = "GST & Income Tax"
                )
            )
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: LobbyRepository? = null

        fun getInstance(context: Context): LobbyRepository {
            return INSTANCE ?: synchronized(this) {
                val db = LobbyDatabase.getDatabase(context)
                val instance = LobbyRepository(db)
                INSTANCE = instance
                instance
            }
        }
    }
}
