package com.example.data

import com.aistudio.lawyerslobby.advktz.BuildConfig
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Service to initialize the Google Generative AI client (com.google.ai.client.generativeai)
 * using the API key from the .env file (via BuildConfig) and send user messages to the Gemini model.
 */
object GoogleGenerativeAIService {
    private val apiKey = BuildConfig.GEMINI_API_KEY

    // Lazy initialization of the main model client
    private val model: GenerativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = apiKey,
            generationConfig = generationConfig {
                temperature = 0.7f
            }
        )
    }

    /**
     * Sends user messages to the Gemini model for legal assistant responses.
     */
    suspend fun generateLegalResponse(
        prompt: String,
        isLawyerMode: Boolean,
        chatHistory: List<Pair<String, Boolean>> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isEmpty() || apiKey == "AQ.Ab8RN6I2W-LPl7Wt832xYnPb1vM3KD5pSpxcy9WxEJPWGEspaQ") {
            return@withContext "Google Generative AI Client SDK initialized, but API Key is missing. Please configure your GEMINI_API_KEY via the Secrets panel in AI Studio."
        }

        try {
            // Dynamic system instructions depending on lawyer, counsel or citizen mode
            val systemInstruction = if (isLawyerMode) {
                """
                You are NyayaCopilot, a high-end luxury legal expert and co-counsel advisor. 
                You are advising a professional Advocate or Litigator practicing under the Bar Council of India.
                When answering, provide precise corporate citations, reference applicable sections from the Bhartiya Nyaya Sanhita (BNS), 
                Civil Procedure Code (CPC), or Indian Penal Code (IPC) contextually, draft professional legal clause snippets when requested, 
                and help formulate professional court litigation strategies. Maintain an elite, premium, objective tone.
                """.trimIndent()
            } else {
                """
                You are NyayaMitra, a luxury, empathetic automatic legal chatbot guiding an Indian citizen with pre-litigation queries.
                Explain complex legal terms in extremely simple language, highlight citizen rights, mention appropriate legal categories (e.g., Family Dispute, Cybercrime), 
                alert them on necessary documentation, and guide them on choosing top litigators near them. 
                Include a polite disclaimer stating that your advice is for awareness purposes only, not a substitute for a signed power of attorney.
                Keep responses elegantly formatted, structural, and easy to read.
                """.trimIndent()
            }

            // Create model with specific system instructions
            val modelWithInstruction = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = apiKey,
                systemInstruction = content { text(systemInstruction) },
                generationConfig = generationConfig {
                    temperature = 0.7f
                }
            )

            // Convert prior turns from chat history to SDK content format
            val sdkHistory = chatHistory.takeLast(10).map { (msg, isUser) ->
                content(role = if (isUser) "user" else "model") {
                    text(msg)
                }
            }

            // Start a chat session with the historical context and send the new message
            val chat = modelWithInstruction.startChat(sdkHistory)
            val response = chat.sendMessage(prompt)
            response.text ?: "Empty response received from Gemini."
        } catch (e: Exception) {
            e.printStackTrace()
            "Error: ${e.localizedMessage ?: e.message}"
        }
    }
}
