package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// =================================================================
// ENTITIES
// =================================================================

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val uid: String,
    val name: String,
    val email: String,
    val phone: String,
    val city: String,
    val state: String,
    val role: String, // "client" or "lawyer"
    val profilePhoto: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
)

@Entity(tableName = "lawyers")
data class LawyerEntity(
    @PrimaryKey val uid: String, // links to user uid
    val name: String,
    val email: String,
    val phone: String,
    val city: String,
    val state: String,
    val barCouncilNumber: String,
    val experienceYears: Int,
    val consultationFee: Int,
    val courtAppearanceFee: Int,
    val specialisation: String,
    val caseTypes: String, // Comma separated, e.g. "Criminal Defence, Bail Application"
    val languages: String, // Comma separated, e.g. "Hindi, English"
    val about: String,
    val officeAddress: String,
    val workingHours: String = "10:00 AM - 06:00 PM (Mon-Sat)",
    val profilePhoto: String = "",
    val officePhotos: String = "", // Comma-separated list of office photo paths (up to 5)
    val isVerified: Boolean = true,
    val isOnline: Boolean = true,
    val rating: Float = 4.5f,
    val totalReviews: Int = 0,
    val totalCasesWon: Int = 10,
    val linkedInUrl: String = "",
    val googleProfileUrl: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey(autoGenerate = true) val reviewId: Int = 0,
    val lawyerId: String,
    val clientId: String,
    val clientName: String,
    val rating: Int,
    val reviewText: String,
    val caseType: String,
    val isVerifiedClient: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val isVisible: Boolean = true
)

@Entity(tableName = "chalans")
data class ChalanEntity(
    @PrimaryKey(autoGenerate = true) val chalanId: Int = 0,
    val userId: String,
    val paymentType: String, // e.g. "Court Fee", "Chalan", "Stamp Duty", "Court Fine"
    val state: String,
    val courtNameOrCaseNumber: String,
    val amount: Double,
    val status: String = "completed", // "pending", "completed", "failed"
    val paymentMethod: String = "UPI",
    val userName: String,
    val contactNumber: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "emergency_requests")
data class EmergencyRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val city: String,
    val emergencyType: String, // e.g., "Police Arrest", "FIR Filed Against Me", "Urgent Bail Needed", etc.
    val description: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isResolved: Boolean = false,
    val assignedLawyerId: String? = null,
    val assignedLawyerName: String? = null
)

// =================================================================
// DAOS
// =================================================================

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE uid = :uid")
    suspend fun getUser(uid: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("UPDATE users SET isActive = :isActive WHERE uid = :uid")
    suspend fun updateUserActiveStatus(uid: String, isActive: Boolean)

    @Query("DELETE FROM users WHERE uid = :uid")
    suspend fun deleteUserByUid(uid: String)
}

@Dao
interface LawyerDao {
    @Query("SELECT * FROM lawyers")
    fun getAllLawyers(): Flow<List<LawyerEntity>>

    @Query("SELECT * FROM lawyers WHERE uid = :uid")
    suspend fun getLawyerById(uid: String): LawyerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLawyer(lawyer: LawyerEntity)

    @Query("UPDATE lawyers SET isOnline = :isOnline WHERE uid = :uid")
    suspend fun updateOnlineStatus(uid: String, isOnline: Boolean)

    @Query("UPDATE lawyers SET rating = :rating, totalReviews = :totalReviews WHERE uid = :uid")
    suspend fun updateRating(uid: String, rating: Float, totalReviews: Int)

    @Query("UPDATE lawyers SET isVerified = :isVerified WHERE uid = :uid")
    suspend fun updateLawyerVerification(uid: String, isVerified: Boolean)

    @Query("UPDATE lawyers SET isActive = :isActive WHERE uid = :uid")
    suspend fun updateLawyerActiveStatus(uid: String, isActive: Boolean)

    @Query("UPDATE lawyers SET name = :name, specialisation = :specialisation, experienceYears = :experienceYears, consultationFee = :consultationFee, courtAppearanceFee = :courtAppearanceFee WHERE uid = :uid")
    suspend fun updateLawyerDetails(uid: String, name: String, specialisation: String, experienceYears: Int, consultationFee: Int, courtAppearanceFee: Int)

    @Query("DELETE FROM lawyers WHERE uid = :uid")
    suspend fun deleteLawyerByUid(uid: String)
}

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews WHERE lawyerId = :lawyerId ORDER BY createdAt DESC")
    fun getReviewsForLawyer(lawyerId: String): Flow<List<ReviewEntity>>

    @Query("SELECT * FROM reviews ORDER BY createdAt DESC")
    fun getAllReviews(): Flow<List<ReviewEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: ReviewEntity)

    @Query("DELETE FROM reviews WHERE reviewId = :reviewId")
    suspend fun deleteReviewById(reviewId: Int)

    @Query("UPDATE reviews SET isVerifiedClient = :isVerifiedClient WHERE reviewId = :reviewId")
    suspend fun updateReviewVerification(reviewId: Int, isVerifiedClient: Boolean)
}

@Dao
interface ChalanDao {
    @Query("SELECT * FROM chalans WHERE userId = :userId ORDER BY createdAt DESC")
    fun getPaymentsForUser(userId: String): Flow<List<ChalanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChalan(chalan: ChalanEntity)

    @Query("SELECT * FROM chalans ORDER BY createdAt DESC")
    fun getAllChalans(): Flow<List<ChalanEntity>>
}

@Dao
interface EmergencyRequestDao {
    @Query("SELECT * FROM emergency_requests ORDER BY createdAt DESC")
    fun getAllEmergencyRequests(): Flow<List<EmergencyRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmergencyRequest(request: EmergencyRequestEntity)

    @Query("UPDATE emergency_requests SET isResolved = :isResolved, assignedLawyerId = :assignedLawyerId, assignedLawyerName = :assignedLawyerName WHERE id = :id")
    suspend fun updateEmergencyStatus(id: Int, isResolved: Boolean, assignedLawyerId: String?, assignedLawyerName: String?)
}

// =================================================================
// DATABASE
// =================================================================

@Database(
    entities = [
        UserEntity::class,
        LawyerEntity::class,
        ReviewEntity::class,
        ChalanEntity::class,
        EmergencyRequestEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class LobbyDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun lawyerDao(): LawyerDao
    abstract fun reviewDao(): ReviewDao
    abstract fun chalanDao(): ChalanDao
    abstract fun emergencyRequestDao(): EmergencyRequestDao

    companion object {
        @Volatile
        private var INSTANCE: LobbyDatabase? = null

        fun getDatabase(context: Context): LobbyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LobbyDatabase::class.java,
                    "lawyers_lobby_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
