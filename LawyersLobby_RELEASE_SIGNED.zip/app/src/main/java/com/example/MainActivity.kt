package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.data.AnalyticsHelper
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyBlue
import com.example.ui.theme.SaffronOrange
import com.example.ui.theme.WarmCream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AnalyticsHelper.init(applicationContext)
        try {
            com.google.android.gms.ads.MobileAds.initialize(this) {}
            com.example.ui.AdMobHelper.loadInterstitial(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LobbyApplicationScaffold()
            }
        }
    }
}

@Composable
fun LobbyApplicationScaffold() {
    val navController = rememberNavController()
    val viewModel: LobbyViewModel = viewModel()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var showGlobalFeedbackDialog by remember { mutableStateOf(false) }

    ShakeDetectorListener {
        showGlobalFeedbackDialog = true
    }

    if (showGlobalFeedbackDialog) {
        val scaffoldContext = LocalContext.current
        AppFeedbackDialog(
            onDismissRequest = { showGlobalFeedbackDialog = false },
            onFeedbackSubmitted = { category, rating, description ->
                sendFeedbackEmail(scaffoldContext, category, rating, description)
                showGlobalFeedbackDialog = false
            }
        )
    }

    // Track screen views automatically
    LaunchedEffect(currentRoute) {
        if (!currentRoute.isNullOrEmpty()) {
            AnalyticsHelper.logScreenView(currentRoute)
        }
    }

    // Define routes that should display the Bottom Navigation Bar
    val mainBarRoutes = listOf("home", "listing", "categories", "reviews", "my_profile")
    val showBottomBar = currentRoute in mainBarRoutes

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.navigationBars),
        bottomBar = {
            if (showBottomBar) {
                Column {
                    // Floating Pay Fees button anchored nicely above bottombar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NavyBlue)
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🇮🇳 Court Fee Portal Fast Deposit",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                        Button(
                            onClick = { navController.navigate("pay_fees") },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronOrange),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Pay Fees 🏛️", fontSize = 10.sp, color = Color.White)
                        }
                    }

                    // Native Material 3 Navigation Bar
                    NavigationBar(
                        containerColor = Color.White,
                        tonalElevation = 8.dp,
                        modifier = Modifier.height(72.dp)
                    ) {
                        NavigationBarItem(
                            selected = currentRoute == "home",
                            onClick = {
                                if (currentRoute != "home") {
                                    navController.navigate("home") {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                    }
                                }
                            },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                            label = { Text("Home", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SaffronOrange,
                                selectedTextColor = NavyBlue,
                                unselectedIconColor = NavyBlue.copy(alpha = 0.5f),
                                unselectedTextColor = NavyBlue.copy(alpha = 0.5f),
                                indicatorColor = WarmCream
                            )
                        )

                        NavigationBarItem(
                            selected = currentRoute == "listing",
                            onClick = {
                                if (currentRoute != "listing") {
                                    navController.navigate("listing") {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                    }
                                }
                            },
                            icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                            label = { Text("Find lawyers", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SaffronOrange,
                                selectedTextColor = NavyBlue,
                                unselectedIconColor = NavyBlue.copy(alpha = 0.5f),
                                unselectedTextColor = NavyBlue.copy(alpha = 0.5f),
                                indicatorColor = WarmCream
                            )
                        )

                        NavigationBarItem(
                            selected = currentRoute == "categories",
                            onClick = {
                                if (currentRoute != "categories") {
                                    navController.navigate("categories") {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                    }
                                }
                            },
                            icon = { Icon(Icons.Default.Balance, contentDescription = "Categories") },
                            label = { Text("Practice", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SaffronOrange,
                                selectedTextColor = NavyBlue,
                                unselectedIconColor = NavyBlue.copy(alpha = 0.5f),
                                unselectedTextColor = NavyBlue.copy(alpha = 0.5f),
                                indicatorColor = WarmCream
                            )
                        )

                        NavigationBarItem(
                            selected = currentRoute == "reviews",
                            onClick = {
                                if (currentRoute != "reviews") {
                                    navController.navigate("reviews") {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                    }
                                }
                            },
                            icon = { Icon(Icons.Default.Star, contentDescription = "Reviews") },
                            label = { Text("Feedbacks", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SaffronOrange,
                                selectedTextColor = NavyBlue,
                                unselectedIconColor = NavyBlue.copy(alpha = 0.5f),
                                unselectedTextColor = NavyBlue.copy(alpha = 0.5f),
                                indicatorColor = WarmCream
                            )
                        )

                        NavigationBarItem(
                            selected = currentRoute == "my_profile",
                            onClick = {
                                if (currentRoute != "my_profile") {
                                    navController.navigate("my_profile") {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                    }
                                }
                            },
                            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                            label = { Text("Profile", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SaffronOrange,
                                selectedTextColor = NavyBlue,
                                unselectedIconColor = NavyBlue.copy(alpha = 0.5f),
                                unselectedTextColor = NavyBlue.copy(alpha = 0.5f),
                                indicatorColor = WarmCream
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (showBottomBar) innerPadding.calculateBottomPadding() else 0.dp)
        ) {
            composable("splash") {
                SplashScreen(navController = navController)
            }

            composable("onboarding") {
                OnboardingScreen(navController = navController)
            }

            composable("auth") {
                OnboardingAuthScreen(navController = navController, viewModel = viewModel)
            }

            composable("home") {
                HomeScreen(navController = navController, viewModel = viewModel)
            }

            composable("listing") {
                LawyerListingScreen(navController = navController, viewModel = viewModel)
            }

            composable(
                route = "profile_detail/{lawyerId}",
                arguments = listOf(navArgument("lawyerId") { type = NavType.StringType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getString("lawyerId") ?: ""
                LawyerProfileScreen(navController = navController, viewModel = viewModel, lawyerId = id)
            }

            composable("categories") {
                LegalCategoriesScreen(navController = navController, viewModel = viewModel)
            }

            composable("reviews") {
                ClientReviewsScreen(viewModel = viewModel)
            }

            composable("pay_fees") {
                PayChalanScreen(viewModel = viewModel)
            }

            composable("my_profile") {
                MyProfileScreen(navController = navController, viewModel = viewModel)
            }

            composable("registration_success") {
                LawyerRegistrationSuccessScreen(navController = navController)
            }

            composable("emergency") {
                EmergencyLawyerScreen(navController = navController, viewModel = viewModel)
            }

            composable("ai_messenger") {
                AIChatbotScreen(navController = navController, viewModel = viewModel)
            }
        }
    }
}
